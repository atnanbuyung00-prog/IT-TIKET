# 🏥 AiniDesk - IT Support Ticket & Helpdesk System
### Rumah Sakit Mutiara Aini

Aplikasi Web IT Helpdesk & Ticketing System modern, tangguh, dan sangat ringan yang dibangun khusus untuk operasional penanganan kendala IT Rumah Sakit. Menggunakan teknologi **Golang (Go 1.22+)**, **SQLite (Pure Go tanpa CGO)**, **Bootstrap 5**, serta terintegrasi penuh dengan **Agen Bot Telegram** dan **Docker Container** yang dioptimalkan untuk **ZimaOS / CasaOS**.

---

## 🌟 Fitur Utama Sistem

### 1. 🌐 Portal Publik (Tanpa Perlu Login)
- **Pelaporan Kendala Mandiri (`/tickets/new`)**:
  - Pelapor (dokter, perawat, staf unit/ruangan) dapat langsung membuat tiket tanpa registrasi akun.
  - Form dinamis: Nama, No. WhatsApp/Telepon, Unit/Departemen, Kategori Gangguan, Tingkat Urgensi (*Rendah, Sedang, Tinggi, Darurat*), Subjek Masalah, dan Deskripsi Rinci.
  - Upload file bukti kendala (screenshot layar, foto hardware, PDF/Word) hingga 10MB dengan kompresi dan sanitasi nama file aman.
  - Pembuatan kode tiket unik otomatis (contoh: `TCK-20261102-A7F9`).
  - Halaman konfirmasi sukses dengan tombol sekali klik **"Salin Nomor Tiket"** ke clipboard dan tombol cetak bukti tiket.
- **Lacak Progres Tiket Real-Time (`/tickets/track`)**:
  - Pelapor dapat mengecek status penanganan tiket cukup dengan memasukkan Nomor Tiket dan Verifikasi No. HP/Email.
  - Visual *Stepper Progress*: **Tiket Diterima (Open)** ➔ **Sedang Ditangani (In Progress)** ➔ **Selesai (Resolved)** ➔ **Ditutup (Closed)**.
  - Komunikasi 2 arah: Pelapor dapat membalas dan mengirimkan komentar/tanggapan langsung ke teknisi.

### 2. 🛡️ Portal Kontrol Teknisi & Administrator (`/admin`)
- **Dashboard Statistik & Ringkasan Metrik**:
  - Jumlah total tiket, tiket aktif, tiket selesai, dan rata-rata waktu penanganan.
  - Grafik dan statistik kategori kendala terpopuler.
- **Manajemen Tiket Helpdesk**:
  - Filter lengkap berdasarkan status, prioritas, kategori kendala, unit kerja, dan pencarian instan.
  - Quick Action untuk update status langsung tanpa berpindah halaman.
  - Penugasan teknisi (*Assignee*) dan pencatatan catatan internal.
  - Fitur **Ubah** dan **Hapus Tiket** khusus akun Superadmin dengan modal konfirmasi protektif.
- **Ekspor Laporan Resmi ke Excel (`.xlsx`)**:
  - Ekspor seluruh riwayat penanganan kendala ke format spreadsheet Excel dengan format rapi untuk pelaporan manajemen RS.
- **Manajemen Master Data (`/admin/master`)**:
  - Tambah, ubah, dan hapus Kategori Kendala & Departemen/Unit RS secara dinamis.
- **Manajemen Pengguna & Hak Akses Granular (`/admin/technicians`)**:
  - Kontrol hak akses per teknisi: *Akses Tiket, Akses Master Data, Kelola Teknisi, atau Superadmin*.

### 3. 🔔 Notifikasi Real-Time & Nada Dering Alarm Tiket Baru
- **Auto-Polling Real-Time**: Portal admin mendeteksi tiket baru tanpa perlu me-refresh halaman.
- **4 Pilihan Nada Dering Suara Audio**:
  1. *Ticket Alert (Default)*
  2. *Hospital Bell*
  3. *Google Chime*
  4. *Radar Alarm*
- **Sistem Penyimpanan Nada Dering**: Pilihan nada dering tersimpan secara otomatis di memori browser pengguna (`localStorage`), sehingga tetap tersimpan meskipun pengguna logout dan login kembali.
- **Sinkronisasi Notifikasi Multi-Akun**: Jika ada akun teknisi yang baru login atau membuka dashboard setelah tiket masuk, sistem tetap mendeteksi tiket baru yang belum diproses dan membunyikan alarm suara.

### 4. 🤖 Agen Bot Telegram (@AiniDeskbot)
- **Token Bot**: `9108076489:AAGyGQThGjhRwXvXH_zVGgOB1bFZ9a2aEoQ`
- **Username Bot**: `@AiniDeskbot`
- **Notifikasi Instan**: Begitu ada staf/ruangan yang mengirim tiket kendala baru, bot langsung mengirimkan notifikasi detail (Kode Tiket, Pelapor, Unit, Masalah, Prioritas) ke akun Telegram teknisi yang terdaftar.
- **Interaksi Mandiri**: Teknisi cukup membuka `@AiniDeskbot` di Telegram dan mengetik `/start` untuk langsung terhubung otomatis tanpa konfigurasi rumit. Perintah lain yang didukung: `/id`, `/help`, `/stop`.

### 5. 🔒 Sistem Keamanan Internal & Optimasi
- **Built-in Web Application Firewall (WAF)**: Melindungi dari injeksi SQL, Cross-Site Scripting (XSS), Path Traversal, dan Web Scanner otomatis.
- **Anti-DDoS Rate Limiter**: Membatasi laju request per IP untuk mencegah flooding.
- **Bandwidth Optimizer**: Dilengkapi kompresi respons Gzip otomatis (menghemat 70-80% kuota jaringan) dan HTTP 304 Browser Caching untuk aset statis (CSS, JS, audio, gambar).

---

## 📁 Susunan Struktur Direktori Proyek

```
it-ticket-support/
├── cmd/
│   └── server/
│       └── main.go                 # Titik masuk utama aplikasi (Go HTTP server & routing)
├── internal/
│   ├── database/
│   │   ├── db.go                   # Driver SQLite pure Go, auto-migration tabel, pragmas
│   │   └── queries.go              # Fungsi CRUD tiket, komentar, master data, user & session
│   ├── handlers/
│   │   ├── admin.go                # Handler dashboard, tiket, master data, teknisi, profil
│   │   ├── auth.go                 # Handler autentikasi login & logout teknisi
│   │   ├── export.go               # Handler ekspor laporan riwayat tiket ke Excel (.xlsx)
│   │   ├── helpers.go              # Renderer HTML template & helper format tanggal/badge
│   │   └── public.go               # Handler halaman beranda, formulir buat tiket, tracking
│   ├── middleware/
│   │   ├── auth.go                 # Middleware cookie session & granular permissions
│   │   ├── bandwidth.go            # Middleware kompresi Gzip & HTTP cache 304
│   │   └── firewall.go             # Middleware WAF, anti-DDoS rate limiter, security headers
│   ├── models/
│   │   └── models.go               # Struct model data (Ticket, User, Category, Dept, Comment)
│   └── telegram/
│       └── telegram.go             # Engine Agen Bot Telegram (@AiniDeskbot) & Long Polling
├── web/
│   ├── static/
│   │   ├── css/
│   │   │   └── custom.css          # Desain antarmuka kustom (dark mode IT RS & animasi)
│   │   ├── img/                    # Logo RS Mutiara Aini, icon helpdesk, favicon
│   │   ├── js/
│   │   │   └── app.js              # Real-time notification poller, sound player, clipboard
│   │   ├── sounds/                 # Berkas audio nada dering (.wav, .m4a)
│   │   └── uploads/                # Direktori penyimpanan foto lampiran/screenshot tiket
│   └── templates/
│       ├── layout.html             # Master layout HTML Bootstrap 5
│       ├── admin/
│       │   ├── dashboard.html      # Tampilan dashboard kontrol teknisi
│       │   ├── login.html          # Form login dengan tombol 1-klik demo akun
│       │   ├── master.html         # Panel kelola Master Kategori & Departemen RS
│       │   ├── profile.html        # Pengaturan profil, username, & ubah password
│       │   ├── technicians.html    # Panel kelola akun staf teknisi & hak akses
│       │   ├── tickets.html        # Daftar seluruh tiket helpdesk & filter dinamis
│       │   └── ticket_detail.html  # Rincian tiket, respon teknisi, tombol ubah/hapus
│       └── public/
│           ├── index.html          # Halaman beranda IT Portal publik
│           ├── create_ticket.html  # Formulir pendaftaran tiket kendala baru
│           ├── ticket_success.html # Bukti tiket sukses & salin nomor tiket
│           └── track_ticket.html   # Pelacakan status tiket publik & balas tanggapan
├── .dockerignore                   # Berkas yang dikecualikan saat build Docker image
├── Dockerfile                      # Spesifikasi Docker multi-stage build (Alpine 3.19)
├── docker-compose.yml              # Konfigurasi container dengan metadata ZimaOS (x-casaos)
├── deploy-zimaos.sh                # Script 1-klik deploy otomatis di terminal ZimaOS
├── server-linux                    # Binary executable Linux x86_64 murni (siap pakai)
├── go.mod                          # Definisi modul dependensi Golang
├── go.sum                          # Checksum hash dependensi
└── README.md                       # Dokumentasi panduan lengkap sistem
```

---

## 🖥️ Panduan Instalasi & Menjalankan di ZimaOS

Aplikasi AiniDesk dirancang agar dapat berjalan dengan sangat efisien pada **ZimaOS** (ZimaBoard, ZimaBlade, maupun PC x86_64 yang diinstall ZimaOS). 

Tersedia **3 metode pilihan** untuk menjalankannya:

---

### METODE 1: Instalasi Melalui Web Dashboard ZimaOS (Sangat Mudah / Rekomendasi)

ZimaOS memiliki fitur *App Store Custom Install* yang mendukung import langsung dari file `docker-compose.yml`. Karena file `docker-compose.yml` proyek ini sudah dilengkapi metadata **`x-casaos`**, nama aplikasi, ikon, port, serta folder data akan terisi secara otomatis!

#### Langkah-langkah:
1. Pastikan folder proyek `it-ticket-support` sudah disalin ke ZimaOS, misalnya diletakkan di `/DATA/AppData/ainidesk-src`.
   *(Anda dapat mengunggahnya via menu **Files** di web ZimaOS atau via SFTP/SCP).*
2. Buka Web Dashboard ZimaOS di browser Anda (misalnya `http://zimaos.local` atau `http://<IP_ZIMAOS>`).
3. Masuk ke menu **App Store**.
4. Di pojok kanan atas App Store, klik tombol **"Custom Install"** (Ikon tanda tambah / Install Aplikasi Kustom).
5. Di pojok kanan atas jendela instalasi, klik tombol **"Import"** (ikon dokumen/panah).
6. Buka file `docker-compose.yml` dari proyek ini, salin (copy) seluruh isinya, lalu tempelkan (paste) ke dalam kotak Import ZimaOS, kemudian klik **Submit**.
7. ZimaOS akan otomatis membaca konfigurasi:
   - **Title**: AiniDesk IT Support
   - **Icon**: Ikon helpdesk otomatis terpasang
   - **Web Port**: `8080`
   - **Volumes**:
     - Host: `/DATA/AppData/ainidesk/data` ➔ Container: `/app/data` (Penyimpanan Database SQLite)
     - Host: `/DATA/AppData/ainidesk/uploads` ➔ Container: `/app/web/static/uploads` (Penyimpanan Foto)
   - **Environment**: Timezone `Asia/Jakarta` (WIB) dan Token Bot Telegram.
8. Klik tombol **Install**.
9. Selesai! Ikon aplikasi **AiniDesk IT Support** akan langsung muncul di halaman utama Dashboard ZimaOS dan siap digunakan.

---

### METODE 2: Instalasi Melalui Terminal / SSH ZimaOS (Docker Compose CLI)

Jika Anda lebih terbiasa menggunakan baris perintah (Terminal Web ZimaOS atau SSH dari komputer Anda):

1. Buka koneksi SSH ke ZimaOS:
   ```bash
   ssh root@<IP_ZIMAOS>
   ```
2. Pindahkan folder proyek `it-ticket-support` ke server ZimaOS, lalu masuk ke foldernya:
   ```bash
   cd /DATA/AppData/it-ticket-support
   ```
3. Berikan izin eksekusi pada script deploy otomatis:
   ```bash
   chmod +x deploy-zimaos.sh
   ```
4. Jalankan script deployment:
   ```bash
   ./deploy-zimaos.sh
   ```
   *Atau jika ingin menjalankan secara manual:*
   ```bash
   # Buat folder data persisten
   mkdir -p /DATA/AppData/ainidesk/data
   mkdir -p /DATA/AppData/ainidesk/uploads
   chmod -R 777 /DATA/AppData/ainidesk

   # Jalankan Docker Compose
   docker compose up -d --build
   ```
5. Periksa status kontainer:
   ```bash
   docker compose ps
   docker compose logs -f ainidesk
   ```

---

### METODE 3: Menjalankan Binary Standalone `server-linux` (Tanpa Docker)

Proyek ini telah menyediakan binary yang sudah dikompilasi khusus untuk Linux 64-bit (`server-linux`) tanpa dependensi sistem eksternal (menggunakan driver SQLite *pure Go*).

1. Unggah berkas `server-linux` beserta folder `web/` ke ZimaOS, misalnya di direktori `/DATA/AppData/ainidesk-bin`:
   ```
   /DATA/AppData/ainidesk-bin/
   ├── server-linux
   └── web/
       ├── static/
       └── templates/
   ```
2. Masuk ke direktori tersebut melalui Terminal/SSH:
   ```bash
   cd /DATA/AppData/ainidesk-bin
   chmod +x server-linux
   ```
3. Jalankan aplikasi:
   ```bash
   # Jalankan di background
   nohup ./server-linux > server.log 2>&1 &
   ```
4. Aplikasi akan langsung berjalan pada port `8080`.

---

## 💾 Struktur Penyimpanan Data Persisten di ZimaOS

Pada sistem operasi ZimaOS, seluruh data pengguna tersimpan di partisi `/DATA/`. Aplikasi ini telah diatur agar memetakan data penting ke folder persisten berikut:

| Direktori di ZimaOS (Host) | Direktori di Kontainer | Fungsi & Keterangan |
|---|---|---|
| `/DATA/AppData/ainidesk/data/` | `/app/data/` | Berisi berkas database SQLite `tickets.db`. Menyimpan seluruh data tiket, master data, akun teknisi, riwayat komentar, dan pengaturan bot Telegram. **Aman dari restart kontainer**. |
| `/DATA/AppData/ainidesk/uploads/` | `/app/web/static/uploads/` | Berisi seluruh berkas gambar/foto screenshot lampiran kendala yang diunggah oleh pelapor. |

> [!TIP]
> **Cara Melakukan Backup Rutin di ZimaOS**:
> Cukup salin folder `/DATA/AppData/ainidesk` ke flashdisk, external drive, atau cloud storage melalui menu **Files** di ZimaOS. Seluruh database dan foto lampiran akan langsung ter-backup secara utuh.

---

## 🤖 Menghubungkan Teknisi ke Agen Bot Telegram

Aplikasi telah terintegrasi dengan Bot Telegram `@AiniDeskbot`. Setiap ada tiket masalah baru yang dikirim oleh ruangan/unit kerja, bot akan otomatis mengirim pesan pemberitahuan ke seluruh staf IT yang terhubung.

### Cara Menghubungkan Akun Telegram Teknisi:
1. Buka aplikasi Telegram di HP atau Komputer Anda.
2. Cari username bot: **`@AiniDeskbot`**
3. Klik tombol **START** (atau ketik `/start`).
4. Bot akan langsung merespons:
   ```
   ✅ Pendaftaran Berhasil!
   Halo [Nama Anda], Akun Telegram Anda telah otomatis terdaftar sebagai penerima notifikasi masalah IT Rumah Sakit Mutiara Aini.
   ```
5. Akun Anda langsung aktif menerima pesan notifikasi setiap kali ada tiket kendala baru masuk ke sistem!
6. Perintah Telegram tambahan yang tersedia:
   - `/id` : Melihat nomor Telegram Chat ID Anda.
   - `/help` : Menampilkan petunjuk penggunaan bot.
   - `/stop` : Berhenti menerima notifikasi sementara waktu.

> [!NOTE]
> Jika Anda ingin menggunakan token bot Telegram milik Anda sendiri, Anda cukup mengubah nilai `TELEGRAM_BOT_TOKEN` pada file `docker-compose.yml` atau di form Custom Install ZimaOS.

---

## 🔑 Akun Login Bawaan Sistem

Saat database pertama kali diinisialisasi di ZimaOS, sistem secara otomatis menyiapkan akun bawaan:

| Peran (Role) | Username / Email | Password Default | Hak Akses |
|---|---|---|---|
| **Super Administrator IT** | `admin@itsupport.local` | `admin123` | Akses Penuh: Kelola Seluruh Tiket, Edit/Hapus Tiket, Master Kategori & Dept, Kelola Akun Teknisi, Ekspor Excel |
| **Teknisi 1 (Budi Santoso)** | `teknisi@itsupport.local` | `teknisi123` | Penanganan Tiket, Ubah Status, Tambah Respon |
| **Teknisi 2 (Eko Prasetyo)** | `eko@itsupport.local` | `teknisi123` | Penanganan Tiket + Master Kategori & Departemen |

*(Pada halaman login `/admin/login`, tersedia juga tombol demo 1-klik untuk memudahkan login tanpa mengetik).*

---

## 🛠️ Perintah Berguna & Troubleshooting di ZimaOS

### 1. Memeriksa Log Aplikasi
Untuk melihat log aktivitas, request HTTP, dan proses notifikasi Telegram:
```bash
docker logs -f ainidesk
```

### 2. Mengatasi Kendala Izin Folder (Permission Denied pada Database)
Jika database tidak bisa dibuat atau foto tidak bisa diunggah, pastikan folder di ZimaOS memiliki izin tulis:
```bash
chmod -R 777 /DATA/AppData/ainidesk
```

### 3. Mengubah Port Web (Jika Port 8080 Sudah Digunakan Aplikasi Lain)
Jika port 8080 di ZimaOS Anda sudah dipakai oleh aplikasi lain (misalnya Nextcloud atau Docker lain), cukup ganti mapping port host di file `docker-compose.yml`:
```yaml
ports:
  - "8085:8080"   # Akses web menjadi http://<IP_ZIMAOS>:8085
```

### 4. Memperbarui (Restart / Reload) Aplikasi
```bash
cd /DATA/AppData/it-ticket-support
docker compose down
docker compose up -d --build
```
*(Seluruh database dan foto lampiran tetap aman di folder `/DATA/AppData/ainidesk`).*

---

## 🌐 Tautan Alamat Web Aplikasi

Setelah berjalan di ZimaOS (asumsi alamat IP ZimaOS Anda adalah `192.168.1.50`):

- **Portal Beranda & Lapor Kendala Publik**: `http://192.168.1.50:8080/`
- **Formulir Buat Tiket Cepat**: `http://192.168.1.50:8080/tickets/new`
- **Cek & Lacak Tiket**: `http://192.168.1.50:8080/tickets/track`
- **Portal Login Teknisi / Admin**: `http://192.168.1.50:8080/admin/login`
- **Dashboard Tiket**: `http://192.168.1.50:8080/admin/dashboard`
- **Kelola Master Kategori & Dept**: `http://192.168.1.50:8080/admin/master`
- **Kelola Hak Akses Teknisi**: `http://192.168.1.50:8080/admin/technicians`
