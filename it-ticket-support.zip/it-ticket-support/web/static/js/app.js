// Client-side interactions for IT Ticket Support App - RS Mutiara Aini

document.addEventListener('DOMContentLoaded', () => {
    // 1. Format input nomor tiket otomatis menjadi UPPERCASE
    const ticketInputs = document.querySelectorAll('input[name="code"]');
    ticketInputs.forEach(input => {
        input.addEventListener('input', (e) => {
            e.target.value = e.target.value.toUpperCase();
        });
    });

    // 2. Auto-dismiss alert sukses setelah 5 detik
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) {
                bsAlert.close();
            }
        }, 5000);
    });

    // Helper global untuk memulihkan tombol submit ke status aktif & normal
    window.resetSubmitButton = function(form) {
        if (!form) return;
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            submitBtn.disabled = false;
            if (submitBtn.dataset.originalText) {
                submitBtn.innerHTML = submitBtn.dataset.originalText;
            }
        }
    };

    /**
     * Helper universal untuk menyalin teks ke clipboard dengan dukungan penuh
     * baik pada Secure Context (HTTPS/localhost) maupun Non-Secure Context (HTTP LAN/IP).
     */
    window.copyToClipboard = function(text, onSuccess, onError) {
        text = (text || '').trim();
        if (!text) return;

        // Fallback synchronous menggunakan textarea & execCommand
        function runExecCommandFallback() {
            var textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.setAttribute('readonly', '');
            textArea.style.position = 'fixed';
            textArea.style.top = '0';
            textArea.style.left = '0';
            textArea.style.width = '2em';
            textArea.style.height = '2em';
            textArea.style.padding = '0';
            textArea.style.border = 'none';
            textArea.style.outline = 'none';
            textArea.style.boxShadow = 'none';
            textArea.style.background = 'transparent';
            textArea.style.opacity = '0';
            textArea.style.fontSize = '16px';
            document.body.appendChild(textArea);

            textArea.focus();
            textArea.select();
            textArea.setSelectionRange(0, 99999);

            var ok = false;
            try {
                ok = document.execCommand('copy');
            } catch (err) {
                ok = false;
            }
            document.body.removeChild(textArea);

            if (ok) {
                if (typeof onSuccess === 'function') onSuccess(text);
            } else {
                try {
                    window.prompt('Salin nomor tiket secara manual (Ctrl+C lalu Enter):', text);
                    if (typeof onSuccess === 'function') onSuccess(text);
                } catch (promptErr) {
                    if (typeof onError === 'function') onError(promptErr);
                }
            }
        }

        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text)
                .then(() => {
                    if (typeof onSuccess === 'function') onSuccess(text);
                })
                .catch(() => {
                    runExecCommandFallback();
                });
        } else {
            runExecCommandFallback();
        }
    };

    /**
     * Menampilkan notifikasi toast kecil saat teks berhasil disalin
     */
    window.showCopyToast = function(message) {
        let toastContainer = document.getElementById('copyToastContainer');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'copyToastContainer';
            toastContainer.style.position = 'fixed';
            toastContainer.style.bottom = '24px';
            toastContainer.style.right = '24px';
            toastContainer.style.zIndex = '99999';
            toastContainer.style.pointerEvents = 'none';
            document.body.appendChild(toastContainer);
        }

        const toast = document.createElement('div');
        toast.className = 'alert shadow-lg border-0 rounded-pill px-4 py-2.5 mb-2 d-flex align-items-center gap-2';
        toast.style.backgroundColor = '#059669';
        toast.style.color = '#ffffff';
        toast.style.fontSize = '0.9rem';
        toast.style.fontWeight = '600';
        toast.style.boxShadow = '0 10px 25px -5px rgba(5, 150, 105, 0.4)';
        toast.style.pointerEvents = 'auto';
        toast.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
        toast.innerHTML = '<i class="bi bi-clipboard-check-fill fs-5"></i><span>' + message + '</span>';

        toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(12px)';
            setTimeout(() => toast.remove(), 350);
        }, 2500);
    };

    /**
     * Handler umum untuk tombol Salin Nomor Tiket
     */
    window.copyTicketCode = function(code, btn) {
        if (!code) {
            const codeEl = document.getElementById('ticketCodeText');
            if (codeEl) code = codeEl.textContent.trim();
        }
        if (!code) return;

        const targetBtn = btn || document.getElementById('btnCopyTicket');
        const icon = targetBtn ? (targetBtn.querySelector('i') || document.getElementById('copyIcon')) : document.getElementById('copyIcon');
        const label = targetBtn ? (targetBtn.querySelector('span') || document.getElementById('copyLabel')) : document.getElementById('copyLabel');

        window.copyToClipboard(code, function() {
            if (icon) {
                icon.dataset.prevClass = icon.className;
                icon.className = 'bi bi-check2-circle me-1 text-white';
            }
            if (label) {
                label.dataset.prevText = label.textContent;
                label.textContent = 'Tersalin!';
                label.classList.add('text-white', 'fw-bold');
            }
            if (targetBtn) {
                targetBtn.dataset.prevClass = targetBtn.className;
                targetBtn.classList.remove('btn-outline-primary', 'btn-outline-secondary');
                targetBtn.classList.add('btn-success', 'text-white', 'shadow-xs');
            }

            window.showCopyToast('Nomor tiket ' + code + ' berhasil disalin!');

            setTimeout(() => {
                if (icon && icon.dataset.prevClass) {
                    icon.className = icon.dataset.prevClass;
                }
                if (label && label.dataset.prevText) {
                    label.textContent = label.dataset.prevText;
                    label.classList.remove('text-white', 'fw-bold');
                }
                if (targetBtn && targetBtn.dataset.prevClass) {
                    targetBtn.className = targetBtn.dataset.prevClass;
                }
            }, 2500);
        }, function(err) {
            alert('Nomor tiket Anda: ' + code);
        });
    };

    // 3. Disable double submit secara cerdas (tidak mengunci jika form belum valid atau dicegah)
    const forms = document.querySelectorAll('form:not(#formExportExcel)');
    forms.forEach(form => {
        // Pulihkan tombol submit seketika saat user mengetik atau mengubah input apapun di form
        form.addEventListener('input', () => window.resetSubmitButton(form));
        form.addEventListener('change', () => window.resetSubmitButton(form));

        form.addEventListener('submit', function(e) {
            // Jika form dicegah oleh validasi sebelumnya, jangan nonaktifkan tombol
            if (e.defaultPrevented) {
                window.resetSubmitButton(this);
                return;
            }

            // Validasi HTML5 bawaan: jika ada field required yang belum diisi, jangan nonaktifkan tombol
            if (typeof this.checkValidity === 'function' && !this.checkValidity()) {
                window.resetSubmitButton(this);
                return;
            }

            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn && !submitBtn.disabled) {
                if (!submitBtn.dataset.originalText) {
                    submitBtn.dataset.originalText = submitBtn.innerHTML;
                }
                
                // Beri jeda 50ms agar browser selesai menyusun payload form sebelum tombol disabled
                setTimeout(() => {
                    if (!e.defaultPrevented) {
                        submitBtn.disabled = true;
                        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Memproses...';
                    }
                }, 50);

                // Safety watchdog: pulihkan tombol otomatis setelah 6 detik jika halaman belum berpindah
                setTimeout(() => {
                    window.resetSubmitButton(this);
                }, 6000);
            }
        });
    });

    // 4. Inisialisasi Filter Modal Unduh Excel
    initExcelExportFilterModal();

    // 5. Sistem Notifikasi Tiket Masuk & Nada Dering untuk Teknisi / Admin
    const isUserAuthenticated = document.body.dataset.userAuthenticated === 'true';
    if (isUserAuthenticated) {
        initTicketNotificationSystem();
    }
});

/**
 * Pengaturan & Handler Modal Filter Unduh Excel (Rentang Tanggal, Per Bulan, dan Per Tahun)
 */
function initExcelExportFilterModal() {
    const modalEl = document.getElementById('modalExportExcel');
    if (!modalEl) return;

    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1; // 1-12

    // Set default month & year
    const monthSelect = document.getElementById('exportMonthSelect');
    if (monthSelect) monthSelect.value = currentMonth.toString();

    const yearSelect = document.getElementById('exportYearSelect');
    if (yearSelect) yearSelect.value = currentYear.toString();

    const yearOnlySelect = document.getElementById('exportYearOnlySelect');
    if (yearOnlySelect) yearOnlySelect.value = currentYear.toString();

    // Set default date range: awal bulan ini s/d hari ini
    const startInput = document.getElementById('exportStartDate');
    const endInput = document.getElementById('exportEndDate');
    if (startInput && endInput) {
        const yyyy = now.getFullYear();
        const mm = String(now.getMonth() + 1).padStart(2, '0');
        const dd = String(now.getDate()).padStart(2, '0');
        startInput.value = `${yyyy}-${mm}-01`;
        endInput.value = `${yyyy}-${mm}-${dd}`;
    }

    // Handler form submit ekspor
    const exportForm = document.getElementById('formExportExcel');
    if (exportForm) {
        exportForm.addEventListener('submit', () => {
            const selectedType = document.querySelector('input[name="filter_type"]:checked')?.value || 'month';
            if (selectedType === 'year' && yearOnlySelect && yearSelect) {
                yearSelect.value = yearOnlySelect.value;
            }
            // Tutup modal setelah klik unduh
            setTimeout(() => {
                const bsModal = bootstrap.Modal.getInstance(modalEl);
                if (bsModal) bsModal.hide();
            }, 600);
        });
    }
}

/**
 * Fungsi global untuk beralih tampilan tab filter pada modal ekspor excel
 */
window.toggleExportFilterView = function() {
    const selected = document.querySelector('input[name="filter_type"]:checked')?.value || 'month';
    const panelMonth = document.getElementById('panelFilterMonth');
    const panelRange = document.getElementById('panelFilterRange');
    const panelYear = document.getElementById('panelFilterYear');
    const panelPeriod = document.getElementById('panelFilterPeriod');

    if (panelMonth) panelMonth.classList.toggle('d-none', selected !== 'month');
    if (panelRange) panelRange.classList.toggle('d-none', selected !== 'range');
    if (panelYear) panelYear.classList.toggle('d-none', selected !== 'year');
    if (panelPeriod) panelPeriod.classList.toggle('d-none', selected !== 'all');
};

/**
 * Shared AudioContext singleton untuk mencegah limit hardware browser
 */
let sharedAudioContext = null;
function getSharedAudioContext() {
    if (!sharedAudioContext) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) {
            sharedAudioContext = new AudioCtx();
        }
    }
    if (sharedAudioContext && sharedAudioContext.state === 'suspended') {
        sharedAudioContext.resume();
    }
    return sharedAudioContext;
}

/**
 * Inisialisasi Modul Notifikasi Real-Time & Nada Dering
 */
function initTicketNotificationSystem() {
    const validRingtones = ['custom', 'google', 'hospital', 'melody'];

    // Helper membaca preferensi nada dering (localStorage -> Cookie -> Server DOM fallback)
    function getSavedRingtone() {
        const local = localStorage.getItem('it_ticket_ringtone_type');
        if (local && validRingtones.includes(local)) {
            return local;
        }

        const match = document.cookie.match(/(?:^|;\s*)it_ticket_ringtone_type=([^;]+)/);
        if (match && match[1]) {
            const val = decodeURIComponent(match[1]);
            if (validRingtones.includes(val)) {
                localStorage.setItem('it_ticket_ringtone_type', val);
                return val;
            }
        }

        const selectEl = document.getElementById('selectRingtoneType');
        if (selectEl && selectEl.value && validRingtones.includes(selectEl.value)) {
            return selectEl.value;
        }

        return 'custom';
    }

    // Helper menyimpan preferensi nada dering secara permanen ke localStorage dan Cookie (1 tahun)
    function saveRingtone(val) {
        if (!val || !validRingtones.includes(val)) return;
        localStorage.setItem('it_ticket_ringtone_type', val);
        document.cookie = 'it_ticket_ringtone_type=' + encodeURIComponent(val) + '; path=/; max-age=31536000; SameSite=Lax';
    }

    // Helper membaca status suara aktif/mute
    function getSavedSoundEnabled() {
        const local = localStorage.getItem('it_ticket_sound_enabled');
        if (local !== null) {
            return local !== 'false';
        }
        const match = document.cookie.match(/(?:^|;\s*)it_ticket_sound_enabled=([^;]+)/);
        if (match && match[1]) {
            return match[1] !== 'false';
        }
        return true;
    }

    // Helper menyimpan status suara aktif/mute
    function saveSoundEnabled(val) {
        localStorage.setItem('it_ticket_sound_enabled', val ? 'true' : 'false');
        document.cookie = 'it_ticket_sound_enabled=' + (val ? 'true' : 'false') + '; path=/; max-age=31536000; SameSite=Lax';
    }

    let soundEnabled = getSavedSoundEnabled();
    let ringtoneType = getSavedRingtone();

    // Pastikan tersimpan sinkron di cookie & localStorage
    saveRingtone(ringtoneType);
    saveSoundEnabled(soundEnabled);

    // Identifikasi ID akun teknisi yang sedang aktif untuk melacak riwayat notifikasi per-akun
    const currentUserId = document.body.dataset.userId || 'default';
    const userTicketStorageKey = 'it_last_known_ticket_id_' + currentUserId;

    function getSavedLastKnownTicketId() {
        const val = localStorage.getItem(userTicketStorageKey);
        return val ? parseInt(val, 10) : 0;
    }

    function saveLastKnownTicketId(id) {
        if (id > 0) {
            localStorage.setItem(userTicketStorageKey, id.toString());
        }
    }

    let lastKnownTicketId = getSavedLastKnownTicketId();
    let unreadCount = 0;

    // Buffer audio Web Audio API untuk nada dering khusus
    let customAudioBuffer = null;
    let isDecodingCustomAudio = false;
    async function preloadCustomAudioBuffer() {
        if (customAudioBuffer || isDecodingCustomAudio) return;
        try {
            isDecodingCustomAudio = true;
            const ctx = getSharedAudioContext();
            if (!ctx) return;
            const res = await fetch('/static/sounds/custom-alert.m4a');
            if (!res.ok) return;
            const arrayBuf = await res.arrayBuffer();
            customAudioBuffer = await ctx.decodeAudioData(arrayBuf);
        } catch (e) {
            console.log("WebAudio custom audio buffer note:", e);
        } finally {
            isDecodingCustomAudio = false;
        }
    }
    // Preload di latar belakang
    setTimeout(preloadCustomAudioBuffer, 600);

    // DOM Elements
    const bellIcon = document.getElementById('notificationBellIcon');
    const countBadge = document.getElementById('notificationCountBadge');
    const navNotificationItem = document.getElementById('navNotificationItem');
    const notificationList = document.getElementById('notificationItemsList');
    const emptyState = document.getElementById('notificationEmptyState');
    const toastContainer = document.getElementById('ticketToastContainer');
    const btnToggleSound = document.getElementById('btnToggleSound');
    const btnToggleSoundIcon = document.getElementById('btnToggleSoundIcon');
    const btnToggleSoundText = document.getElementById('btnToggleSoundText');
    const soundStatusBadge = document.getElementById('soundStatusBadge');
    const selectRingtoneType = document.getElementById('selectRingtoneType');
    const soundPlayingNotice = document.getElementById('soundPlayingNotice');
    const btnTestSound = document.getElementById('btnTestSound');
    const btnEnableDesktopNotif = document.getElementById('btnEnableDesktopNotif');

    // Inisialisasi Pilihan Nada Dering & Event Listener
    if (selectRingtoneType) {
        selectRingtoneType.value = ringtoneType;
        selectRingtoneType.addEventListener('change', (e) => {
            ringtoneType = e.target.value;
            saveRingtone(ringtoneType);
            // Uji coba suara yang baru dipilih
            playTicketRingtone();
        });
    }

    // Update UI Sound Status
    function updateSoundUI() {
        if (!btnToggleSound || !soundStatusBadge) return;
        if (soundEnabled) {
            btnToggleSoundIcon.className = 'bi bi-volume-mute-fill text-danger';
            btnToggleSoundText.textContent = 'Mute Nada Dering';
            soundStatusBadge.className = 'badge bg-success-subtle text-success border border-success-subtle small font-monospace';
            soundStatusBadge.innerHTML = '<i class="bi bi-volume-up-fill me-1"></i> Suara Aktif';
        } else {
            btnToggleSoundIcon.className = 'bi bi-volume-up-fill text-success';
            btnToggleSoundText.textContent = 'Aktifkan Suara';
            soundStatusBadge.className = 'badge bg-secondary-subtle text-secondary border border-secondary-subtle small font-monospace';
            soundStatusBadge.innerHTML = '<i class="bi bi-volume-mute-fill me-1"></i> Suara Nonaktif';
        }
    }
    updateSoundUI();

    // Auto unlock audio context & gesture handler
    let pendingRingtoneRepeats = 0;

    function showAudioUnlockNotice() {
        if (document.getElementById('audioUnlockFloatingNotice')) return;
        const banner = document.createElement('div');
        banner.id = 'audioUnlockFloatingNotice';
        banner.className = 'position-fixed top-0 start-50 translate-middle-x mt-3 shadow-lg rounded-pill px-4 py-2 bg-primary text-white d-flex align-items-center gap-2 cursor-pointer';
        banner.style.zIndex = '99999';
        banner.style.cursor = 'pointer';
        banner.innerHTML = `
            <i class="bi bi-bell-fill animate-pulse fs-5 text-warning"></i>
            <span class="small fw-semibold">Tiket baru masuk! Klik di mana saja untuk mengaktifkan nada dering</span>
            <button type="button" class="btn-close btn-close-white btn-sm ms-2" aria-label="Close"></button>
        `;
        banner.addEventListener('click', (e) => {
            e.stopPropagation();
            handleUserAudioInteraction();
        });
        const closeBtn = banner.querySelector('.btn-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                removeAudioUnlockNotice();
            });
        }
        document.body.appendChild(banner);
    }

    function removeAudioUnlockNotice() {
        const el = document.getElementById('audioUnlockFloatingNotice');
        if (el) el.remove();
    }

    function unlockAudio() {
        const ctx = getSharedAudioContext();
        if (ctx && ctx.state === 'suspended') {
            ctx.resume();
        }
        preloadCustomAudioBuffer();
        const audioTags = ['audioCustomAlert', 'audioGoogleChime', 'audioHospitalBell', 'audioTicketAlert'];
        audioTags.forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.load();
            }
        });
    }

    function handleUserAudioInteraction() {
        unlockAudio();
        removeAudioUnlockNotice();
        if (pendingRingtoneRepeats > 0) {
            const repeats = pendingRingtoneRepeats;
            pendingRingtoneRepeats = 0;
            startRepeatingTicketRingtone(repeats);
        }
    }

    window.addEventListener('click', handleUserAudioInteraction, { passive: true });
    window.addEventListener('keydown', handleUserAudioInteraction, { passive: true });
    window.addEventListener('touchstart', handleUserAudioInteraction, { passive: true });

    // Variabel pengulangan nada dering tiket masuk (hingga 10 kali)
    let ringtoneRepeatTimer = null;
    let ringtoneCurrentRepeat = 0;
    const MAX_RINGTONE_REPEATS = 10;
    const RINGTONE_INTERVAL_MS = 2500; // Jeda 2.5 detik per pengulangan nada dering standard

    // Toggle Sound Button
    if (btnToggleSound) {
        btnToggleSound.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            soundEnabled = !soundEnabled;
            saveSoundEnabled(soundEnabled);
            updateSoundUI();
            if (!soundEnabled) {
                stopRepeatingTicketRingtone();
            } else {
                playTicketRingtone();
            }
        });
    }

    // Test Sound Button
    if (btnTestSound) {
        btnTestSound.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            unlockAudio();
            playTicketRingtone();
            showTestToast();
        });
    }

    // Enable Desktop Notification Permission
    if (btnEnableDesktopNotif) {
        if ("Notification" in window && Notification.permission === "granted") {
            btnEnableDesktopNotif.innerHTML = '<i class="bi bi-check-circle-fill text-success me-1"></i> Notifikasi Desktop Aktif';
            btnEnableDesktopNotif.classList.add('text-success');
        }

        btnEnableDesktopNotif.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (!("Notification" in window)) {
                alert("Browser ini tidak mendukung Web Notifications API.");
                return;
            }
            Notification.requestPermission().then(permission => {
                if (permission === "granted") {
                    btnEnableDesktopNotif.innerHTML = '<i class="bi bi-check-circle-fill text-success me-1"></i> Notifikasi Desktop Aktif';
                    btnEnableDesktopNotif.classList.add('text-success');
                    new Notification("RS Mutiara Aini IT Support", {
                        body: "Notifikasi tiket baru desktop telah berhasil diaktifkan!",
                        icon: "/static/img/logo.png"
                    });
                }
            });
        });
    }

    // Reset unread counter, animation, dan HENTIKAN dering ketika dropdown lonceng dibuka
    if (navNotificationItem) {
        navNotificationItem.addEventListener('show.bs.dropdown', () => {
            stopRepeatingTicketRingtone();
            unreadCount = 0;
            if (countBadge) {
                countBadge.textContent = '0';
                countBadge.classList.add('d-none');
            }
            if (bellIcon) {
                bellIcon.classList.remove('bell-ringing');
            }
        });
    }

    /**
     * Menghentikan pengulangan dering tiket
     */
    function stopRepeatingTicketRingtone() {
        if (ringtoneRepeatTimer) {
            clearTimeout(ringtoneRepeatTimer);
            ringtoneRepeatTimer = null;
        }
        ringtoneCurrentRepeat = 0;
        pendingRingtoneRepeats = 0;
        removeAudioUnlockNotice();

        if (soundPlayingNotice) {
            soundPlayingNotice.style.display = 'none';
        }

        const btnStopRingtone = document.getElementById('btnStopRingtone');
        if (btnStopRingtone) {
            btnStopRingtone.classList.add('d-none');
            btnStopRingtone.classList.remove('d-inline-flex');
        }

        const toastBadges = document.querySelectorAll('.repeat-count-indicator');
        toastBadges.forEach(badge => {
            badge.innerHTML = '<i class="bi bi-volume-mute text-secondary me-1"></i>Dering Berhenti';
        });
    }
    // Ekspor ke window global agar dapat dipanggil dari onclick tombol / toast
    window.stopTicketRingtone = stopRepeatingTicketRingtone;

    /**
     * Memulai pengulangan nada dering tiket masuk hingga 10 kali
     */
    function startRepeatingTicketRingtone(maxRepeats = MAX_RINGTONE_REPEATS) {
        if (!soundEnabled) return;

        // Bersihkan timer aktif sebelumnya
        stopRepeatingTicketRingtone();
        ringtoneCurrentRepeat = 0;

        function runCycle() {
            if (!soundEnabled) {
                stopRepeatingTicketRingtone();
                return;
            }

            ringtoneCurrentRepeat++;
            playTicketRingtone();

            // Update UI status berdering
            if (soundPlayingNotice) {
                soundPlayingNotice.style.display = 'inline';
                soundPlayingNotice.innerHTML = `<i class="bi bi-soundwave text-warning animate-pulse me-1"></i>Berdering (${ringtoneCurrentRepeat}/${maxRepeats})...`;
            }

            const btnStopRingtone = document.getElementById('btnStopRingtone');
            if (btnStopRingtone) {
                btnStopRingtone.classList.remove('d-none');
                btnStopRingtone.classList.add('d-inline-flex');
                const label = btnStopRingtone.querySelector('.stop-label');
                if (label) label.textContent = `Hentikan Dering (${ringtoneCurrentRepeat}/${maxRepeats})`;
            }

            const toastBadges = document.querySelectorAll('.repeat-count-indicator');
            toastBadges.forEach(badge => {
                badge.innerHTML = `<i class="bi bi-bell-fill text-warning me-1"></i>Dering ${ringtoneCurrentRepeat}/${maxRepeats}`;
            });

            // Jadwalkan putaran berikutnya jika belum mencapai batas 10 kali
            // Sesuaikan jeda berdasarkan durasi audio (audio khusus ~5 detik, nada pendek 2.5 detik)
            const repeatInterval = (ringtoneType === 'custom') ? 5200 : RINGTONE_INTERVAL_MS;
            if (ringtoneCurrentRepeat < maxRepeats) {
                ringtoneRepeatTimer = setTimeout(runCycle, repeatInterval);
            } else {
                // Selesai 10 kali putaran
                setTimeout(() => {
                    stopRepeatingTicketRingtone();
                }, (ringtoneType === 'custom') ? 4500 : 2000);
            }
        }

        runCycle();
    }

    /**
     * Memutar nada dering notifikasi tiket
     * Menggunakan Web Audio API synthesizer / AudioBuffer + fallback HTML5 audio element
     */
    function playTicketRingtone() {
        if (!soundEnabled) return;

        // Tampilkan indikator visual suara berbunyi
        if (soundPlayingNotice) {
            soundPlayingNotice.style.display = 'inline';
            setTimeout(() => { soundPlayingNotice.style.display = 'none'; }, 2000);
        }

        // Tentukan audio element berdasarkan pilihan user
        let audioTagId = 'audioCustomAlert';
        if (ringtoneType === 'google') {
            audioTagId = 'audioGoogleChime';
        } else if (ringtoneType === 'hospital') {
            audioTagId = 'audioHospitalBell';
        } else if (ringtoneType === 'melody') {
            audioTagId = 'audioTicketAlert';
        } else if (ringtoneType === 'custom') {
            audioTagId = 'audioCustomAlert';
        }

        let isBlocked = false;
        const ctx = getSharedAudioContext();
        if (ctx && ctx.state === 'suspended') {
            isBlocked = true;
            ctx.resume().catch(() => {});
        }

        const audioEl = document.getElementById(audioTagId);
        if (audioEl) {
            try {
                audioEl.currentTime = 0;
                audioEl.volume = 1.0;
                const playPromise = audioEl.play();
                if (playPromise !== undefined) {
                    playPromise.catch(err => {
                        console.log("HTML5 Audio play note (fallback to WebAudio):", err);
                        if (err.name === 'NotAllowedError') {
                            isBlocked = true;
                            if (soundEnabled && !document.getElementById('audioUnlockFloatingNotice')) {
                                pendingRingtoneRepeats = MAX_RINGTONE_REPEATS;
                                showAudioUnlockNotice();
                            }
                        }
                    });
                }
            } catch (e) {}
        }

        if (isBlocked && soundEnabled && !document.getElementById('audioUnlockFloatingNotice')) {
            pendingRingtoneRepeats = MAX_RINGTONE_REPEATS;
            showAudioUnlockNotice();
        }

        // Jalankan juga Web Audio API Synthesizer / AudioBuffer independen (Anti-Gagal)
        try {
            const ctx = getSharedAudioContext();
            if (ctx) {
                if (ringtoneType === 'custom') {
                    // Putar via Web Audio API AudioBuffer yang telah di-decode di memory jika tersedia
                    if (customAudioBuffer) {
                        const srcNode = ctx.createBufferSource();
                        srcNode.buffer = customAudioBuffer;
                        const gainNode = ctx.createGain();
                        gainNode.gain.setValueAtTime(1.0, ctx.currentTime);
                        srcNode.connect(gainNode);
                        gainNode.connect(ctx.destination);
                        srcNode.start(0);
                    }
                } else {
                    const now = ctx.currentTime;
                    if (ringtoneType === 'google') {
                        // Google Material Chime: C6 (1046 Hz) -> E6 (1318 Hz) -> G6 (1568 Hz)
                        playTone(ctx, 1046.50, now + 0.00, 0.40, 0.75);
                        playTone(ctx, 1318.51, now + 0.10, 0.50, 0.80);
                        playTone(ctx, 1567.98, now + 0.20, 0.85, 0.85);
                    } else if (ringtoneType === 'hospital') {
                        // Hospital Nurse Call Bell: Ding (A5 = 880 Hz) -> Dong (D5 = 587 Hz)
                        playTone(ctx, 880.00, now + 0.00, 0.75, 0.85);
                        playTone(ctx, 587.33, now + 0.45, 1.10, 0.90);
                    } else {
                        // Melodi Chime: E5 -> G#5 -> B5 -> E6
                        playTone(ctx, 659.25, now + 0.00, 0.65, 0.75);
                        playTone(ctx, 830.61, now + 0.18, 0.65, 0.80);
                        playTone(ctx, 987.77, now + 0.36, 0.75, 0.85);
                        playTone(ctx, 1318.51, now + 0.54, 1.10, 0.90);
                    }
                }
            }
        } catch (err) {
            console.warn("WebAudio Synthesizer note:", err);
        }
    }

    /**
     * Memainkan 1 not nada sintetis yang aman tanpa resiko InvalidStateError
     */
    function playTone(ctx, freq, startTime, duration, volume) {
        try {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, startTime);

            // Linear ramp attack & smooth decay (aman dari throw exception)
            gain.gain.setValueAtTime(0.0001, startTime);
            gain.gain.linearRampToValueAtTime(volume, startTime + 0.02);
            gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

            osc.connect(gain);
            gain.connect(ctx.destination);

            osc.start(startTime);
            osc.stop(startTime + duration + 0.05);
        } catch (e) {
            console.log("playTone note:", e);
        }
    }

    /**
     * Tampilkan Toast Konfirmasi Tes Suara
     */
    function showTestToast() {
        if (!toastContainer) return;
        const toastId = 'toast-test-' + Date.now();
        let soundName = 'Suara Khusus RS Mutiara Aini';
        if (ringtoneType === 'google') soundName = 'Google Material Chime';
        else if (ringtoneType === 'hospital') soundName = 'Bel Panggilan Rumah Sakit (Ding-Dong)';
        else if (ringtoneType === 'melody') soundName = 'Melodi Chime Multi-Tone';

        const toastHtml = `
            <div id="${toastId}" class="toast ticket-toast show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="true" data-bs-delay="5000">
                <div class="ticket-toast-header bg-dark d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center gap-2">
                        <i class="bi bi-volume-up-fill text-warning fs-5"></i>
                        <strong class="me-auto text-white">Uji Coba Nada Dering Berhasil</strong>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="ticket-toast-body">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <span class="badge bg-success-subtle text-success border border-success-subtle font-monospace"><i class="bi bi-check-circle-fill me-1"></i>Suara Diputar</span>
                        <span class="small fw-bold text-dark">${soundName}</span>
                    </div>
                    <p class="mb-0 text-muted smaller">Jika belum mendengar bunyi, pastikan volume speaker komputer telah dinaikkan dan tab browser tidak dalam mode mute.</p>
                </div>
            </div>
        `;
        toastContainer.insertAdjacentHTML('beforeend', toastHtml);
        const toastEl = document.getElementById(toastId);
        if (toastEl && window.bootstrap) {
            const bsToast = new bootstrap.Toast(toastEl, { delay: 5000 });
            bsToast.show();
        }
    }

    /**
     * Tampilkan Floating Toast Alert untuk Tiket Masuk Baru
     */
    function showTicketNotificationToast(ticket) {
        if (!toastContainer) return;

        const toastId = 'toast-ticket-' + ticket.id + '-' + Date.now();
        let priorityBadgeClass = 'bg-primary text-white';
        let priorityHeaderClass = 'priority-Sedang';

        if (ticket.priority === 'Darurat') {
            priorityBadgeClass = 'bg-danger text-white animate-pulse';
            priorityHeaderClass = 'priority-Darurat';
        } else if (ticket.priority === 'Tinggi') {
            priorityBadgeClass = 'bg-warning text-dark';
            priorityHeaderClass = 'priority-Tinggi';
        } else if (ticket.priority === 'Rendah') {
            priorityBadgeClass = 'bg-info text-dark';
            priorityHeaderClass = 'priority-Rendah';
        }

        const safeCode = escapeHtml(ticket.ticket_code);
        const safeName = escapeHtml(ticket.requester_name);
        const safeDept = escapeHtml(ticket.department);
        const safeSubject = escapeHtml(ticket.subject);
        const safePriority = escapeHtml(ticket.priority);
        const safeTime = escapeHtml(ticket.time_ago || 'Baru saja');

        const toastHtml = `
            <div id="${toastId}" class="toast ticket-toast show mb-3" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="ticket-toast-header ${priorityHeaderClass} d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center gap-2">
                        <span class="spinner-grow spinner-grow-sm text-warning" role="status"></span>
                        <strong class="text-white small fw-bold">TIKET MASUK BARU!</strong>
                        <span class="badge ${priorityBadgeClass} small px-2 py-0.5 rounded-pill">${safePriority}</span>
                    </div>
                    <div class="d-flex align-items-center gap-1.5">
                        <span class="badge bg-white text-dark small font-monospace repeat-count-indicator shadow-2xs" style="font-size: 0.72rem;">
                            <i class="bi bi-bell-fill text-warning me-1"></i>Dering (1/10)
                        </span>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close" onclick="window.stopTicketRingtone()"></button>
                    </div>
                </div>
                <div class="ticket-toast-body">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <span class="badge bg-light text-primary border font-monospace fw-bold">${safeCode}</span>
                        <span class="text-muted smaller"><i class="bi bi-clock me-1"></i>${safeTime}</span>
                    </div>
                    <h6 class="fw-bold text-dark mb-1 text-truncate" title="${safeSubject}">${safeSubject}</h6>
                    <div class="text-secondary small mb-3">
                        <i class="bi bi-person-fill text-primary me-1"></i><strong>${safeName}</strong>
                        <span class="text-muted">&bull; ${safeDept}</span>
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="/admin/tickets/${ticket.id}" class="btn btn-sm btn-primary rounded-pill flex-fill fw-bold shadow-xs d-flex align-items-center justify-content-center gap-1.5 py-1.5" onclick="window.stopTicketRingtone()">
                            <i class="bi bi-box-arrow-up-right"></i> Buka Tiket Sekarang
                        </a>
                        <button type="button" class="btn btn-sm btn-outline-danger rounded-pill px-2.5 d-flex align-items-center gap-1" onclick="window.stopTicketRingtone()" title="Hentikan Nada Dering">
                            <i class="bi bi-volume-mute-fill"></i> Stop Dering
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill px-3" data-bs-dismiss="toast" onclick="window.stopTicketRingtone()">
                            Tutup
                        </button>
                    </div>
                </div>
            </div>
        `;

        toastContainer.insertAdjacentHTML('beforeend', toastHtml);
        const toastEl = document.getElementById(toastId);
        if (toastEl && window.bootstrap) {
            // Toast tetap aktif selama pengulangan dering (35 detik) atau sampai user menutupnya
            const bsToast = new bootstrap.Toast(toastEl, { autohide: true, delay: 35000 });
            bsToast.show();
        }

        // Tampilkan juga notifikasi browser desktop jika diizinkan
        if ("Notification" in window && Notification.permission === "granted") {
            try {
                new Notification(`[${ticket.priority}] Tiket Baru: ${ticket.ticket_code}`, {
                    body: `${ticket.requester_name} (${ticket.department}):\n${ticket.subject}`,
                    icon: "/static/img/logo.png"
                });
            } catch (e) {}
        }
    }

    /**
     * Tambahkan item tiket ke dropdown notifikasi navbar
     */
    function appendTicketToDropdown(ticket, isNew = false) {
        if (!notificationList) return;
        if (emptyState) emptyState.classList.add('d-none');

        const safeCode = escapeHtml(ticket.ticket_code);
        const safeName = escapeHtml(ticket.requester_name);
        const safeDept = escapeHtml(ticket.department);
        const safeSubject = escapeHtml(ticket.subject);
        const safeTime = escapeHtml(ticket.time_ago || ticket.created_at_formatted || 'Baru saja');

        let badgeBg = 'bg-secondary';
        if (ticket.priority === 'Darurat') badgeBg = 'bg-danger text-white';
        else if (ticket.priority === 'Tinggi') badgeBg = 'bg-warning text-dark';
        else if (ticket.priority === 'Sedang') badgeBg = 'bg-primary text-white';

        const itemHtml = `
            <a href="/admin/tickets/${ticket.id}" class="notification-item p-3 ${isNew ? 'unread' : ''}">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <span class="badge ${badgeBg} smaller px-2 py-0.5 rounded-pill">${escapeHtml(ticket.priority)}</span>
                    <span class="text-muted smaller font-monospace">${safeCode}</span>
                </div>
                <div class="fw-bold text-dark small text-truncate mb-0.5" title="${safeSubject}">${safeSubject}</div>
                <div class="text-muted smaller d-flex justify-content-between align-items-center">
                    <span class="text-truncate" style="max-width: 200px;"><i class="bi bi-person me-1"></i>${safeName} (${safeDept})</span>
                    <span class="text-nowrap ms-2">${safeTime}</span>
                </div>
            </a>
        `;

        if (isNew) {
            notificationList.insertAdjacentHTML('afterbegin', itemHtml);
        } else {
            notificationList.insertAdjacentHTML('beforeend', itemHtml);
        }
    }

    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Siklus Polling & Sinkronisasi Berkala (Setiap 5 detik)
     */
    async function pollNotifications() {
        try {
            const url = `/admin/api/notifications/poll?since_id=${lastKnownTicketId}`;
            const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
            if (!res.ok) return;

            const data = await res.json();
            if (data.status !== 'ok') return;

            // Update metrik angka dashboard jika tersedia
            if (data.stats) {
                updateDashboardMetrics(data.stats, data.resolution_rate);
            }

            // 1. Jika ada tiket baru yang masuk (baik saat online maupun saat baru membuka sistem/login)
            if (data.has_new && data.new_tickets && data.new_tickets.length > 0) {
                // Update latest ID per akun teknisi
                lastKnownTicketId = data.latest_id;
                saveLastKnownTicketId(lastKnownTicketId);

                // Mainkan nada dering berulang hingga 10 KALI!
                startRepeatingTicketRingtone(MAX_RINGTONE_REPEATS);

                // Getar / Goyangkan ikon lonceng
                if (bellIcon) {
                    bellIcon.classList.add('bell-ringing');
                }

                // Naikkan counter badge
                unreadCount += data.new_tickets.length;
                if (countBadge) {
                    countBadge.textContent = unreadCount > 9 ? '9+' : unreadCount;
                    countBadge.classList.remove('d-none');
                }

                // Tampilkan Toast alert, masukkan ke dropdown, dan LANGSUNG MASUKKAN KE TABEL DASHBOARD & KELOLA TIKET
                for (let i = data.new_tickets.length - 1; i >= 0; i--) {
                    const ticket = data.new_tickets[i];
                    appendTicketToDropdown(ticket, true);
                    showTicketNotificationToast(ticket);
                    // Langsung masukkan ke tabel secara instan tanpa perlu refresh manual
                    insertTicketToDashboardTable(ticket);
                    insertTicketToTicketsPageTable(ticket);
                }
            } else if (data.latest_id && (!lastKnownTicketId || lastKnownTicketId === 0)) {
                // Inisialisasi awal tanpa tiket baru (hanya isi dropdown riwayat tanpa memicu dering suara)
                lastKnownTicketId = data.latest_id;
                saveLastKnownTicketId(lastKnownTicketId);

                if (data.recent_tickets && data.recent_tickets.length > 0) {
                    if (emptyState) emptyState.classList.add('d-none');
                    data.recent_tickets.forEach(ticket => appendTicketToDropdown(ticket, false));
                }
            }
        } catch (e) {
            // Silently ignore network drop during navigation
        }
    }

    /**
     * Memperbarui 4 Kartu Metrik Dashboard secara Real-Time
     */
    function updateDashboardMetrics(stats, resolutionRate) {
        const elTotal = document.getElementById('metricTotalTickets');
        if (elTotal && stats.total_tickets !== undefined) {
            elTotal.textContent = stats.total_tickets;
        }

        const elProgress = document.getElementById('metricInProgressTickets');
        if (elProgress && stats.in_progress_tickets !== undefined) {
            elProgress.textContent = stats.in_progress_tickets;
        }

        const elResolved = document.getElementById('metricResolvedTickets');
        if (elResolved && stats.resolved_tickets !== undefined) {
            elResolved.textContent = stats.resolved_tickets;
        }

        const elRate = document.getElementById('metricResolutionRate');
        if (elRate && resolutionRate !== undefined) {
            elRate.textContent = resolutionRate + '%';
        }

        const elBar = document.getElementById('metricResolutionProgressBar');
        if (elBar && resolutionRate !== undefined) {
            elBar.style.width = resolutionRate + '%';
        }
    }

    /**
     * Helper menghasilkan HTML badge kategori & kelompok (Hardware, Software, Jaringan & Akun, Lainnya)
     */
    function getCategoryBadgeData(category) {
        const safeCat = escapeHtml(category || '');
        const catLower = (category || '').toLowerCase();
        let catGroup = 'Lainnya';
        if (catLower.includes('jaringan') || catLower.includes('network') || catLower.includes('wifi') || catLower.includes('email') || catLower.includes('akun') || catLower.includes('akses') || catLower.includes('vpn') || catLower.includes('lan')) {
            catGroup = 'Jaringan & Akun';
        } else if (catLower.includes('hardware') || catLower.includes('komputer') || catLower.includes('monitor') || catLower.includes('printer') || catLower.includes('scanner') || catLower.includes('perangkat') || catLower.includes('laptop')) {
            catGroup = 'Hardware';
        } else if (catLower.includes('software') || catLower.includes('simrs') || catLower.includes('rme') || catLower.includes('bpjs') || catLower.includes('aplikasi') || catLower.includes('os') || catLower.includes('windows')) {
            catGroup = 'Software';
        }

        let catBadgeHtml = '';
        if (catGroup === 'Hardware') {
            catBadgeHtml = `<span class="badge badge-cat-hardware"><i class="bi bi-pc-display me-1"></i>Hardware</span>`;
        } else if (catGroup === 'Software') {
            catBadgeHtml = `<span class="badge badge-cat-software"><i class="bi bi-window-stack me-1"></i>Software</span>`;
        } else if (catGroup === 'Jaringan & Akun') {
            catBadgeHtml = `<span class="badge badge-cat-network"><i class="bi bi-router-fill me-1"></i>Jaringan & Akun</span>`;
        } else {
            catBadgeHtml = `<span class="badge badge-cat-other"><i class="bi bi-tag-fill me-1"></i>Lainnya</span>`;
        }
        const catSubtextHtml = (catGroup !== category && safeCat) ? `<span class="smaller text-muted text-truncate" style="max-width: 180px;" title="${safeCat}">${safeCat}</span>` : '';
        return { catBadgeHtml, catSubtextHtml };
    }

    /**
     * Memasukkan tiket baru langsung ke tabel "Tiket IT Terkini & Aksi Cepat" pada Dashboard
     */
    function insertTicketToDashboardTable(ticket) {
        const tbody = document.getElementById('dashboardTicketsTableBody');
        if (!tbody) return;

        // Cegah duplikasi jika baris sudah ada
        if (tbody.querySelector(`tr[data-ticket-id="${ticket.id}"]`)) return;

        // Hapus baris kosong ("Semua Tiket Antrean Telah Selesai") jika ada
        const emptyRow = document.getElementById('dashboardTicketsEmptyRow');
        if (emptyRow) {
            emptyRow.remove();
        }

        const safeCode = escapeHtml(ticket.ticket_code);
        const safeSubject = escapeHtml(ticket.subject);
        const safeName = escapeHtml(ticket.requester_name);
        const safeDept = escapeHtml(ticket.department);
        const safePriority = escapeHtml(ticket.priority);

        const { catBadgeHtml, catSubtextHtml } = getCategoryBadgeData(ticket.category);

        let priorityBadgeHtml = `<span class="badge badge-priority-sedang"><i class="bi bi-dash-circle me-1"></i>Sedang</span>`;
        if (ticket.priority === 'Darurat') {
            priorityBadgeHtml = `<span class="badge badge-priority-darurat animate-pulse"><i class="bi bi-exclamation-triangle-fill me-1"></i>Darurat</span>`;
        } else if (ticket.priority === 'Tinggi') {
            priorityBadgeHtml = `<span class="badge badge-priority-tinggi"><i class="bi bi-exclamation-circle me-1"></i>Tinggi</span>`;
        } else if (ticket.priority === 'Rendah') {
            priorityBadgeHtml = `<span class="badge badge-priority-rendah"><i class="bi bi-arrow-down-circle me-1"></i>Rendah</span>`;
        }

        const statusBadgeHtml = `<span class="badge badge-status-open font-monospace"><i class="bi bi-envelope-open me-1"></i>Open</span>`;

        const rowHtml = `
            <tr data-ticket-id="${ticket.id}" class="table-row-highlight">
                <td class="ps-4 font-monospace fw-bold text-primary">
                    <a href="/admin/tickets/${ticket.id}" class="text-decoration-none">${safeCode}</a>
                </td>
                <td>
                    <div class="fw-semibold text-dark text-truncate" style="max-width: 230px;" title="${safeSubject}">
                        ${safeSubject}
                    </div>
                </td>
                <td>
                    <div class="small fw-semibold text-dark">${safeName}</div>
                    <div class="smaller text-muted">${safeDept}</div>
                </td>
                <td>
                    <div class="d-flex flex-column align-items-start gap-1">
                        ${catBadgeHtml}
                        ${catSubtextHtml}
                    </div>
                </td>
                <td>${priorityBadgeHtml}</td>
                <td>${statusBadgeHtml}</td>
                <td>
                    <form action="/admin/tickets/quick-status" method="POST" class="d-inline-block">
                        <input type="hidden" name="ticket_id" value="${ticket.id}">
                        <input type="hidden" name="return_url" value="/admin/dashboard">
                        <select name="status" class="form-select form-select-sm rounded-pill" onchange="this.form.submit()" style="width: 135px; font-size: 0.8rem;">
                            <option value="Open" selected>Open</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Pending">Pending</option>
                            <option value="Resolved">Resolved</option>
                            <option value="Closed">Closed</option>
                        </select>
                    </form>
                </td>
                <td>
                    <span class="small fw-semibold text-secondary">
                        <i class="bi bi-person-gear me-1"></i>Belum ditugaskan
                    </span>
                </td>
                <td class="text-end pe-4">
                    <a href="/admin/tickets/${ticket.id}" class="btn btn-sm btn-primary rounded-pill px-3">
                        Kelola <i class="bi bi-chevron-right ms-1"></i>
                    </a>
                </td>
            </tr>
        `;

        tbody.insertAdjacentHTML('afterbegin', rowHtml);
    }

    /**
     * Memasukkan tiket baru langsung ke tabel pada halaman Kelola Tiket (/admin/tickets)
     */
    function insertTicketToTicketsPageTable(ticket) {
        const tbody = document.getElementById('ticketsTableBody');
        if (!tbody) return;

        if (tbody.querySelector(`tr[data-ticket-id="${ticket.id}"]`)) return;

        const safeCode = escapeHtml(ticket.ticket_code);
        const safeSubject = escapeHtml(ticket.subject);
        const safeName = escapeHtml(ticket.requester_name);
        const safeDept = escapeHtml(ticket.department);
        const safePriority = escapeHtml(ticket.priority);

        const { catBadgeHtml, catSubtextHtml } = getCategoryBadgeData(ticket.category);

        let priorityBadgeHtml = `<span class="badge badge-priority-sedang"><i class="bi bi-dash-circle me-1"></i>Sedang</span>`;
        if (ticket.priority === 'Darurat') {
            priorityBadgeHtml = `<span class="badge badge-priority-darurat animate-pulse"><i class="bi bi-exclamation-triangle-fill me-1"></i>Darurat</span>`;
        } else if (ticket.priority === 'Tinggi') {
            priorityBadgeHtml = `<span class="badge badge-priority-tinggi"><i class="bi bi-exclamation-circle me-1"></i>Tinggi</span>`;
        } else if (ticket.priority === 'Rendah') {
            priorityBadgeHtml = `<span class="badge badge-priority-rendah"><i class="bi bi-arrow-down-circle me-1"></i>Rendah</span>`;
        }

        const statusBadgeHtml = `<span class="badge badge-status-open font-monospace"><i class="bi bi-envelope-open me-1"></i>Open</span>`;

        const rowHtml = `
            <tr data-ticket-id="${ticket.id}" class="table-row-highlight ${ticket.priority === 'Darurat' ? 'table-danger-subtle' : ''}">
                <td class="ps-4 font-monospace fw-bold text-primary">
                    <a href="/admin/tickets/${ticket.id}" class="text-decoration-none">${safeCode}</a>
                </td>
                <td>
                    <div class="fw-semibold text-dark text-truncate" style="max-width: 220px;" title="${safeSubject}">
                        ${safeSubject}
                    </div>
                </td>
                <td>
                    <div class="small fw-semibold text-dark">${safeName}</div>
                    <div class="smaller text-muted">${safeDept}</div>
                </td>
                <td>
                    <div class="d-flex flex-column align-items-start gap-1">
                        ${catBadgeHtml}
                        ${catSubtextHtml}
                    </div>
                </td>
                <td>${priorityBadgeHtml}</td>
                <td>${statusBadgeHtml}</td>
                <td>
                    <form action="/admin/tickets/quick-status" method="POST" class="d-inline-block">
                        <input type="hidden" name="ticket_id" value="${ticket.id}">
                        <input type="hidden" name="return_url" value="/admin/tickets">
                        <select name="status" class="form-select form-select-sm rounded-pill" onchange="this.form.submit()" style="width: 130px; font-size: 0.8rem;">
                            <option value="Open" selected>Open</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Pending">Pending</option>
                            <option value="Resolved">Resolved</option>
                            <option value="Closed">Closed</option>
                        </select>
                    </form>
                </td>
                <td>
                    <span class="small fw-semibold text-secondary">
                        <i class="bi bi-person-gear me-1"></i>Belum ditugaskan
                    </span>
                </td>
                <td><span class="small text-muted">Baru saja</span></td>
                <td class="text-end pe-4 text-nowrap">
                    <div class="d-inline-flex gap-1 align-items-center">
                        <a href="/admin/tickets/${ticket.id}" class="btn btn-sm btn-primary rounded-pill px-3 shadow-xs" title="Lihat detail penanganan">
                            <i class="bi bi-eye me-1"></i>Detail
                        </a>
                    </div>
                </td>
            </tr>
        `;

        // Update counter di pill filter tanggal jika ada
        const todayCountBadge = document.querySelector('.date-count-today');
        if (todayCountBadge) {
            const curVal = parseInt(todayCountBadge.textContent) || 0;
            todayCountBadge.textContent = curVal + 1;
        }
        const allCountBadge = document.querySelector('.date-count-all');
        if (allCountBadge) {
            const curVal = parseInt(allCountBadge.textContent) || 0;
            allCountBadge.textContent = curVal + 1;
        }

        // Cek URL params: jika filter tanggal sedang aktif dan BUKAN "all" atau "today", jangan masukkan ke tabel tampilan hari lain
        const currentUrlParams = new URLSearchParams(window.location.search);
        const activeDateFilter = currentUrlParams.get('date_filter') || 'all';
        if (activeDateFilter !== 'all' && activeDateFilter !== 'today') {
            return;
        }

        // Hapus baris empty-state jika ada (misal "Belum ada tiket")
        const emptyRow = tbody.querySelector('tr td[colspan="10"] .text-muted');
        if (emptyRow) {
            const emptyTr = emptyRow.closest('tr');
            if (emptyTr && !emptyTr.classList.contains('date-group-header-row')) {
                emptyTr.remove();
            }
        }

        // Cari header pemisah "Hari Ini"
        const todayHeader = tbody.querySelector('.date-group-header-today');
        if (todayHeader) {
            // Update counter pada header hari ini
            const groupCountBadge = todayHeader.querySelector('.group-ticket-count-badge');
            if (groupCountBadge) {
                const match = groupCountBadge.textContent.match(/(\d+)/);
                const count = match ? parseInt(match[1]) + 1 : 1;
                groupCountBadge.innerHTML = `<i class="bi bi-ticket-detailed text-primary me-1"></i>${count} Tiket`;
            }
            // Sisipkan baris tiket tepat setelah header Hari Ini
            todayHeader.insertAdjacentHTML('afterend', rowHtml);
        } else {
            // Jika grup Hari Ini belum ada, buat header hari ini dan sisipkan di paling atas tabel
            const now = new Date();
            const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
            const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
            const dayName = days[now.getDay()];
            const dayNum = now.getDate();
            const monthName = months[now.getMonth()];
            const yearNum = now.getFullYear();
            const dateLabel = `Hari Ini — ${dayName}, ${dayNum} ${monthName} ${yearNum}`;

            const todayHeaderHtml = `
                <tr class="date-group-header-row date-group-header-today" style="background-color: #f1f5f9;">
                    <td colspan="10" class="py-2.5 px-4 border-top border-bottom">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-2">
                                <span class="badge bg-primary text-white shadow-xs rounded-pill px-3 py-1.5 fw-bold d-inline-flex align-items-center gap-1.5" style="font-size: 0.82rem;">
                                    <i class="bi bi-calendar3"></i>
                                    <span>${dateLabel}</span>
                                </span>
                                <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill font-monospace" style="font-size: 0.72rem;">
                                    <i class="bi bi-lightning-charge-fill me-1"></i>HARI INI
                                </span>
                            </div>
                            <span class="badge bg-white text-dark border shadow-2xs rounded-pill px-3 py-1.5 small fw-semibold group-ticket-count-badge">
                                <i class="bi bi-ticket-detailed text-primary me-1"></i>1 Tiket
                            </span>
                        </div>
                    </td>
                </tr>
            `;
            tbody.insertAdjacentHTML('afterbegin', todayHeaderHtml + rowHtml);
        }
    }

    // =========================================================
    // KONTROL AUTO-REFRESH SETIAP 5 DETIK DENGAN COUNTDOWN VISUAL
    // =========================================================
    let autoRefreshRemaining = 5;
    let autoRefreshInterval = null;
    let isPollingInProgress = false;

    function startAutoRefreshController() {
        if (autoRefreshInterval) {
            clearInterval(autoRefreshInterval);
        }

        autoRefreshRemaining = 5;
        updateAutoRefreshUI(autoRefreshRemaining, false);

        // Jalankan polling awal pertama kali
        pollNotifications();

        autoRefreshInterval = setInterval(async () => {
            autoRefreshRemaining--;

            if (autoRefreshRemaining <= 0) {
                // Tampilkan status memeriksa
                updateAutoRefreshUI(0, true);

                if (!isPollingInProgress) {
                    isPollingInProgress = true;
                    try {
                        await pollNotifications();
                    } catch (e) {
                    } finally {
                        isPollingInProgress = false;
                    }
                }

                // Reset countdown ke 5 detik
                autoRefreshRemaining = 5;
                setTimeout(() => {
                    updateAutoRefreshUI(autoRefreshRemaining, false);
                }, 500);
            } else {
                updateAutoRefreshUI(autoRefreshRemaining, false);
            }
        }, 1000);
    }

    function updateAutoRefreshUI(seconds, isChecking = false) {
        const badge = document.getElementById('autoRefreshCountdown');
        const statusText = document.getElementById('autoRefreshStatusText');
        const syncIcon = document.getElementById('syncSpinIcon');

        if (badge) {
            if (isChecking) {
                badge.className = 'badge bg-warning text-dark rounded-pill px-2 py-0.5 fw-bold animate-pulse';
                badge.textContent = 'Cek...';
            } else {
                badge.className = 'badge bg-success text-white rounded-pill px-2 py-0.5 fw-bold';
                badge.textContent = seconds + 's';
            }
        }

        if (statusText) {
            if (isChecking) {
                statusText.textContent = '• Memeriksa Tiket Masuk...';
            } else {
                statusText.textContent = '• Aktif (5s)';
            }
        }

        if (syncIcon) {
            if (isChecking) {
                syncIcon.style.display = 'inline-block';
                syncIcon.classList.add('rotate-spin');
            } else {
                syncIcon.classList.remove('rotate-spin');
            }
        }
    }

    // Fungsi pemicu refresh manual seketika jika tombol refresh diklik
    window.triggerImmediateSync = async function() {
        autoRefreshRemaining = 5;
        updateAutoRefreshUI(0, true);
        await pollNotifications();
        setTimeout(() => {
            updateAutoRefreshUI(autoRefreshRemaining, false);
        }, 300);
    };

    // Jalankan controller auto-refresh 5 detik
    startAutoRefreshController();
}

/**
 * Pengujian Kirim Pesan Agen Bot Telegram dari Modal Admin
 */
window.testTelegramNotification = async function() {
    const btn = document.getElementById('btnTestTelegram');
    const resultDiv = document.getElementById('telegramTestResult');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1.5" role="status" aria-hidden="true"></span> Mengirim Pesan...';
    }
    if (resultDiv) {
        resultDiv.className = 'alert alert-info py-2 px-3 small rounded-3 mb-3 d-flex align-items-center gap-2';
        resultDiv.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Menghubungi API Telegram...';
    }

    try {
        const res = await fetch('/admin/api/telegram/test', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json'
            }
        });
        const data = await res.json();
        if (resultDiv) {
            resultDiv.classList.remove('d-none', 'alert-info', 'alert-danger', 'alert-success');
            if (data.status === 'ok') {
                resultDiv.classList.add('alert-success');
                resultDiv.innerHTML = '<i class="bi bi-check-circle-fill fs-5 text-success me-2"></i> <div><strong>Berhasil Terkirim!</strong> ' + (data.message || 'Pesan uji coba telah terkirim ke Telegram Anda.') + '</div>';
            } else {
                resultDiv.classList.add('alert-danger');
                resultDiv.innerHTML = '<i class="bi bi-exclamation-triangle-fill fs-5 text-danger me-2"></i> <div><strong>Gagal Kirim:</strong> ' + (data.message || 'Terjadi kesalahan.') + '</div>';
            }
        }
    } catch (err) {
        if (resultDiv) {
            resultDiv.classList.remove('d-none', 'alert-info', 'alert-success');
            resultDiv.classList.add('alert-danger');
            resultDiv.innerHTML = '<i class="bi bi-exclamation-triangle-fill fs-5 text-danger me-2"></i> <div><strong>Koneksi Gagal:</strong> ' + err.message + '</div>';
        }
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-send-fill me-1"></i> Tes Kirim Pesan ke Telegram';
        }
    }
};

