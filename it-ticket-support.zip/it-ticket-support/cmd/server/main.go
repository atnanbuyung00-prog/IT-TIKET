package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"it-ticket-support/internal/database"
	"it-ticket-support/internal/handlers"
	"it-ticket-support/internal/middleware"
	"it-ticket-support/internal/telegram"
)

func main() {
	// Direktori database SQLite
	dbPath := "tickets.db"
	if customDB := os.Getenv("DB_PATH"); customDB != "" {
		dbPath = customDB
	}

	log.Printf("Menginisialisasi database SQLite di: %s", dbPath)
	db, err := database.InitDB(dbPath)
	if err != nil {
		log.Fatalf("Gagal inisialisasi database: %v", err)
	}
	defer db.Close()
	log.Println("Database SQLite dan tabel berhasil disiapkan.")

	// Inisialisasi Agen Notifikasi Telegram AiniDesk RS Mutiara Aini
	telegram.InitTelegramAgent()

	// Pastikan folder uploads ada
	_ = os.MkdirAll("web/static/uploads", 0755)

	mux := http.NewServeMux()

	// Static Files dengan Cache Browser & ETag (304 Not Modified untuk efisiensi bandwidth)
	staticFileServer := http.StripPrefix("/static/", http.FileServer(http.Dir("web/static")))
	staticAssets := middleware.StaticCacheMiddleware("web/static", staticFileServer)
	mux.HandleFunc("GET /static/{path...}", func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, "/") {
			http.NotFound(w, r)
			return
		}
		staticAssets.ServeHTTP(w, r)
	})

	// Rute Publik (Tanpa Login)
	mux.HandleFunc("GET /{$}", handlers.HomeHandler)
	mux.HandleFunc("GET /tickets/new", handlers.CreateTicketFormHandler)
	mux.HandleFunc("POST /tickets/new", handlers.SubmitTicketHandler)
	mux.HandleFunc("GET /tickets/success", handlers.TicketSuccessHandler)
	mux.HandleFunc("GET /tickets/track", handlers.TrackTicketHandler)
	mux.HandleFunc("POST /tickets/comment", handlers.AddPublicCommentHandler)

	// Rute Autentikasi
	mux.HandleFunc("GET /admin/login", handlers.LoginFormHandler)
	mux.HandleFunc("POST /admin/login", handlers.LoginSubmitHandler)
	mux.HandleFunc("GET /admin/logout", handlers.LogoutHandler)

	// Rute Portal Teknisi & Admin (Wajib Login)
	mux.HandleFunc("GET /admin", func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, "/admin/dashboard", http.StatusSeeOther)
	})
	mux.HandleFunc("GET /admin/dashboard", middleware.RequireAuth(handlers.AdminDashboardHandler))
	mux.HandleFunc("GET /admin/tickets", middleware.RequireTicketAccess(handlers.AdminTicketsHandler))
	mux.HandleFunc("GET /admin/tickets/{id}", middleware.RequireTicketAccess(handlers.AdminTicketDetailHandler))
	mux.HandleFunc("POST /admin/tickets/update", middleware.RequireTicketAccess(handlers.AdminUpdateTicketStatusHandler))
	mux.HandleFunc("POST /admin/tickets/quick-status", middleware.RequireTicketAccess(handlers.AdminQuickUpdateStatusHandler))
	mux.HandleFunc("POST /admin/tickets/comment", middleware.RequireTicketAccess(handlers.AdminAddTicketCommentHandler))

	// Rute Ubah & Hapus Tiket (Hanya diizinkan untuk Administrator IT)
	mux.HandleFunc("POST /admin/tickets/edit", middleware.RequireAdmin(handlers.AdminEditTicketHandler))
	mux.HandleFunc("POST /admin/tickets/delete", middleware.RequireAdmin(handlers.AdminDeleteTicketHandler))

	// Rute Unduh Laporan Excel
	mux.HandleFunc("GET /admin/export/excel", middleware.RequireAuth(handlers.AdminExportExcelHandler))

	// Rute Kelola Master Data (Kategori & Departemen)
	mux.HandleFunc("GET /admin/master", middleware.RequireMasterAccess(handlers.AdminMasterDataHandler))
	mux.HandleFunc("POST /admin/categories/create", middleware.RequireMasterAccess(handlers.AdminCreateCategoryHandler))
	mux.HandleFunc("POST /admin/categories/update", middleware.RequireMasterAccess(handlers.AdminUpdateCategoryHandler))
	mux.HandleFunc("POST /admin/categories/delete", middleware.RequireMasterAccess(handlers.AdminDeleteCategoryHandler))
	mux.HandleFunc("POST /admin/departments/create", middleware.RequireMasterAccess(handlers.AdminCreateDepartmentHandler))
	mux.HandleFunc("POST /admin/departments/update", middleware.RequireMasterAccess(handlers.AdminUpdateDepartmentHandler))
	mux.HandleFunc("POST /admin/departments/delete", middleware.RequireMasterAccess(handlers.AdminDeleteDepartmentHandler))

	// Rute Kelola Teknisi & Hak Akses
	mux.HandleFunc("GET /admin/technicians", middleware.RequireUserAccess(handlers.AdminTechniciansHandler))
	mux.HandleFunc("POST /admin/technicians/create", middleware.RequireUserAccess(handlers.AdminCreateTechnicianHandler))
	mux.HandleFunc("POST /admin/technicians/update", middleware.RequireUserAccess(handlers.AdminUpdateTechnicianHandler))
	mux.HandleFunc("POST /admin/technicians/delete", middleware.RequireUserAccess(handlers.AdminDeleteTechnicianHandler))

	// Rute Profil & Pengaturan Akun Pengguna (Ganti Profil, Username, dan Password)
	mux.HandleFunc("GET /admin/profile", middleware.RequireAuth(handlers.AdminProfileHandler))
	mux.HandleFunc("POST /admin/profile/update", middleware.RequireAuth(handlers.AdminUpdateProfileHandler))
	mux.HandleFunc("POST /admin/profile/password", middleware.RequireAuth(handlers.AdminChangePasswordHandler))

	// Rute API Polling Notifikasi & Nada Dering Tiket Baru Real-Time
	mux.HandleFunc("GET /admin/api/notifications/poll", middleware.RequireAuth(handlers.AdminPollNotificationsHandler))

	// Rute API Statistik Keamanan & Firewall
	mux.HandleFunc("GET /admin/api/security/stats", middleware.RequireAuth(handlers.AdminSecurityStatsHandler))

	// Rute API Agen Bot Telegram RS Mutiara Aini
	mux.HandleFunc("GET /admin/api/telegram/status", middleware.RequireAuth(handlers.AdminTelegramStatusHandler))
	mux.HandleFunc("POST /admin/api/telegram/test", middleware.RequireAuth(handlers.AdminTelegramTestHandler))

	// Pipeline Middleware Terpadu:
	// 1. MaxBodySizeMiddleware (Membatasi payload upload agar tidak boros bandwidth)
	// 2. FirewallMiddleware (WAF + Anti-DDoS Rate Limiter + Security Headers OWASP)
	// 3. GzipCompressionMiddleware (Kompresi Gzip untuk HTML/CSS/JS/JSON penghematan bandwidth 70-80%)
	// 4. AuthMiddleware (Autentikasi sesi teknisi & admin)
	pipeline := middleware.MaxBodySizeMiddleware(
		middleware.FirewallMiddleware(
			middleware.GzipCompressionMiddleware(
				middleware.AuthMiddleware(mux),
			),
		),
	)

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	addr := fmt.Sprintf(":%s", port)

	// Hardening konfigurasi server HTTP dengan timeout perlindungan Slowloris
	server := &http.Server{
		Addr:              addr,
		Handler:           pipeline,
		ReadTimeout:       15 * time.Second,
		ReadHeaderTimeout: 5 * time.Second, // Melindungi dari serangan Slowloris
		WriteTimeout:      30 * time.Second,
		IdleTimeout:       60 * time.Second,
		MaxHeaderBytes:    1 << 20, // Maksimal 1 MB header
	}

	log.Printf("======================================================")
	log.Printf(" AiniDesk - IT Support Ticket System - RS Mutiara Aini")
	log.Printf(" Server berjalan di: http://localhost:%s", port)
	log.Printf(" Firewall & WAF: AKTIF (Anti-DDoS, SQLi, XSS, Scanners)")
	log.Printf(" Bandwidth Optimizer: AKTIF (Gzip + 304 Browser Cache)")
	log.Printf("======================================================")

	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("Server berhenti karena error: %v", err)
	}
}
