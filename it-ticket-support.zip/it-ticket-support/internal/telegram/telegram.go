package telegram

import (
	"bytes"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"it-ticket-support/internal/database"
	"it-ticket-support/internal/models"
)

const (
	DefaultBotToken    = "9108076489:AAGyGQThGjhRwXvXH_zVGgOB1bFZ9a2aEoQ"
	DefaultBotUsername = "AiniDeskbot"
)

// HTTP Client dengan timeout wajar
var apiClient = &http.Client{
	Timeout: 35 * time.Second,
}

// Telegram API Types
type TelegramResponse struct {
	OK          bool            `json:"ok"`
	Result      json.RawMessage `json:"result"`
	ErrorCode   int             `json:"error_code,omitempty"`
	Description string          `json:"description,omitempty"`
}

type TelegramUpdate struct {
	UpdateID int              `json:"update_id"`
	Message  *TelegramMessage `json:"message,omitempty"`
}

type TelegramMessage struct {
	MessageID int          `json:"message_id"`
	From      TelegramUser `json:"from"`
	Chat      TelegramChat `json:"chat"`
	Date      int64        `json:"date"`
	Text      string       `json:"text"`
}

type TelegramUser struct {
	ID        int64  `json:"id"`
	IsBot     bool   `json:"is_bot"`
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
	Username  string `json:"username"`
}

type TelegramChat struct {
	ID        int64  `json:"id"`
	Type      string `json:"type"`
	Title     string `json:"title,omitempty"`
	Username  string `json:"username,omitempty"`
	FirstName string `json:"first_name,omitempty"`
	LastName  string `json:"last_name,omitempty"`
}

type SendMessageRequest struct {
	ChatID                string `json:"chat_id"`
	Text                  string `json:"text"`
	ParseMode             string `json:"parse_mode"`
	DisableWebPagePreview bool   `json:"disable_web_page_preview"`
}

// GetBotToken mengambil token bot yang aktif dari environment variable, database, atau default bawaan
func GetBotToken() string {
	if envToken := os.Getenv("TELEGRAM_BOT_TOKEN"); envToken != "" {
		return envToken
	}
	return database.GetTelegramSetting("bot_token", DefaultBotToken)
}

// IsBotEnabled memeriksa apakah notifikasi bot aktif
func IsBotEnabled() bool {
	return database.GetTelegramSetting("bot_enabled", "1") == "1"
}

// SendMessage mengirim pesan teks via Telegram Bot API (Format HTML)
func SendMessage(chatID string, text string) error {
	token := GetBotToken()
	if token == "" {
		return fmt.Errorf("token bot telegram belum disetel")
	}

	payload := SendMessageRequest{
		ChatID:                strings.TrimSpace(chatID),
		Text:                  text,
		ParseMode:             "HTML",
		DisableWebPagePreview: true,
	}

	bodyBytes, err := json.Marshal(payload)
	if err != nil {
		return err
	}

	url := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", token)
	resp, err := apiClient.Post(url, "application/json", bytes.NewBuffer(bodyBytes))
	if err != nil {
		return fmt.Errorf("gagal menghubungi API Telegram: %w", err)
	}
	defer resp.Body.Close()

	respBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("gagal membaca respon Telegram: %w", err)
	}

	var tgResp TelegramResponse
	if err := json.Unmarshal(respBytes, &tgResp); err != nil {
		return fmt.Errorf("format respon Telegram tidak valid: %w", err)
	}

	if !tgResp.OK {
		return fmt.Errorf("telegram API error (%d): %s", tgResp.ErrorCode, tgResp.Description)
	}

	return nil
}

// NotifyNewTicket mengirimkan notifikasi pesan ke semua teknisi / subscriber Telegram terdaftar
func NotifyNewTicket(ticket *models.Ticket) {
	if ticket == nil {
		return
	}

	if !IsBotEnabled() {
		log.Println("[Telegram Bot] Notifikasi dilewati karena bot dinonaktifkan di pengaturan.")
		return
	}

	// Ambil daftar chat_id aktif
	chatIDs, err := database.GetAllActiveTelegramSubscribers()
	if err != nil || len(chatIDs) == 0 {
		// Fallback ke chat_id awal jika tabel kosong
		chatIDs = []string{"5502041173"}
	}

	// Format icon dan label prioritas
	var priorityBadge string
	switch strings.ToLower(ticket.Priority) {
	case "darurat":
		priorityBadge = "🔴 <b>DARURAT</b>"
	case "tinggi":
		priorityBadge = "🟠 <b>TINGGI</b>"
	case "rendah":
		priorityBadge = "🟢 <b>RENDAH</b>"
	default:
		priorityBadge = "🔵 <b>SEDANG</b>"
	}

	// Format tanggal & jam
	timeFormatted := ticket.CreatedAt.Format("02 Jan 2006, 15:04 WIB")
	if ticket.CreatedAt.IsZero() {
		timeFormatted = time.Now().Format("02 Jan 2006, 15:04 WIB")
	}

	// Bersihkan karakter HTML dari input pengguna
	safeCode := html.EscapeString(ticket.TicketCode)
	safeRequester := html.EscapeString(ticket.RequesterName)
	safeDept := html.EscapeString(ticket.Department)
	safeCat := html.EscapeString(ticket.Category)
	safeSubject := html.EscapeString(ticket.Subject)
	safeDesc := html.EscapeString(ticket.Description)
	if safeDesc == "" || safeDesc == "-" {
		safeDesc = "<i>(Tidak ada deskripsi tambahan)</i>"
	}

	// Kontak pemohon
	contactInfo := ""
	if ticket.RequesterPhone != "" && ticket.RequesterPhone != "-" {
		contactInfo += fmt.Sprintf(" • 📞 %s", html.EscapeString(ticket.RequesterPhone))
	}
	if ticket.RequesterEmail != "" && ticket.RequesterEmail != "-" {
		contactInfo += fmt.Sprintf(" • ✉️ %s", html.EscapeString(ticket.RequesterEmail))
	}

	msg := fmt.Sprintf(`🚨 <b>PEMBERITAHUAN MASALAH / TIKET BARU!</b>
🏥 <b>RS Mutiara Aini — AiniDesk IT Helpdesk</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎫 <b>No. Tiket:</b> <code>%s</code>
👤 <b>Pemohon:</b> <b>%s</b>%s
🏢 <b>Unit / Ruangan:</b> <b>%s</b>
📂 <b>Kategori:</b> %s
⚡ <b>Prioritas:</b> %s

📌 <b>Subjek Kendala:</b>
<b>%s</b>

📝 <b>Rincian Masalah:</b>
%s

⏰ <b>Waktu Masuk:</b> %s
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>Mohon staf/teknisi IT yang bertugas segera memeriksa portal AiniDesk untuk menindaklanjuti kendala ini.</i>`,
		safeCode,
		safeRequester,
		contactInfo,
		safeDept,
		safeCat,
		priorityBadge,
		safeSubject,
		safeDesc,
		timeFormatted,
	)

	// Kirim ke semua subscriber
	for _, chatID := range chatIDs {
		cID := chatID
		go func() {
			if err := SendMessage(cID, msg); err != nil {
				log.Printf("[Telegram Bot] Gagal kirim notifikasi tiket ke Chat ID %s: %v", cID, err)
			} else {
				log.Printf("[Telegram Bot] Sukses mengirim notifikasi tiket %s ke Chat ID %s", safeCode, cID)
			}
		}()
	}
}

// SendTestNotification mengirim pesan uji coba ke chat ID tertentu
func SendTestNotification(targetChatID string) error {
	now := time.Now().Format("02 Jan 2006 15:04:05 WIB")
	msg := fmt.Sprintf(`✅ <b>UJI COBA KONEKSI BOT TELEGRAM BERHASIL</b>
🏥 <b>RS Mutiara Aini — AiniDesk IT Support</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Halo! Integrasi Agen Bot Telegram AiniDesk berjalan normal dan siap mengirimkan notifikasi instan setiap ada tiket masalah baru.

⏰ <b>Waktu Uji Coba:</b> %s
🆔 <b>Chat ID Anda:</b> <code>%s</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>Ketik /tiket untuk melihat tiket aktif atau /help untuk bantuan.</i>`, now, targetChatID)

	return SendMessage(targetChatID, msg)
}

// StartAgentLongPolling menjalankan Agen Bot Telegram secara interaktif (Background Long Polling)
func StartAgentLongPolling() {
	log.Println("[Telegram Bot] Agen Bot AiniDesk mulai berjalan dalam mode Long-Polling...")

	lastUpdateID := 0

	for {
		token := GetBotToken()
		if token == "" {
			time.Sleep(10 * time.Second)
			continue
		}

		pollURL := fmt.Sprintf("https://api.telegram.org/bot%s/getUpdates?offset=%d&timeout=25", token, lastUpdateID+1)
		resp, err := apiClient.Get(pollURL)
		if err != nil {
			// Cegah spam log jika jaringan offline sementara
			time.Sleep(5 * time.Second)
			continue
		}

		bodyBytes, err := io.ReadAll(resp.Body)
		resp.Body.Close()
		if err != nil {
			time.Sleep(3 * time.Second)
			continue
		}

		var tgResp TelegramResponse
		if err := json.Unmarshal(bodyBytes, &tgResp); err != nil || !tgResp.OK {
			time.Sleep(5 * time.Second)
			continue
		}

		var updates []TelegramUpdate
		if err := json.Unmarshal(tgResp.Result, &updates); err != nil {
			time.Sleep(5 * time.Second)
			continue
		}

		for _, update := range updates {
			if update.UpdateID >= lastUpdateID {
				lastUpdateID = update.UpdateID
			}

			if update.Message == nil || update.Message.Text == "" {
				continue
			}

			msg := update.Message
			chatIDStr := fmt.Sprintf("%d", msg.Chat.ID)
			senderName := strings.TrimSpace(msg.From.FirstName + " " + msg.From.LastName)
			if senderName == "" {
				senderName = msg.From.Username
			}
			username := msg.From.Username
			text := strings.TrimSpace(msg.Text)

			// Proses perintah / pesan masuk
			go handleIncomingMessage(chatIDStr, senderName, username, text)
		}

		// Istirahat singkat antar polling
		time.Sleep(1 * time.Second)
	}
}

// handleIncomingMessage memproses interaksi chat masuk dari pengguna Telegram
func handleIncomingMessage(chatID, name, username, text string) {
	log.Printf("[Telegram Bot] Pesan diterima dari %s (%s, ChatID: %s): %s", name, username, chatID, text)

	lowerText := strings.ToLower(text)

	// 1. Perintah /start
	if strings.HasPrefix(lowerText, "/start") {
		// Otomatis daftarkan subscriber ke database
		_ = database.RegisterTelegramSubscriber(chatID, name, username)

		reply := fmt.Sprintf(`👋 <b>Halo, %s!</b>

Selamat datang di <b>Agen Bot AiniDesk</b> — Layanan Notifikasi & IT Helpdesk <b>RS Mutiara Aini</b> 🏥🤖

✅ <b>Pendaftaran Berhasil!</b>
Akun Telegram Anda (ID: <code>%s</code>) telah otomatis terdaftar sebagai <b>penerima notifikasi masalah IT</b>.

Setiap kali staf poli, IGD, bangsal, atau unit kerja rumah sakit mengirim laporan kendala, Anda akan langsung menerima pesan peringatan ke sini agar cepat ditindaklanjuti!

📋 <b>Perintah yang dapat Anda gunakan:</b>
• /tiket — Cek daftar tiket kendala aktif saat ini
• /status — Ringkasan statistik tiket & progres hari ini
• /cek &lt;NomorTiket&gt; — Cek rincian tiket (cth: <code>/cek TCK-20261029-056B</code>)
• /id — Tampilkan Chat ID Telegram Anda
• /stop — Hentikan notifikasi sementara
• /help — Tampilkan menu bantuan ini

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>AiniDesk IT Support • Siap Melayani 24 Jam</i>`,
			html.EscapeString(name), chatID)

		_ = SendMessage(chatID, reply)
		return
	}

	// 2. Perintah /id
	if lowerText == "/id" {
		reply := fmt.Sprintf(`🆔 <b>Informasi Akun Telegram Anda:</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• <b>Chat ID:</b> <code>%s</code>
• <b>Nama:</b> %s
• <b>Username:</b> @%s
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>Gunakan Chat ID ini jika ingin menghubungkan dengan profil teknisi Anda di sistem.</i>`,
			chatID, html.EscapeString(name), html.EscapeString(username))
		_ = SendMessage(chatID, reply)
		return
	}

	// 3. Perintah /help atau /bantuan
	if lowerText == "/help" || lowerText == "/bantuan" {
		reply := `🤖 <b>Panduan Agen Bot AiniDesk RS Mutiara Aini:</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Bot ini bertindak sebagai agen otomatis yang menghubungkan staf rumah sakit dengan tim IT Support.

📋 <b>Daftar Perintah:</b>
1. /tiket — Menampilkan seluruh tiket kendala yang masih berstatus Open / In Progress.
2. /status — Rekapitulasi jumlah tiket, kendala selesai, dan tingkat penyelesaian.
3. /cek &lt;KODE_TIKET&gt; — Menampilkan riwayat dan rincian lengkap dari suatu tiket.
4. /id — Menampilkan Chat ID Telegram Anda.
5. /start — Mengaktifkan kembali langganan notifikasi tiket masuk.
6. /stop — Menonaktifkan sementara notifikasi tiket.

💡 <i>Tip: Anda juga dapat mengetik kode tiket secara langsung (misal: <code>TCK-20261029-056B</code>) untuk melihat statusnya.</i>`
		_ = SendMessage(chatID, reply)
		return
	}

	// 4. Perintah /stop atau /mute
	if lowerText == "/stop" || lowerText == "/mute" {
		_ = database.SetTelegramSubscriberActive(chatID, false)
		reply := `🔕 <b>Notifikasi Dinonaktifkan Sementara</b>
Anda tidak akan menerima pesan notifikasi tiket baru lagi.

Ketik /start kapan saja jika Anda ingin mengaktifkan kembali notifikasi.`
		_ = SendMessage(chatID, reply)
		return
	}

	// 5. Perintah /tiket atau /list
	if lowerText == "/tiket" || lowerText == "/list" || strings.Contains(lowerText, "tiket aktif") {
		openTickets, _ := database.GetTickets("Open", "", "", "")
		progressTickets, _ := database.GetTickets("In Progress", "", "", "")
		allActive := append(openTickets, progressTickets...)

		if len(allActive) == 0 {
			reply := `🎉 <b>Semua Bersih!</b>
Saat ini tidak ada tiket kendala aktif yang tertunda di RS Mutiara Aini. Semua masalah telah selesai ditangani tim IT. 👍`
			_ = SendMessage(chatID, reply)
			return
		}

		var sb strings.Builder
		sb.WriteString(fmt.Sprintf("📋 <b>Daftar Tiket Aktif (%d Kendala):</b>\n", len(allActive)))
		sb.WriteString("━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")

		// Batasi maksimal 10 tiket agar tidak kepanjangan
		limit := len(allActive)
		if limit > 10 {
			limit = 10
		}

		for i := 0; i < limit; i++ {
			t := allActive[i]
			statusIcon := "⏳"
			if t.Status == "In Progress" {
				statusIcon = "🛠️"
			}

			sb.WriteString(fmt.Sprintf("%d. %s <code>%s</code> [%s]\n", i+1, statusIcon, t.TicketCode, t.Status))
			sb.WriteString(fmt.Sprintf("   👤 <b>%s</b> (%s)\n", html.EscapeString(t.RequesterName), html.EscapeString(t.Department)))
			sb.WriteString(fmt.Sprintf("   📌 %s\n", html.EscapeString(t.Subject)))
			sb.WriteString(fmt.Sprintf("   ⚡ Prioritas: %s\n\n", t.Priority))
		}

		if len(allActive) > 10 {
			sb.WriteString(fmt.Sprintf("<i>...dan %d tiket aktif lainnya di portal web.</i>\n", len(allActive)-10))
		}
		sb.WriteString("━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")
		sb.WriteString("<i>Ketik /cek &lt;KODE_TIKET&gt; untuk melihat detailnya.</i>")

		_ = SendMessage(chatID, sb.String())
		return
	}

	// 6. Perintah /status atau /rekap
	if lowerText == "/status" || lowerText == "/rekap" || strings.Contains(lowerText, "rekap") {
		stats, err := database.GetDashboardStats()
		if err != nil || stats == nil {
			_ = SendMessage(chatID, "Gagal mengambil statistik sistem saat ini.")
			return
		}

		resRate := 0.0
		if stats.TotalTickets > 0 {
			resRate = float64(stats.ResolvedTickets+stats.ClosedTickets) / float64(stats.TotalTickets) * 100.0
		}

		reply := fmt.Sprintf(`📊 <b>Statistik Layanan IT RS Mutiara Aini:</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Total Tiket: <b>%d</b>
• Menunggu (Open): <b>%d</b> tiket
• Sedang Dikerjakan: <b>%d</b> tiket
• Selesai (Resolved): <b>%d</b> tiket
• Ditutup (Closed): <b>%d</b> tiket
• Tingkat Penyelesaian: <b>%.0f%%</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>AiniDesk Real-Time IT Support</i>`,
			stats.TotalTickets,
			stats.OpenTickets,
			stats.InProgressTickets,
			stats.ResolvedTickets,
			stats.ClosedTickets,
			resRate,
		)
		_ = SendMessage(chatID, reply)
		return
	}

	// 7. Perintah /cek <kode_tiket> atau jika pesan adalah nomor tiket TCK-...
	if strings.HasPrefix(lowerText, "/cek") || strings.HasPrefix(strings.ToUpper(text), "TCK-") {
		code := strings.TrimSpace(strings.TrimPrefix(text, "/cek"))
		code = strings.TrimSpace(code)

		if code == "" {
			_ = SendMessage(chatID, "Mohon sertakan nomor tiket yang ingin dicek. Contoh: <code>/cek TCK-20261029-056B</code>")
			return
		}

		ticket, err := database.GetTicketByCode(code)
		if err != nil || ticket == nil {
			_ = SendMessage(chatID, fmt.Sprintf("❌ Tiket dengan kode <code>%s</code> tidak ditemukan di sistem.", html.EscapeString(code)))
			return
		}

		techName := ticket.TechnicianName
		if techName == "" {
			techName = "Belum ditugaskan"
		}

		reply := fmt.Sprintf(`🎫 <b>Rincian Tiket:</b> <code>%s</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• <b>Status:</b> <b>%s</b>
• <b>Prioritas:</b> %s
• <b>Kategori:</b> %s
• <b>Pemohon:</b> %s (%s)
• <b>Teknisi:</b> %s
• <b>Waktu Dibuat:</b> %s

📌 <b>Subjek:</b>
<b>%s</b>

📝 <b>Deskripsi:</b>
%s
━━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
			ticket.TicketCode,
			ticket.Status,
			ticket.Priority,
			ticket.Category,
			html.EscapeString(ticket.RequesterName),
			html.EscapeString(ticket.Department),
			html.EscapeString(techName),
			ticket.CreatedAt.Format("02 Jan 2006 15:04 WIB"),
			html.EscapeString(ticket.Subject),
			html.EscapeString(ticket.Description),
		)
		_ = SendMessage(chatID, reply)
		return
	}

	// 8. Pesan sapaan / chat bebas dari pengguna -> Agen merespon secara cerdas
	if strings.Contains(lowerText, "halo") || strings.Contains(lowerText, "hai") || strings.Contains(lowerText, "assalamu") || lowerText == "p" || lowerText == "test" || lowerText == "tes" {
		reply := fmt.Sprintf(`👋 <b>Halo %s!</b>

Saya adalah <b>Agen Bot AiniDesk IT RS Mutiara Aini</b>. Sistem saat ini aktif dan siap memantau laporan kendala.

Ada yang bisa saya bantu?
• Ketik /tiket untuk melihat tiket kendala yang belum selesai.
• Ketik /status untuk melihat statistik hari ini.
• Ketik /help untuk panduan lengkap.`, html.EscapeString(name))
		_ = SendMessage(chatID, reply)
		return
	}

	// Default fallback response
	reply := fmt.Sprintf(`Halo %s! Saya telah menerima pesan Anda.
Untuk melihat tiket yang aktif ketik /tiket, atau ketik /help untuk daftar perintah yang tersedia.`, html.EscapeString(name))
	_ = SendMessage(chatID, reply)
}

// InitTelegramAgent menginisialisasi Agen Telegram dan menghubungkan hook tiket baru
func InitTelegramAgent() {
	// Daftarkan hook ke database agar setiap tiket baru memicu notifikasi Telegram
	database.OnTicketCreatedHook = NotifyNewTicket

	// Jalankan Long-Polling agent di background goroutine
	go StartAgentLongPolling()

	log.Printf("[Telegram Bot] Agen Bot AiniDesk (@%s) berhasil diinisialisasi.", DefaultBotUsername)
}
