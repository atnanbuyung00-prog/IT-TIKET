package middleware

import (
	"fmt"
	"log"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"time"
)

// SecurityEvent mencatat insiden keamanan yang dicegah oleh firewall
type SecurityEvent struct {
	Timestamp  time.Time `json:"timestamp"`
	ClientIP   string    `json:"client_ip"`
	Method     string    `json:"method"`
	Path       string    `json:"path"`
	ThreatType string    `json:"threat_type"`
	Details    string    `json:"details"`
}

// SecurityStats menampung ringkasan statistik keamanan & firewall sistem
type SecurityStats struct {
	FirewallActive     bool            `json:"firewall_active"`
	TotalRequests      int64           `json:"total_requests"`
	BlockedThreats     int64           `json:"blocked_threats"`
	BlockedByWAF       int64           `json:"blocked_by_waf"`
	BlockedByRateLimit int64           `json:"blocked_by_rate_limit"`
	RecentEvents       []SecurityEvent `json:"recent_events"`
	ActiveRateLimitIPs int             `json:"active_rate_limit_ips"`
}

// FirewallEngine adalah mesin WAF dan Rate Limiter terpadu
type FirewallEngine struct {
	mu                 sync.RWMutex
	totalRequests      int64
	blockedThreats     int64
	blockedWAF         int64
	blockedRateLimit   int64
	events             []SecurityEvent
	maxEvents          int
	globalRateLimit    *rateBucketManager
	sensitiveRateLimit *rateBucketManager
	blacklistIPs       map[string]time.Time
}

// rateBucket mencatat token per IP menggunakan algoritma Leaky Token Bucket
type rateBucket struct {
	tokens     float64
	lastUpdate time.Time
}

type rateBucketManager struct {
	mu         sync.Mutex
	buckets    map[string]*rateBucket
	rate       float64 // token yang ditambah per detik
	capacity   float64 // batas maksimal burst token
	lastPruned time.Time
}

func newRateBucketManager(ratePerMinute float64, burstCapacity float64) *rateBucketManager {
	return &rateBucketManager{
		buckets:    make(map[string]*rateBucket),
		rate:       ratePerMinute / 60.0,
		capacity:   burstCapacity,
		lastPruned: time.Now(),
	}
}

// allow memeriksa apakah permintaan dari IP tertentu diizinkan
func (m *rateBucketManager) allow(ip string) bool {
	m.mu.Lock()
	defer m.mu.Unlock()

	now := time.Now()

	// Pembersihan rutin setiap 5 menit untuk mencegah kebocoran memori
	if now.Sub(m.lastPruned) > 5*time.Minute {
		for k, b := range m.buckets {
			if now.Sub(b.lastUpdate) > 10*time.Minute {
				delete(m.buckets, k)
			}
		}
		m.lastPruned = now
	}

	bucket, exists := m.buckets[ip]
	if !exists {
		m.buckets[ip] = &rateBucket{
			tokens:     m.capacity - 1,
			lastUpdate: now,
		}
		return true
	}

	// Hitung token baru yang terisi sejak request terakhir
	elapsed := now.Sub(bucket.lastUpdate).Seconds()
	bucket.tokens += elapsed * m.rate
	if bucket.tokens > m.capacity {
		bucket.tokens = m.capacity
	}
	bucket.lastUpdate = now

	if bucket.tokens >= 1.0 {
		bucket.tokens -= 1.0
		return true
	}

	return false
}

// Global Firewall Instance
var GlobalFirewall = &FirewallEngine{
	maxEvents:          60,
	events:             make([]SecurityEvent, 0, 60),
	blacklistIPs:       make(map[string]time.Time),
	globalRateLimit:    newRateBucketManager(160, 50), // 160 req/menit untuk penjelajahan umum
	sensitiveRateLimit: newRateBucketManager(25, 8),   // 25 req/menit untuk login & submit tiket
}

// Pola RegEx untuk Web Application Firewall (WAF)
var (
	// SQL Injection Detector
	sqlInjectionRegex = regexp.MustCompile(`(?i)(union\s+(all\s+)?select|select\s+.*\s+from\b|insert\s+into\b|update\s+.*\s+set\b|delete\s+from\b|drop\s+(table|database)\b|information_schema|benchmark\s*\(|sleep\s*\(|waitfor\s+delay\b|--\s*|\/\*.*\*\/|'\s*(or|and)\s*['"]?[0-9a-zA-Z]+['"]?\s*=\s*['"]?[0-9a-zA-Z]+|xp_cmdshell)`)

	// Cross-Site Scripting (XSS) Detector
	xssRegex = regexp.MustCompile(`(?i)(<\s*script\b|javascript\s*:|vbscript\s*:|\bon(error|load|click|mouseover|submit|focus|keydown)\s*=|eval\s*\(|expression\s*\(|<\s*iframe\b|<\s*object\b|<\s*embed\b|<svg\/onload)`)

	// Path Traversal / LFI Detector
	pathTraversalRegex = regexp.MustCompile(`(?i)(\.\.\/|\.\.\\|%2e%2e%2f|%2e%2e\/|\/etc\/passwd|\/etc\/shadow|\/proc\/self|c:\\windows|win\.ini|boot\.ini)`)

	// Command Injection / RCE Detector
	commandInjectionRegex = regexp.MustCompile(`(?i)(;\s*(rm\s+-rf|wget\s|curl\s|bash\s+-c|powershell|cmd\.exe|cat\s+\/etc\/|nc\s+-e|system\s*\(|exec\s*\()|\bpowershell\.exe\b|\bcmd\.exe\b)`)

	// Bad Bots & Vulnerability Scanners
	badBotsRegex = regexp.MustCompile(`(?i)(sqlmap|nikto|acunetix|dirbuster|nmap|masscan|wpscan|gobuster|hydra|burpcollaborator|metasploit|havij|netsparker|zgrab)`)
)

// RecordEvent mencatat insiden keamanan ke memori
func (f *FirewallEngine) RecordEvent(ip, method, path, threatType, details string, isWAF bool) {
	f.mu.Lock()
	defer f.mu.Unlock()

	f.blockedThreats++
	if isWAF {
		f.blockedWAF++
	} else {
		f.blockedRateLimit++
	}

	event := SecurityEvent{
		Timestamp:  time.Now(),
		ClientIP:   ip,
		Method:     method,
		Path:       path,
		ThreatType: threatType,
		Details:    details,
	}

	f.events = append([]SecurityEvent{event}, f.events...)
	if len(f.events) > f.maxEvents {
		f.events = f.events[:f.maxEvents]
	}

	log.Printf("[FIREWALL ALERT] %s dicegah dari IP %s pada rute %s: %s", threatType, ip, path, details)
}

// GetStats mengembalikan ringkasan statistik keamanan untuk dashboard / API
func (f *FirewallEngine) GetStats() SecurityStats {
	f.mu.RLock()
	defer f.mu.RUnlock()

	f.globalRateLimit.mu.Lock()
	activeIPs := len(f.globalRateLimit.buckets)
	f.globalRateLimit.mu.Unlock()

	eventsCopy := make([]SecurityEvent, len(f.events))
	copy(eventsCopy, f.events)

	return SecurityStats{
		FirewallActive:     true,
		TotalRequests:      f.totalRequests,
		BlockedThreats:     f.blockedThreats,
		BlockedByWAF:       f.blockedWAF,
		BlockedByRateLimit: f.blockedRateLimit,
		RecentEvents:       eventsCopy,
		ActiveRateLimitIPs: activeIPs,
	}
}

// GetClientIP mengambil IP asli klien dengan memeriksa X-Forwarded-For dan RemoteAddr
func GetClientIP(r *http.Request) string {
	// Periksa header X-Forwarded-For (jika di belakang reverse proxy seperti Nginx / Cloudflare)
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		ips := strings.Split(xff, ",")
		if len(ips) > 0 {
			ip := strings.TrimSpace(ips[0])
			if net.ParseIP(ip) != nil {
				return ip
			}
		}
	}

	if xrip := r.Header.Get("X-Real-IP"); xrip != "" {
		if net.ParseIP(xrip) != nil {
			return xrip
		}
	}

	// Fallback ke RemoteAddr (buang port)
	ip, _, err := net.SplitHostPort(r.RemoteAddr)
	if err == nil && ip != "" {
		return ip
	}

	return r.RemoteAddr
}

// FirewallMiddleware adalah middleware terpadu: WAF, Rate Limiting, dan Security Headers
func FirewallMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		GlobalFirewall.mu.Lock()
		GlobalFirewall.totalRequests++
		GlobalFirewall.mu.Unlock()

		clientIP := GetClientIP(r)

		// 1. Terapkan HTTP Security Headers pada seluruh respons
		setSecurityHeaders(w)

		// 2. Periksa User-Agent berbahaya (Vulnerability Scanners)
		userAgent := r.UserAgent()
		if userAgent != "" && badBotsRegex.MatchString(userAgent) {
			GlobalFirewall.RecordEvent(clientIP, r.Method, r.URL.Path, "Vulnerability Scanner Blocked", "User-Agent: "+userAgent, true)
			renderSecurityBlock(w, http.StatusForbidden, "Akses Ditolak: Pola pemindai keamanan tidak diizinkan.")
			return
		}

		// 3. WAF: Analisis Path URL dan Query String terhadap serangan
		rawURL := r.URL.Path
		if r.URL.RawQuery != "" {
			rawURL += "?" + r.URL.RawQuery
		}

		// Decode URL untuk mendeteksi payload terenkripsi URL
		decodedURL, err := url.QueryUnescape(rawURL)
		if err != nil {
			decodedURL = rawURL
		}

		// Deteksi SQL Injection pada URI / Query String
		if sqlInjectionRegex.MatchString(decodedURL) {
			GlobalFirewall.RecordEvent(clientIP, r.Method, r.URL.Path, "SQL Injection (SQLi)", "Payload pada query/URL", true)
			renderSecurityBlock(w, http.StatusForbidden, "Akses Ditolak: Upaya SQL Injection terdeteksi oleh Firewall.")
			return
		}

		// Deteksi Cross-Site Scripting (XSS) pada URI / Query String
		if xssRegex.MatchString(decodedURL) {
			GlobalFirewall.RecordEvent(clientIP, r.Method, r.URL.Path, "Cross-Site Scripting (XSS)", "Payload skrip berbahaya pada URL", true)
			renderSecurityBlock(w, http.StatusForbidden, "Akses Ditolak: Kode skrip berbahaya (XSS) terdeteksi.")
			return
		}

		// Deteksi Path Traversal / LFI
		if pathTraversalRegex.MatchString(decodedURL) {
			GlobalFirewall.RecordEvent(clientIP, r.Method, r.URL.Path, "Path Traversal (LFI)", "Upaya akses direktori sistem", true)
			renderSecurityBlock(w, http.StatusForbidden, "Akses Ditolak: Path traversal ilegal terdeteksi.")
			return
		}

		// Deteksi Command Injection
		if commandInjectionRegex.MatchString(decodedURL) {
			GlobalFirewall.RecordEvent(clientIP, r.Method, r.URL.Path, "Command Injection (RCE)", "Upaya eksekusi perintah shell", true)
			renderSecurityBlock(w, http.StatusForbidden, "Akses Ditolak: Upaya Command Injection terdeteksi.")
			return
		}

		// 4. Rate Limiter (Anti-DDoS & Brute Force Protection)
		isSensitiveRoute := r.URL.Path == "/admin/login" ||
			r.URL.Path == "/tickets/new" ||
			r.URL.Path == "/admin/profile/password"

		if isSensitiveRoute {
			if !GlobalFirewall.sensitiveRateLimit.allow(clientIP) {
				GlobalFirewall.RecordEvent(clientIP, r.Method, r.URL.Path, "Rate Limit Sensitive Route Exceeded", "Frekuensi percobaan melebihi batas aman", false)
				w.Header().Set("Retry-After", "60")
				renderSecurityBlock(w, http.StatusTooManyRequests, "Akses Dibatasi Sementara: Terlalu banyak permintaan pada fitur penting. Silakan coba 1 menit lagi.")
				return
			}
		} else {
			if !GlobalFirewall.globalRateLimit.allow(clientIP) {
				GlobalFirewall.RecordEvent(clientIP, r.Method, r.URL.Path, "Global Rate Limit Exceeded", "Volume request per menit melampaui batas", false)
				w.Header().Set("Retry-After", "60")
				renderSecurityBlock(w, http.StatusTooManyRequests, "Akses Dibatasi Sementara: Terlalu banyak permintaan dari IP Anda. Silakan tunggu sejenak.")
				return
			}
		}

		next.ServeHTTP(w, r)
	})
}

// setSecurityHeaders memasang konfigurasi header keamanan terstandarisasi OWASP
func setSecurityHeaders(w http.ResponseWriter) {
	headers := w.Header()

	// Cegah MIME type sniffing
	headers.Set("X-Content-Type-Options", "nosniff")

	// Cegah Clickjacking (frame hanya diizinkan dari origin yang sama)
	headers.Set("X-Frame-Options", "SAMEORIGIN")

	// Proteksi XSS bawaan browser lama
	headers.Set("X-XSS-Protection", "1; mode=block")

	// Kendalikan informasi perujuk (referrer)
	headers.Set("Referrer-Policy", "strict-origin-when-cross-origin")

	// Blokir akses perangkat keras yang tidak relevan
	headers.Set("Permissions-Policy", "camera=(), microphone=(), geolocation=()")

	// Larang Adobe Flash / PDF cross domain policy
	headers.Set("X-Permitted-Cross-Domain-Policies", "none")

	// Content Security Policy (CSP) aman yang mengizinkan CDN Bootstrap, Google Fonts, dan Chart.js
	csp := "default-src 'self'; " +
		"script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; " +
		"style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; " +
		"font-src 'self' https://fonts.gstatic.com https://cdn.jsdelivr.net data:; " +
		"img-src 'self' data: blob:; " +
		"media-src 'self' data:; " +
		"connect-src 'self'; " +
		"frame-ancestors 'self';"

	headers.Set("Content-Security-Policy", csp)
}

// renderSecurityBlock menampilkan halaman peringatan keamanan yang profesional
func renderSecurityBlock(w http.ResponseWriter, statusCode int, message string) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(statusCode)

	html := fmt.Sprintf(`<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Keamanan - Permintaan Diblokir</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body { background: #0f172a; color: #f8fafc; font-family: system-ui, -apple-system, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; }
        .security-card { background: #1e293b; border: 1px solid #334155; border-radius: 1.25rem; max-width: 520px; width: 100%%; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5); }
    </style>
</head>
<body>
    <div class="security-card p-4 p-md-5 text-center">
        <div class="mb-4">
            <span class="d-inline-flex align-items-center justify-content-center bg-danger-subtle text-danger rounded-circle p-3" style="width: 72px; height: 72px;">
                <i class="bi bi-shield-x fs-1"></i>
            </span>
        </div>
        <h4 class="fw-bold mb-2 text-white">Sistem Keamanan Firewall IT</h4>
        <span class="badge bg-danger px-3 py-1.5 rounded-pill mb-3 font-monospace">STATUS: BLOCKED (%d)</span>
        <p class="text-secondary mb-4">%s</p>
        <div class="bg-dark p-3 rounded-3 text-start small font-monospace text-muted mb-4 border border-secondary border-opacity-25">
            <div><strong class="text-light">Protokol:</strong> WAF & Rate Limiter Go Active</div>
            <div><strong class="text-light">Waktu Insiden:</strong> %s WIB</div>
            <div><strong class="text-light">Keamanan:</strong> Dilindungi oleh OWASP Hardening Suite</div>
        </div>
        <div class="d-flex gap-2 justify-content-center">
            <a href="/" class="btn btn-primary rounded-pill px-4 fw-semibold"><i class="bi bi-house-door me-1"></i> Kembali ke Beranda</a>
        </div>
    </div>
</body>
</html>`, statusCode, message, time.Now().Format("02 Jan 2006 15:04:05"))

	_, _ = w.Write([]byte(html))
}
