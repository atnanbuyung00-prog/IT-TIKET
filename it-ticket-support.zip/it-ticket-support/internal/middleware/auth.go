package middleware

import (
	"context"
	"net/http"

	"it-ticket-support/internal/database"
	"it-ticket-support/internal/models"
)

type contextKey string

const UserContextKey = contextKey("user")

// AuthMiddleware memeriksa apakah ada session token aktif di cookie
func AuthMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		cookie, err := r.Cookie("session_token")
		if err == nil && cookie.Value != "" {
			sess, err := database.GetSession(cookie.Value)
			if err == nil && sess != nil && sess.User != nil {
				ctx := context.WithValue(r.Context(), UserContextKey, sess.User)
				next.ServeHTTP(w, r.WithContext(ctx))
				return
			}
		}
		next.ServeHTTP(w, r)
	})
}

// RequireAuth mewajibkan user sudah login sebagai teknisi/admin
func RequireAuth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user := GetUserFromContext(r)
		if user == nil {
			http.Redirect(w, r, "/admin/login?next="+r.URL.Path, http.StatusSeeOther)
			return
		}
		next(w, r)
	}
}

// RequireAdmin mewajibkan user memiliki role 'admin'
func RequireAdmin(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user := GetUserFromContext(r)
		if user == nil {
			http.Redirect(w, r, "/admin/login?next="+r.URL.Path, http.StatusSeeOther)
			return
		}
		if user.Role != "admin" {
			http.Error(w, "Akses ditolak: Hanya Administrator yang berhak mengakses halaman ini.", http.StatusForbidden)
			return
		}
		next(w, r)
	}
}

// RequireTicketAccess memeriksa apakah user memiliki hak akses mengelola tiket
func RequireTicketAccess(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user := GetUserFromContext(r)
		if user == nil {
			http.Redirect(w, r, "/admin/login?next="+r.URL.Path, http.StatusSeeOther)
			return
		}
		if !user.HasTicketAccess() {
			http.Error(w, "Akses ditolak: Anda tidak memiliki hak akses untuk mengelola tiket.", http.StatusForbidden)
			return
		}
		next(w, r)
	}
}

// RequireMasterAccess memeriksa apakah user memiliki hak akses mengelola Kategori & Departemen
func RequireMasterAccess(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user := GetUserFromContext(r)
		if user == nil {
			http.Redirect(w, r, "/admin/login?next="+r.URL.Path, http.StatusSeeOther)
			return
		}
		if !user.HasMasterAccess() {
			http.Error(w, "Akses ditolak: Anda tidak memiliki hak akses untuk mengelola Master Data (Kategori & Departemen).", http.StatusForbidden)
			return
		}
		next(w, r)
	}
}

// RequireUserAccess memeriksa apakah user memiliki hak akses mengelola akun teknisi
func RequireUserAccess(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user := GetUserFromContext(r)
		if user == nil {
			http.Redirect(w, r, "/admin/login?next="+r.URL.Path, http.StatusSeeOther)
			return
		}
		if !user.HasUserAccess() {
			http.Error(w, "Akses ditolak: Anda tidak memiliki hak akses untuk mengelola akun teknisi.", http.StatusForbidden)
			return
		}
		next(w, r)
	}
}

// GetUserFromContext mengambil user yang sedang login dari context
func GetUserFromContext(r *http.Request) *models.User {
	val := r.Context().Value(UserContextKey)
	if val == nil {
		return nil
	}
	user, ok := val.(*models.User)
	if !ok {
		return nil
	}
	return user
}
