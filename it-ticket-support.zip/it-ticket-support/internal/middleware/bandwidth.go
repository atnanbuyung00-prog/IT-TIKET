package middleware

import (
	"compress/gzip"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// gzipWriterPool menggunakan sync.Pool untuk efisiensi memori dan CPU
var gzipWriterPool = sync.Pool{
	New: func() interface{} {
		gz, _ := gzip.NewWriterLevel(io.Discard, gzip.BestSpeed)
		return gz
	},
}

// gzipResponseWriter membungkus http.ResponseWriter untuk mengompresi payload secara real-time
type gzipResponseWriter struct {
	http.ResponseWriter
	writer       *gzip.Writer
	wroteHeader  bool
	headerStatus int
	isCompress   bool
}

func (w *gzipResponseWriter) WriteHeader(status int) {
	if w.wroteHeader {
		return
	}
	w.headerStatus = status
	w.wroteHeader = true

	// Jangan kompresi untuk status respons tertentu (seperti 304 Not Modified, 204 No Content)
	if status == http.StatusNoContent || status == http.StatusNotModified {
		w.isCompress = false
		w.ResponseWriter.WriteHeader(status)
		return
	}

	// Periksa Content-Type apakah layak dikompresi
	contentType := w.Header().Get("Content-Type")
	if contentType == "" || shouldCompress(contentType) {
		w.isCompress = true
		w.Header().Set("Content-Encoding", "gzip")
		w.Header().Set("Vary", "Accept-Encoding")
		w.Header().Del("Content-Length") // Content-length berubah karena kompresi
	} else {
		w.isCompress = false
	}

	w.ResponseWriter.WriteHeader(status)
}

func (w *gzipResponseWriter) Write(b []byte) (int, error) {
	if !w.wroteHeader {
		// Deteksi Content-Type awal jika belum diset
		if w.Header().Get("Content-Type") == "" {
			w.Header().Set("Content-Type", http.DetectContentType(b))
		}
		w.WriteHeader(http.StatusOK)
	}

	if w.isCompress {
		return w.writer.Write(b)
	}
	return w.ResponseWriter.Write(b)
}

// Flush mengimplementasikan interface http.Flusher
func (w *gzipResponseWriter) Flush() {
	if w.isCompress && w.writer != nil {
		_ = w.writer.Flush()
	}
	if flusher, ok := w.ResponseWriter.(http.Flusher); ok {
		flusher.Flush()
	}
}

// shouldCompress memeriksa apakah MIME type cocok untuk dikompresi gzip
func shouldCompress(contentType string) bool {
	ct := strings.ToLower(contentType)
	compressTypes := []string{
		"text/html",
		"text/css",
		"text/plain",
		"text/javascript",
		"text/xml",
		"application/javascript",
		"application/x-javascript",
		"application/json",
		"application/xml",
		"application/xhtml+xml",
		"image/svg+xml",
	}

	for _, t := range compressTypes {
		if strings.Contains(ct, t) {
			return true
		}
	}
	return false
}

// GzipCompressionMiddleware mengompresi konten teks, JSON, HTML, CSS, JS hingga 70-80% penghematan bandwidth
func GzipCompressionMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Periksa apakah browser / client mendukung gzip
		if !strings.Contains(r.Header.Get("Accept-Encoding"), "gzip") {
			next.ServeHTTP(w, r)
			return
		}

		// Jangan kompresi file binary/gambar/suara yang sudah terkompresi secara native
		path := strings.ToLower(r.URL.Path)
		if strings.HasSuffix(path, ".png") ||
			strings.HasSuffix(path, ".jpg") ||
			strings.HasSuffix(path, ".jpeg") ||
			strings.HasSuffix(path, ".gif") ||
			strings.HasSuffix(path, ".webp") ||
			strings.HasSuffix(path, ".wav") ||
			strings.HasSuffix(path, ".mp3") ||
			strings.HasSuffix(path, ".zip") ||
			strings.HasSuffix(path, ".pdf") ||
			strings.HasSuffix(path, ".xlsx") {
			next.ServeHTTP(w, r)
			return
		}

		gz := gzipWriterPool.Get().(*gzip.Writer)
		defer gzipWriterPool.Put(gz)

		gz.Reset(w)
		defer gz.Close()

		gzw := &gzipResponseWriter{
			ResponseWriter: w,
			writer:         gz,
			headerStatus:   http.StatusOK,
			isCompress:     true,
		}

		next.ServeHTTP(gzw, r)
	})
}

// StaticCacheMiddleware menyetel header Cache-Control, ETag, dan mendukung 304 Not Modified untuk aset statis
func StaticCacheMiddleware(staticDir string, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Bersihkan path relatif untuk mencegah directory traversal
		relPath := strings.TrimPrefix(r.URL.Path, "/static/")
		fullPath := filepath.Join(staticDir, filepath.Clean(relPath))

		fileInfo, err := os.Stat(fullPath)
		if err == nil && !fileInfo.IsDir() {
			// Buat ETag berbasis ukuran dan modifikasi waktu
			eTag := fmt.Sprintf(`W/"%x-%x"`, fileInfo.Size(), fileInfo.ModTime().UnixNano())
			w.Header().Set("ETag", eTag)

			// Cek If-None-Match untuk respons instan 304 (0 KB bandwidth transfer)
			if match := r.Header.Get("If-None-Match"); match != "" && strings.Contains(match, eTag) {
				w.WriteHeader(http.StatusNotModified)
				return
			}

			// Cek If-Modified-Since
			if since := r.Header.Get("If-Modified-Since"); since != "" {
				if t, err := time.Parse(http.TimeFormat, since); err == nil {
					if !fileInfo.ModTime().After(t.Add(1 * time.Second)) {
						w.WriteHeader(http.StatusNotModified)
						return
					}
				}
			}

			// Berikan cache browser 7 hari untuk aset statis (CSS, JS, Fonts, Images)
			w.Header().Set("Cache-Control", "public, max-age=604800, stale-while-revalidate=86400")
			w.Header().Set("Last-Modified", fileInfo.ModTime().UTC().Format(http.TimeFormat))
		}

		next.ServeHTTP(w, r)
	})
}

// MaxBodySizeMiddleware membatasi ukuran request body agar tidak menghabiskan bandwidth server
func MaxBodySizeMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Batas 15 MB untuk form tiket yang mendukung upload lampiran gambar/dokumen
		maxBytes := int64(2 << 20) // Default 2 MB untuk API & form biasa
		if r.URL.Path == "/tickets/new" || r.URL.Path == "/admin/tickets/new" {
			maxBytes = 15 << 20 // 15 MB untuk upload file lampiran tiket
		}

		r.Body = http.MaxBytesReader(w, r.Body, maxBytes)
		next.ServeHTTP(w, r)
	})
}
