package models

import (
	"time"
)

type User struct {
	ID               int64     `json:"id"`
	Name             string    `json:"name"`
	Username         string    `json:"username"`
	Email            string    `json:"email"`
	Password         string    `json:"-"`
	Role             string    `json:"role"` // "admin" or "technician"
	Phone            string    `json:"phone"`
	TelegramChatID   string    `json:"telegram_chat_id"`
	CanManageTickets bool      `json:"can_manage_tickets"` // Izin kelola status & penugasan tiket
	CanManageMaster  bool      `json:"can_manage_master"`  // Izin kelola Kategori & Departemen
	CanManageUsers   bool      `json:"can_manage_users"`   // Izin kelola akun teknisi
	CreatedAt        time.Time `json:"created_at"`
}

func (u *User) IsAdmin() bool {
	if u == nil {
		return false
	}
	return u.Role == "admin"
}

func (u *User) HasTicketAccess() bool {
	if u == nil {
		return false
	}
	return u.Role == "admin" || u.CanManageTickets
}

func (u *User) HasMasterAccess() bool {
	if u == nil {
		return false
	}
	return u.Role == "admin" || u.CanManageMaster
}

func (u *User) HasUserAccess() bool {
	if u == nil {
		return false
	}
	return u.Role == "admin" || u.CanManageUsers
}

type Category struct {
	ID            int64     `json:"id"`
	Name          string    `json:"name"`
	Section       string    `json:"section"`        // Hardware, Software, Jaringan & Akun, Lainnya
	CategoryGroup string    `json:"category_group"` // alias for section
	Description   string    `json:"description"`
	TicketCount   int       `json:"ticket_count"`
	CreatedAt     time.Time `json:"created_at"`
}

type Department struct {
	ID          int64     `json:"id"`
	Name        string    `json:"name"`
	Description string    `json:"description"`
	TicketCount int       `json:"ticket_count"`
	CreatedAt   time.Time `json:"created_at"`
}

type Ticket struct {
	ID             int64          `json:"id"`
	TicketCode     string         `json:"ticket_code"`
	RequesterName  string         `json:"requester_name"`
	RequesterEmail string         `json:"requester_email"`
	RequesterPhone string         `json:"requester_phone"`
	Department     string         `json:"department"`
	Category       string         `json:"category"`
	CategoryGroup  string         `json:"category_group"` // Hardware, Software, Jaringan & Akun, Lainnya
	Priority       string         `json:"priority"`       // Rendah, Sedang, Tinggi, Darurat
	Subject        string         `json:"subject"`
	Description    string         `json:"description"`
	Attachment     string         `json:"attachment"`
	Status         string         `json:"status"` // Open, In Progress, Pending, Resolved, Closed
	AssignedTo     *int64         `json:"assigned_to"`
	TechnicianName string         `json:"technician_name"`
	CreatedAt      time.Time      `json:"created_at"`
	UpdatedAt      time.Time      `json:"updated_at"`
	ResolvedAt     *time.Time     `json:"resolved_at"`
	Updates        []TicketUpdate `json:"updates,omitempty"`
}

type TicketUpdate struct {
	ID         int64     `json:"id"`
	TicketID   int64     `json:"ticket_id"`
	UserID     *int64    `json:"user_id"`
	SenderName string    `json:"sender_name"`
	SenderType string    `json:"sender_type"` // "requester", "technician", "system"
	Message    string    `json:"message"`
	IsInternal bool      `json:"is_internal"`
	Attachment string    `json:"attachment"`
	CreatedAt  time.Time `json:"created_at"`
}

type Session struct {
	Token     string    `json:"token"`
	UserID    int64     `json:"user_id"`
	User      *User     `json:"user"`
	CreatedAt time.Time `json:"created_at"`
	ExpiresAt time.Time `json:"expires_at"`
}

type DashboardStats struct {
	TotalTickets      int `json:"total_tickets"`
	OpenTickets       int `json:"open_tickets"`
	InProgressTickets int `json:"in_progress_tickets"`
	PendingTickets    int `json:"pending_tickets"`
	ResolvedTickets   int `json:"resolved_tickets"`
	ClosedTickets     int `json:"closed_tickets"`
	UrgentTickets     int `json:"urgent_tickets"`
}

type ChartItem struct {
	Label string `json:"label"`
	Count int    `json:"count"`
}

type TimelineItem struct {
	Date     string `json:"date"`
	Incoming int    `json:"incoming"`
	Resolved int    `json:"resolved"`
}

type AnalyticsData struct {
	Period         string         `json:"period"` // "weekly", "monthly", "yearly", "all"
	PeriodLabel    string         `json:"period_label"`
	TotalTickets   int            `json:"total_tickets"`
	ResolvedRate   float64        `json:"resolved_rate"`
	TopCategories  []ChartItem    `json:"top_categories"`
	TopDepartments []ChartItem    `json:"top_departments"`
	StatusCounts   []ChartItem    `json:"status_counts"`
	PriorityCounts []ChartItem    `json:"priority_counts"`
	Timeline       []TimelineItem `json:"timeline"`
}

type TicketDateGroup struct {
	DateKey       string   `json:"date_key"`       // "2026-10-27"
	DateLabel     string   `json:"date_label"`     // "Hari Ini — Selasa, 27 Oktober 2026"
	FormattedDate string   `json:"formatted_date"` // "Selasa, 27 Oktober 2026"
	IsToday       bool     `json:"is_today"`
	IsYesterday   bool     `json:"is_yesterday"`
	TicketCount   int      `json:"ticket_count"`
	Tickets       []Ticket `json:"tickets"`
}

type TelegramSubscriber struct {
	ID           int64     `json:"id"`
	ChatID       string    `json:"chat_id"`
	Name         string    `json:"name"`
	Username     string    `json:"username"`
	IsActive     bool      `json:"is_active"`
	CreatedAt    time.Time `json:"created_at"`
	UpdatedAt    time.Time `json:"updated_at"`
}

type TelegramConfig struct {
	BotToken    string               `json:"bot_token"`
	BotUsername string               `json:"bot_username"`
	BotEnabled  bool                 `json:"bot_enabled"`
	Subscribers []TelegramSubscriber `json:"subscribers"`
}


