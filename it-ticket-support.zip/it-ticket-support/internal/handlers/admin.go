package handlers

import (
	"fmt"
	"net/http"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/bcrypt"

	"it-ticket-support/internal/database"
	"it-ticket-support/internal/middleware"
	"it-ticket-support/internal/models"
	"it-ticket-support/internal/telegram"
)

// AdminDashboardHandler menampilkan dashboard statistik dan tiket terbaru
// AdminDashboardHandler menampilkan dashboard statistik, grafik tren, kendala terbanyak, dan tiket terbaru
func AdminDashboardHandler(w http.ResponseWriter, r *http.Request) {
	stats, err := database.GetDashboardStats()
	if err != nil {
		http.Error(w, "Gagal mengambil statistik: "+err.Error(), http.StatusInternalServerError)
		return
	}

	period := r.URL.Query().Get("period")
	if period == "" {
		period = "monthly" // Default periode bulanan
	}

	analytics, err := database.GetAnalyticsData(period)
	if err != nil {
		http.Error(w, "Gagal mengambil analitik grafik: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// Hanya tampilkan tiket aktif (Open, In Progress, Pending). Tiket yang sudah selesai (Resolved / Closed) otomatis tidak muncul di dashboard, namun tetap tersimpan di Kelola Tiket.
	activeTickets, err := database.GetActiveTicketsForDashboard(10)
	if err != nil {
		http.Error(w, "Gagal mengambil tiket antrean aktif: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// Hitung persentase resolusi
	var resRate float64
	if stats.TotalTickets > 0 {
		resRate = float64(stats.ResolvedTickets+stats.ClosedTickets) / float64(stats.TotalTickets) * 100.0
	}

	RenderTemplate(w, r, "admin/dashboard.html", PageData{
		Title:     "Dashboard & Analisis Helpdesk IT",
		ActiveNav: "admin_dashboard",
		Data: map[string]interface{}{
			"Stats":          stats,
			"Analytics":      analytics,
			"Period":         period,
			"ResolutionRate": fmt.Sprintf("%.1f", resRate),
			"Tickets":        activeTickets,
			"Security":       middleware.GlobalFirewall.GetStats(),
		},
	})
}

// AdminQuickUpdateStatusHandler mengubah status tiket secara instan dari daftar tiket
func AdminQuickUpdateStatusHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	user := middleware.GetUserFromContext(r)
	if user == nil {
		http.Redirect(w, r, "/admin/login", http.StatusSeeOther)
		return
	}

	ticketIDStr := r.FormValue("ticket_id")
	ticketID, err := strconv.ParseInt(ticketIDStr, 10, 64)
	if err != nil {
		http.Error(w, "ID tiket tidak valid", http.StatusBadRequest)
		return
	}

	newStatus := strings.TrimSpace(r.FormValue("status"))
	returnURL := r.FormValue("return_url")
	if returnURL == "" {
		returnURL = "/admin/tickets"
	}

	ticket, err := database.GetTicketByID(ticketID)
	if err != nil {
		http.NotFound(w, r)
		return
	}

	// Validasi Hak Akses & Kepemilikan Tiket:
	// Super Admin memiliki akses penuh (bisa mengubah status, mereset ke Open, atau mengalihkan penugasan).
	// Teknisi hanya bisa mengubah tiket jika:
	// 1) Tiket ditugaskan ke dirinya sendiri (*ticket.AssignedTo == user.ID), ATAU
	// 2) Tiket belum ada yang mengerjakan dan statusnya masih "Open"
	isSuperAdmin := user.IsAdmin()
	isOwner := ticket.AssignedTo != nil && *ticket.AssignedTo == user.ID
	isUnassignedOpen := (ticket.AssignedTo == nil || *ticket.AssignedTo == 0) && ticket.Status == "Open"

	if !isSuperAdmin && !isOwner && !isUnassignedOpen {
		techName := ticket.TechnicianName
		if techName == "" || techName == "-" {
			techName = "teknisi lain"
		}
		SetFlash(w, "flash_error", fmt.Sprintf("Akses Ditolak: Tiket #%s sedang ditangani oleh %s. Teknisi lain tidak dapat mengubah status atau mengambil tiket ini menjadi Resolved/Closed. Pengaturan ulang hanya dapat dilakukan oleh Super Admin.", ticket.TicketCode, techName))
		http.Redirect(w, r, returnURL, http.StatusSeeOther)
		return
	}

	// Tentukan penugasan teknisi:
	var assignedTo *int64
	if isSuperAdmin {
		// Super Admin:
		if newStatus == "Open" {
			assignedTo = nil // Reset ke Open
		} else if ticket.AssignedTo != nil && *ticket.AssignedTo != 0 {
			assignedTo = ticket.AssignedTo // Pertahankan penugasan teknisi yang ada
		} else {
			assignedTo = &user.ID // Ambil alih ke admin jika belum ada penugasan
		}
	} else {
		// Teknisi biasa:
		if newStatus == "Open" {
			SetFlash(w, "flash_error", "Akses Ditolak: Hanya Super Admin yang berhak mereset tiket kembali ke status Open.")
			http.Redirect(w, r, returnURL, http.StatusSeeOther)
			return
		}
		// Selalu ditugaskan ke teknisi yang sedang memproses/mengerjakan
		assignedTo = &user.ID
	}

	if err := database.UpdateTicketStatusAndAssignee(ticketID, newStatus, assignedTo); err != nil {
		SetFlash(w, "flash_error", "Gagal memperbarui status: "+err.Error())
	} else {
		var msg string
		if newStatus == "Open" {
			msg = fmt.Sprintf("Status tiket dikembalikan menjadi 'Open' oleh %s (Belum Ditugaskan)", user.Name)
		} else {
			msg = fmt.Sprintf("Status tiket diubah menjadi '%s' & otomatis dikerjakan oleh %s", newStatus, user.Name)
		}
		_ = database.AddTicketUpdate(&models.TicketUpdate{
			TicketID:   ticketID,
			UserID:     &user.ID,
			SenderName: user.Name,
			SenderType: "system",
			Message:    msg,
			IsInternal: false,
		})
		if newStatus == "Open" {
			SetFlash(w, "flash_success", fmt.Sprintf("Status tiket #%s berhasil diubah menjadi '%s'.", ticket.TicketCode, newStatus))
		} else if newStatus == "Resolved" {
			SetFlash(w, "flash_success", fmt.Sprintf("Tiket #%s telah selesai dikerjakan (Resolved). Tiket telah dipindahkan dari antrean dashboard dan tetap tersimpan aman di menu Kelola Tiket.", ticket.TicketCode))
		} else {
			SetFlash(w, "flash_success", fmt.Sprintf("Status tiket #%s berhasil diubah menjadi '%s' & otomatis ditugaskan ke %s.", ticket.TicketCode, newStatus, user.Name))
		}
	}

	http.Redirect(w, r, returnURL, http.StatusSeeOther)
}

// AdminTicketsHandler menampilkan daftar tiket dengan pemisahan per hari, filter tanggal/hari ini/kemarin, bagian, status, dan pencarian
func AdminTicketsHandler(w http.ResponseWriter, r *http.Request) {
	status := r.URL.Query().Get("status")
	category := r.URL.Query().Get("category")
	priority := r.URL.Query().Get("priority")
	search := r.URL.Query().Get("q")
	section := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("section")))
	dateFilter := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("date_filter")))
	customDate := strings.TrimSpace(r.URL.Query().Get("date"))

	if dateFilter == "" {
		if customDate != "" {
			dateFilter = "custom"
		} else {
			dateFilter = "all"
		}
	}

	// Ambil seluruh tiket sesuai filter status, prioritas, dan kata kunci (tanpa filter kategori dulu untuk menghitung badge tab)
	baseTickets, err := database.GetTickets(status, "", priority, search)
	if err != nil {
		http.Error(w, "Gagal memuat tiket: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// Waktu acuan hari ini dan kemarin (Local Time)
	now := time.Now().In(time.Local)
	todayStr := now.Format("2006-01-02")
	yesterdayStr := now.AddDate(0, 0, -1).Format("2006-01-02")

	// Hitung jumlah tiket per bagian utama
	sectionCounts := map[string]int{
		"All":      0,
		"Hardware": 0,
		"Software": 0,
		"Network":  0,
		"Other":    0,
	}

	// Jika filter kategori dari dropdown adalah kelompok (group:...)
	if strings.HasPrefix(category, "group:") {
		grp := strings.TrimPrefix(category, "group:")
		if strings.EqualFold(grp, "Hardware") {
			section = "hardware"
		} else if strings.EqualFold(grp, "Software") {
			section = "software"
		} else if strings.EqualFold(grp, "Jaringan & Akun") {
			section = "network"
		} else if strings.EqualFold(grp, "Lainnya") {
			section = "other"
		}
	}

	// Saring tiket sesuai bagian atau kategori spesifik
	var sectionFilteredTickets []models.Ticket
	for _, t := range baseTickets {
		switch t.CategoryGroup {
		case "Hardware":
			sectionCounts["Hardware"]++
		case "Software":
			sectionCounts["Software"]++
		case "Jaringan & Akun":
			sectionCounts["Network"]++
		default:
			sectionCounts["Other"]++
		}
		sectionCounts["All"]++

		if section == "hardware" && t.CategoryGroup != "Hardware" {
			continue
		}
		if section == "software" && t.CategoryGroup != "Software" {
			continue
		}
		if (section == "network" || section == "jaringan") && t.CategoryGroup != "Jaringan & Akun" {
			continue
		}
		if (section == "other" || section == "lainnya") && t.CategoryGroup != "Lainnya" {
			continue
		}
		// Jika ada pilihan kategori spesifik (bukan group:...)
		if category != "" && !strings.HasPrefix(category, "group:") && category != "All" {
			if t.Category != category {
				continue
			}
		}
		sectionFilteredTickets = append(sectionFilteredTickets, t)
	}

	// Hitung jumlah tiket per kategori hari (DateCounts: All, Today, Yesterday, Past)
	dateCounts := map[string]int{
		"All":       len(sectionFilteredTickets),
		"Today":     0,
		"Yesterday": 0,
		"Past":      0,
	}

	for _, t := range sectionFilteredTickets {
		tDate := t.CreatedAt.In(time.Local).Format("2006-01-02")
		if tDate == todayStr {
			dateCounts["Today"]++
		} else if tDate == yesterdayStr {
			dateCounts["Yesterday"]++
		}
		if tDate < todayStr {
			dateCounts["Past"]++
		}
	}

	// Saring tiket berdasarkan filter hari yang aktif
	var finalTickets []models.Ticket
	for _, t := range sectionFilteredTickets {
		tDate := t.CreatedAt.In(time.Local).Format("2006-01-02")
		if dateFilter == "today" && tDate != todayStr {
			continue
		}
		if dateFilter == "yesterday" && tDate != yesterdayStr {
			continue
		}
		if dateFilter == "past" && tDate >= todayStr {
			continue
		}
		if dateFilter == "custom" && customDate != "" && tDate != customDate {
			continue
		}
		finalTickets = append(finalTickets, t)
	}

	// Kelompokkan tiket per hari (Group by Day)
	dayNames := map[time.Weekday]string{
		time.Sunday:    "Minggu",
		time.Monday:    "Senin",
		time.Tuesday:   "Selasa",
		time.Wednesday: "Rabu",
		time.Thursday:  "Kamis",
		time.Friday:    "Jumat",
		time.Saturday:  "Sabtu",
	}
	monthNames := []string{
		"", "Januari", "Februari", "Maret", "April", "Mei", "Juni",
		"Juli", "Agustus", "September", "Oktober", "November", "Desember",
	}

	var ticketGroups []models.TicketDateGroup
	groupMap := make(map[string]int) // DateKey -> index in ticketGroups

	for _, t := range finalTickets {
		locTime := t.CreatedAt.In(time.Local)
		dateKey := locTime.Format("2006-01-02")

		idx, exists := groupMap[dateKey]
		if !exists {
			isToday := (dateKey == todayStr)
			isYesterday := (dateKey == yesterdayStr)

			dayName := dayNames[locTime.Weekday()]
			monthName := monthNames[locTime.Month()]
			formattedDate := fmt.Sprintf("%s, %d %s %d", dayName, locTime.Day(), monthName, locTime.Year())

			var dateLabel string
			if isToday {
				dateLabel = fmt.Sprintf("Hari Ini — %s", formattedDate)
			} else if isYesterday {
				dateLabel = fmt.Sprintf("Kemarin — %s", formattedDate)
			} else {
				dateLabel = formattedDate
			}

			newGroup := models.TicketDateGroup{
				DateKey:       dateKey,
				DateLabel:     dateLabel,
				FormattedDate: formattedDate,
				IsToday:       isToday,
				IsYesterday:   isYesterday,
				TicketCount:   0,
				Tickets:       []models.Ticket{},
			}
			ticketGroups = append(ticketGroups, newGroup)
			idx = len(ticketGroups) - 1
			groupMap[dateKey] = idx
		}

		ticketGroups[idx].Tickets = append(ticketGroups[idx].Tickets, t)
		ticketGroups[idx].TicketCount++
	}

	// Urutkan grup tanggal secara kronologis menurun (Hari ini paling atas, kemarin, lalu hari-hari sebelumnya)
	sort.Slice(ticketGroups, func(i, j int) bool {
		return ticketGroups[i].DateKey > ticketGroups[j].DateKey
	})

	categories, _ := database.GetAllCategories()
	departments, _ := database.GetAllDepartments()

	RenderTemplate(w, r, "admin/tickets.html", PageData{
		Title:     "Manajemen Tiket IT",
		ActiveNav: "admin_tickets",
		Data: map[string]interface{}{
			"Tickets":          finalTickets,
			"TicketGroups":     ticketGroups,
			"Categories":       categories,
			"Departments":      departments,
			"FilterStatus":     status,
			"FilterCategory":   category,
			"FilterPriority":   priority,
			"Search":           search,
			"ActiveSection":    section,
			"ActiveDateFilter": dateFilter,
			"CustomDate":       customDate,
			"SectionCounts":    sectionCounts,
			"DateCounts":       dateCounts,
			"TotalCount":       len(finalTickets),
		},
	})
}

// AdminTicketDetailHandler menampilkan detail tiket untuk penanganan teknisi
func AdminTicketDetailHandler(w http.ResponseWriter, r *http.Request) {
	pathParts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	if len(pathParts) < 3 {
		http.NotFound(w, r)
		return
	}

	idStr := pathParts[2]
	ticketID, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.NotFound(w, r)
		return
	}

	ticket, err := database.GetTicketByID(ticketID)
	if err != nil {
		http.NotFound(w, r)
		return
	}

	updates, _ := database.GetTicketUpdates(ticket.ID, true)
	technicians, _ := database.GetAllTechnicians()
	categories, _ := database.GetAllCategories()
	departments, _ := database.GetAllDepartments()

	RenderTemplate(w, r, "admin/ticket_detail.html", PageData{
		Title:     fmt.Sprintf("Detail Tiket #%s", ticket.TicketCode),
		ActiveNav: "admin_tickets",
		Data: map[string]interface{}{
			"Ticket":      ticket,
			"Updates":     updates,
			"Technicians": technicians,
			"Categories":  categories,
			"Departments": departments,
		},
	})
}

// AdminUpdateTicketStatusHandler memperbarui status dan teknisi penanggung jawab
func AdminUpdateTicketStatusHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	user := middleware.GetUserFromContext(r)
	if user == nil {
		http.Redirect(w, r, "/admin/login", http.StatusSeeOther)
		return
	}

	ticketIDStr := r.FormValue("ticket_id")
	ticketID, err := strconv.ParseInt(ticketIDStr, 10, 64)
	if err != nil {
		http.Error(w, "ID tiket tidak valid", http.StatusBadRequest)
		return
	}

	oldTicket, err := database.GetTicketByID(ticketID)
	if err != nil {
		http.NotFound(w, r)
		return
	}

	// Validasi Hak Akses & Kepemilikan Tiket:
	isSuperAdmin := user.IsAdmin()
	isOwner := oldTicket.AssignedTo != nil && *oldTicket.AssignedTo == user.ID
	isUnassignedOpen := (oldTicket.AssignedTo == nil || *oldTicket.AssignedTo == 0) && oldTicket.Status == "Open"

	if !isSuperAdmin && !isOwner && !isUnassignedOpen {
		techName := oldTicket.TechnicianName
		if techName == "" || techName == "-" {
			techName = "teknisi lain"
		}
		SetFlash(w, "flash_error", fmt.Sprintf("Akses Ditolak: Tiket #%s sedang ditangani oleh %s. Anda tidak dapat mengubah status atau mengambil tiket ini. Pengaturan ulang hanya dapat dilakukan oleh Super Admin.", oldTicket.TicketCode, techName))
		http.Redirect(w, r, fmt.Sprintf("/admin/tickets/%d", ticketID), http.StatusSeeOther)
		return
	}

	newStatus := strings.TrimSpace(r.FormValue("status"))
	assignedToStr := strings.TrimSpace(r.FormValue("assigned_to"))

	var assignedTo *int64
	if isSuperAdmin {
		// Super Admin memiliki hak akses penuh mengatur status dan penugasan:
		if assignedToStr != "" && assignedToStr != "0" {
			val, err := strconv.ParseInt(assignedToStr, 10, 64)
			if err == nil {
				assignedTo = &val
			}
		} else {
			if newStatus == "Open" {
				assignedTo = nil
			} else if oldTicket.AssignedTo != nil && *oldTicket.AssignedTo != 0 {
				assignedTo = oldTicket.AssignedTo
			} else {
				assignedTo = &user.ID
			}
		}
		if newStatus == "Open" && (assignedToStr == "" || assignedToStr == "0") {
			assignedTo = nil
		}
	} else {
		// Teknisi biasa:
		if newStatus == "Open" {
			SetFlash(w, "flash_error", "Akses Ditolak: Hanya Super Admin yang berhak mereset tiket kembali ke status Open.")
			http.Redirect(w, r, fmt.Sprintf("/admin/tickets/%d", ticketID), http.StatusSeeOther)
			return
		}
		// Teknisi biasa dilarang mengalihkan tiket ke teknisi lain
		if assignedToStr != "" && assignedToStr != "0" {
			val, _ := strconv.ParseInt(assignedToStr, 10, 64)
			if val != user.ID {
				SetFlash(w, "flash_error", "Akses Ditolak: Hanya Super Admin yang berhak mengalihkan tiket ke teknisi lain.")
				http.Redirect(w, r, fmt.Sprintf("/admin/tickets/%d", ticketID), http.StatusSeeOther)
				return
			}
		}
		// Tetap ditugaskan ke teknisi penanggung jawab
		assignedTo = &user.ID
	}

	if err := database.UpdateTicketStatusAndAssignee(ticketID, newStatus, assignedTo); err != nil {
		SetFlash(w, "flash_error", "Gagal memperbarui tiket: "+err.Error())
		http.Redirect(w, r, fmt.Sprintf("/admin/tickets/%d", ticketID), http.StatusSeeOther)
		return
	}

	if oldTicket.Status != newStatus {
		var msg string
		if assignedTo != nil && *assignedTo == user.ID {
			msg = fmt.Sprintf("Status tiket diubah dari '%s' menjadi '%s' & otomatis ditugaskan ke %s", oldTicket.Status, newStatus, user.Name)
		} else {
			msg = fmt.Sprintf("Status tiket diubah dari '%s' menjadi '%s' oleh %s", oldTicket.Status, newStatus, user.Name)
		}
		_ = database.AddTicketUpdate(&models.TicketUpdate{
			TicketID:   ticketID,
			UserID:     &user.ID,
			SenderName: user.Name,
			SenderType: "system",
			Message:    msg,
			IsInternal: false,
		})
	}

	SetFlash(w, "flash_success", "Status dan penugasan tiket berhasil diperbarui.")
	http.Redirect(w, r, fmt.Sprintf("/admin/tickets/%d", ticketID), http.StatusSeeOther)
}

// AdminAddTicketCommentHandler menambahkan tanggapan teknisi atau catatan internal
func AdminAddTicketCommentHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	user := middleware.GetUserFromContext(r)
	if user == nil {
		http.Redirect(w, r, "/admin/login", http.StatusSeeOther)
		return
	}

	ticketIDStr := r.FormValue("ticket_id")
	ticketID, err := strconv.ParseInt(ticketIDStr, 10, 64)
	if err != nil {
		http.Error(w, "ID tiket tidak valid", http.StatusBadRequest)
		return
	}

	message := strings.TrimSpace(r.FormValue("message"))
	isInternal := r.FormValue("is_internal") == "1"

	if message == "" {
		SetFlash(w, "flash_error", "Pesan tanggapan tidak boleh kosong.")
		http.Redirect(w, r, fmt.Sprintf("/admin/tickets/%d", ticketID), http.StatusSeeOther)
		return
	}

	update := &models.TicketUpdate{
		TicketID:   ticketID,
		UserID:     &user.ID,
		SenderName: fmt.Sprintf("%s (%s)", user.Name, user.Role),
		SenderType: "technician",
		Message:    message,
		IsInternal: isInternal,
	}

	if err := database.AddTicketUpdate(update); err != nil {
		SetFlash(w, "flash_error", "Gagal menambahkan catatan: "+err.Error())
	} else {
		// Jika tiket belum ditugaskan ke siapapun, otomatis tugaskan ke user yang membalas
		t, errT := database.GetTicketByID(ticketID)
		if errT == nil && t != nil && (t.AssignedTo == nil || *t.AssignedTo == 0) {
			st := t.Status
			if st == "Open" {
				st = "In Progress"
			}
			_ = database.UpdateTicketStatusAndAssignee(ticketID, st, &user.ID)
		}

		if isInternal {
			SetFlash(w, "flash_success", "Catatan internal berhasil disimpan (hanya terlihat oleh teknisi).")
		} else {
			SetFlash(w, "flash_success", "Tanggapan publik berhasil dikirim ke pemohon.")
		}
	}

	http.Redirect(w, r, fmt.Sprintf("/admin/tickets/%d", ticketID), http.StatusSeeOther)
}

// AdminEditTicketHandler memperbarui informasi rincian tiket (hanya diizinkan untuk Administrator)
func AdminEditTicketHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	user := middleware.GetUserFromContext(r)
	if user == nil || user.Role != "admin" {
		http.Error(w, "Akses ditolak: Hanya Administrator yang berhak mengubah rincian tiket.", http.StatusForbidden)
		return
	}

	ticketIDStr := r.FormValue("ticket_id")
	ticketID, err := strconv.ParseInt(ticketIDStr, 10, 64)
	if err != nil {
		SetFlash(w, "flash_error", "ID tiket tidak valid.")
		http.Redirect(w, r, "/admin/tickets", http.StatusSeeOther)
		return
	}

	oldTicket, err := database.GetTicketByID(ticketID)
	if err != nil {
		SetFlash(w, "flash_error", "Tiket tidak ditemukan.")
		http.Redirect(w, r, "/admin/tickets", http.StatusSeeOther)
		return
	}

	subject := strings.TrimSpace(r.FormValue("subject"))
	description := strings.TrimSpace(r.FormValue("description"))
	category := strings.TrimSpace(r.FormValue("category"))
	department := strings.TrimSpace(r.FormValue("department"))
	priority := strings.TrimSpace(r.FormValue("priority"))
	reqName := strings.TrimSpace(r.FormValue("requester_name"))
	reqEmail := strings.TrimSpace(r.FormValue("requester_email"))
	reqPhone := strings.TrimSpace(r.FormValue("requester_phone"))
	returnURL := r.FormValue("return_url")
	if returnURL == "" {
		returnURL = fmt.Sprintf("/admin/tickets/%d", ticketID)
	}

	if reqEmail == "" {
		reqEmail = "-"
	}
	if reqPhone == "" {
		reqPhone = "-"
	}
	if description == "" {
		description = "-"
	}

	if subject == "" || category == "" || department == "" || reqName == "" {
		SetFlash(w, "flash_error", "Data pokok tiket (Subjek, Kategori, Departemen, dan Nama Pemohon) wajib diisi.")
		http.Redirect(w, r, returnURL, http.StatusSeeOther)
		return
	}

	if err := database.UpdateTicketDetails(ticketID, subject, description, category, department, priority, reqName, reqEmail, reqPhone); err != nil {
		SetFlash(w, "flash_error", "Gagal memperbarui rincian tiket: "+err.Error())
		http.Redirect(w, r, returnURL, http.StatusSeeOther)
		return
	}

	// Catat log riwayat perubahan rincian oleh Administrator
	_ = database.AddTicketUpdate(&models.TicketUpdate{
		TicketID:   ticketID,
		UserID:     &user.ID,
		SenderName: user.Name,
		SenderType: "technician",
		Message:    fmt.Sprintf("[Pembaruan Administrator] Rincian tiket #%s berhasil diubah oleh Administrator %s (Subjek: '%s', Kategori: '%s', Departemen: '%s', Prioritas: '%s').", oldTicket.TicketCode, user.Name, subject, category, department, priority),
		IsInternal: true,
	})

	SetFlash(w, "flash_success", fmt.Sprintf("Rincian tiket #%s berhasil diperbarui oleh Administrator.", oldTicket.TicketCode))
	http.Redirect(w, r, returnURL, http.StatusSeeOther)
}

// AdminDeleteTicketHandler menghapus tiket beserta log riwayatnya (hanya diizinkan untuk Administrator)
func AdminDeleteTicketHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	user := middleware.GetUserFromContext(r)
	if user == nil || user.Role != "admin" {
		http.Error(w, "Akses ditolak: Hanya Administrator yang berhak menghapus tiket.", http.StatusForbidden)
		return
	}

	ticketIDStr := r.FormValue("ticket_id")
	ticketID, err := strconv.ParseInt(ticketIDStr, 10, 64)
	if err != nil {
		SetFlash(w, "flash_error", "ID tiket tidak valid.")
		http.Redirect(w, r, "/admin/tickets", http.StatusSeeOther)
		return
	}

	ticket, err := database.GetTicketByID(ticketID)
	if err != nil {
		SetFlash(w, "flash_error", "Tiket tidak ditemukan atau sudah dihapus.")
		http.Redirect(w, r, "/admin/tickets", http.StatusSeeOther)
		return
	}

	if err := database.DeleteTicket(ticketID); err != nil {
		SetFlash(w, "flash_error", "Gagal menghapus tiket: "+err.Error())
		http.Redirect(w, r, "/admin/tickets", http.StatusSeeOther)
		return
	}

	SetFlash(w, "flash_success", fmt.Sprintf("Tiket #%s ('%s') berhasil dihapus permanen dari sistem oleh Administrator.", ticket.TicketCode, ticket.Subject))
	http.Redirect(w, r, "/admin/tickets", http.StatusSeeOther)
}

// --- MASTER DATA: KATEGORI & DEPARTEMEN ---

// AdminMasterDataHandler menampilkan halaman manajemen Kategori dan Departemen
func AdminMasterDataHandler(w http.ResponseWriter, r *http.Request) {
	categories, err := database.GetAllCategories()
	if err != nil {
		http.Error(w, "Gagal memuat kategori: "+err.Error(), http.StatusInternalServerError)
		return
	}

	departments, err := database.GetAllDepartments()
	if err != nil {
		http.Error(w, "Gagal memuat departemen: "+err.Error(), http.StatusInternalServerError)
		return
	}

	tab := r.URL.Query().Get("tab")
	if tab == "" {
		tab = "categories"
	}

	// Hitung jumlah kategori per bagian
	groupCounts := map[string]int{
		"All":      len(categories),
		"Hardware": 0,
		"Software": 0,
		"Network":  0,
		"Other":    0,
	}
	for _, c := range categories {
		switch c.CategoryGroup {
		case "Hardware":
			groupCounts["Hardware"]++
		case "Software":
			groupCounts["Software"]++
		case "Jaringan & Akun":
			groupCounts["Network"]++
		default:
			groupCounts["Other"]++
		}
	}

	RenderTemplate(w, r, "admin/master.html", PageData{
		Title:     "Kelola Master Kategori & Departemen",
		ActiveNav: "admin_master",
		Data: map[string]interface{}{
			"Categories":          categories,
			"Departments":         departments,
			"CategoryGroupCounts": groupCounts,
			"ActiveTab":           tab,
		},
	})
}

// AdminCreateCategoryHandler menambah kategori baru
func AdminCreateCategoryHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	name := strings.TrimSpace(r.FormValue("name"))
	section := strings.TrimSpace(r.FormValue("section"))
	desc := strings.TrimSpace(r.FormValue("description"))

	if name == "" {
		SetFlash(w, "flash_error", "Nama kategori tidak boleh kosong.")
		http.Redirect(w, r, "/admin/master?tab=categories", http.StatusSeeOther)
		return
	}

	if section == "" {
		section = database.ClassifyCategoryGroup(name)
	}

	if err := database.CreateCategory(name, section, desc); err != nil {
		SetFlash(w, "flash_error", "Gagal menambah kategori: "+err.Error())
	} else {
		SetFlash(w, "flash_success", fmt.Sprintf("Kategori '%s' berhasil ditambahkan ke bagian %s.", name, section))
	}

	http.Redirect(w, r, "/admin/master?tab=categories", http.StatusSeeOther)
}

// AdminUpdateCategoryHandler memperbarui kategori yang sudah ada
func AdminUpdateCategoryHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	idStr := r.FormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		SetFlash(w, "flash_error", "ID kategori tidak valid.")
		http.Redirect(w, r, "/admin/master?tab=categories", http.StatusSeeOther)
		return
	}

	name := strings.TrimSpace(r.FormValue("name"))
	section := strings.TrimSpace(r.FormValue("section"))
	desc := strings.TrimSpace(r.FormValue("description"))

	if name == "" {
		SetFlash(w, "flash_error", "Nama kategori tidak boleh kosong.")
		http.Redirect(w, r, "/admin/master?tab=categories", http.StatusSeeOther)
		return
	}

	if section == "" {
		section = database.ClassifyCategoryGroup(name)
	}

	if err := database.UpdateCategory(id, name, section, desc); err != nil {
		SetFlash(w, "flash_error", "Gagal mengubah kategori: "+err.Error())
	} else {
		SetFlash(w, "flash_success", fmt.Sprintf("Kategori '%s' berhasil diperbarui.", name))
	}

	http.Redirect(w, r, "/admin/master?tab=categories", http.StatusSeeOther)
}

// AdminDeleteCategoryHandler menghapus kategori
func AdminDeleteCategoryHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	idStr := r.FormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		SetFlash(w, "flash_error", "ID kategori tidak valid.")
		http.Redirect(w, r, "/admin/master?tab=categories", http.StatusSeeOther)
		return
	}

	if err := database.DeleteCategory(id); err != nil {
		SetFlash(w, "flash_error", "Gagal menghapus kategori: "+err.Error())
	} else {
		SetFlash(w, "flash_success", "Kategori berhasil dihapus.")
	}

	http.Redirect(w, r, "/admin/master?tab=categories", http.StatusSeeOther)
}

// AdminCreateDepartmentHandler menambah departemen baru
func AdminCreateDepartmentHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	name := strings.TrimSpace(r.FormValue("name"))
	desc := strings.TrimSpace(r.FormValue("description"))

	if name == "" {
		SetFlash(w, "flash_error", "Nama departemen tidak boleh kosong.")
		http.Redirect(w, r, "/admin/master?tab=departments", http.StatusSeeOther)
		return
	}

	if err := database.CreateDepartment(name, desc); err != nil {
		SetFlash(w, "flash_error", "Gagal menambah departemen: "+err.Error())
	} else {
		SetFlash(w, "flash_success", fmt.Sprintf("Departemen '%s' berhasil ditambahkan.", name))
	}

	http.Redirect(w, r, "/admin/master?tab=departments", http.StatusSeeOther)
}

// AdminUpdateDepartmentHandler memperbarui data departemen
func AdminUpdateDepartmentHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	idStr := r.FormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		SetFlash(w, "flash_error", "ID departemen tidak valid.")
		http.Redirect(w, r, "/admin/master?tab=departments", http.StatusSeeOther)
		return
	}

	name := strings.TrimSpace(r.FormValue("name"))
	desc := strings.TrimSpace(r.FormValue("description"))

	if name == "" {
		SetFlash(w, "flash_error", "Nama departemen tidak boleh kosong.")
		http.Redirect(w, r, "/admin/master?tab=departments", http.StatusSeeOther)
		return
	}

	if err := database.UpdateDepartment(id, name, desc); err != nil {
		SetFlash(w, "flash_error", "Gagal mengubah departemen: "+err.Error())
	} else {
		SetFlash(w, "flash_success", fmt.Sprintf("Departemen '%s' berhasil diperbarui.", name))
	}

	http.Redirect(w, r, "/admin/master?tab=departments", http.StatusSeeOther)
}

// AdminDeleteDepartmentHandler menghapus departemen
func AdminDeleteDepartmentHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	idStr := r.FormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		SetFlash(w, "flash_error", "ID departemen tidak valid.")
		http.Redirect(w, r, "/admin/master?tab=departments", http.StatusSeeOther)
		return
	}

	if err := database.DeleteDepartment(id); err != nil {
		SetFlash(w, "flash_error", "Gagal menghapus departemen: "+err.Error())
	} else {
		SetFlash(w, "flash_success", "Departemen berhasil dihapus.")
	}

	http.Redirect(w, r, "/admin/master?tab=departments", http.StatusSeeOther)
}

// --- PENGELOLAAN TEKNISI & HAK AKSES ---

// AdminTechniciansHandler menampilkan daftar teknisi dan hak aksesnya
func AdminTechniciansHandler(w http.ResponseWriter, r *http.Request) {
	technicians, err := database.GetAllTechnicians()
	if err != nil {
		http.Error(w, "Gagal memuat teknisi: "+err.Error(), http.StatusInternalServerError)
		return
	}

	RenderTemplate(w, r, "admin/technicians.html", PageData{
		Title:     "Kelola Tim Teknisi & Hak Akses",
		ActiveNav: "admin_techs",
		Data: map[string]interface{}{
			"Technicians": technicians,
		},
	})
}

// AdminCreateTechnicianHandler memproses pendaftaran teknisi baru dengan hak akses pilihan
func AdminCreateTechnicianHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	name := strings.TrimSpace(r.FormValue("name"))
	username := strings.TrimSpace(r.FormValue("username"))
	email := strings.TrimSpace(r.FormValue("email"))
	password := strings.TrimSpace(r.FormValue("password"))
	role := strings.TrimSpace(r.FormValue("role"))
	phone := strings.TrimSpace(r.FormValue("phone"))

	canTickets := r.FormValue("can_manage_tickets") == "1"
	canMaster := r.FormValue("can_manage_master") == "1"
	canUsers := r.FormValue("can_manage_users") == "1"

	if name == "" || email == "" || password == "" {
		SetFlash(w, "flash_error", "Nama, email, dan kata sandi wajib diisi.")
		http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
		return
	}

	if username == "" {
		parts := strings.Split(email, "@")
		username = strings.ToLower(parts[0])
	}

	// Cek keunikan username
	if taken, err := database.IsUsernameTaken(username, 0); err == nil && taken {
		SetFlash(w, "flash_error", fmt.Sprintf("Username '%s' sudah digunakan oleh akun lain.", username))
		http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
		return
	}

	// Cek keunikan email
	if emailTaken, err := database.IsEmailTaken(email, 0); err == nil && emailTaken {
		SetFlash(w, "flash_error", fmt.Sprintf("Email '%s' sudah digunakan oleh akun lain.", email))
		http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
		return
	}

	if role == "" {
		role = "technician"
	}
	if role == "admin" {
		canTickets = true
		canMaster = true
		canUsers = true
	}

	_, err := database.CreateUser(name, username, email, password, role, phone, canTickets, canMaster, canUsers)
	if err != nil {
		SetFlash(w, "flash_error", "Gagal menambah teknisi: "+err.Error())
	} else {
		SetFlash(w, "flash_success", fmt.Sprintf("Akun teknisi '%s' (Username: %s) berhasil ditambahkan dengan hak akses yang ditentukan.", name, username))
	}

	http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
}

// AdminUpdateTechnicianHandler memperbarui profil dan hak akses teknisi
func AdminUpdateTechnicianHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	idStr := r.FormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		SetFlash(w, "flash_error", "ID pengguna tidak valid.")
		http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
		return
	}

	name := strings.TrimSpace(r.FormValue("name"))
	username := strings.TrimSpace(r.FormValue("username"))
	email := strings.TrimSpace(r.FormValue("email"))
	password := strings.TrimSpace(r.FormValue("password"))
	role := strings.TrimSpace(r.FormValue("role"))
	phone := strings.TrimSpace(r.FormValue("phone"))

	canTickets := r.FormValue("can_manage_tickets") == "1"
	canMaster := r.FormValue("can_manage_master") == "1"
	canUsers := r.FormValue("can_manage_users") == "1"

	if name == "" || email == "" {
		SetFlash(w, "flash_error", "Nama dan email wajib diisi.")
		http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
		return
	}

	if username == "" {
		parts := strings.Split(email, "@")
		username = strings.ToLower(parts[0])
	}

	// Cek keunikan username
	if taken, err := database.IsUsernameTaken(username, id); err == nil && taken {
		SetFlash(w, "flash_error", fmt.Sprintf("Username '%s' sudah digunakan oleh akun lain.", username))
		http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
		return
	}

	// Cek keunikan email
	if emailTaken, err := database.IsEmailTaken(email, id); err == nil && emailTaken {
		SetFlash(w, "flash_error", fmt.Sprintf("Email '%s' sudah digunakan oleh akun lain.", email))
		http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
		return
	}

	if role == "admin" {
		canTickets = true
		canMaster = true
		canUsers = true
	}

	err = database.UpdateUser(id, name, username, email, role, phone, canTickets, canMaster, canUsers, password)
	if err != nil {
		SetFlash(w, "flash_error", "Gagal memperbarui teknisi: "+err.Error())
	} else {
		SetFlash(w, "flash_success", fmt.Sprintf("Data dan hak akses akun '%s' (Username: %s) berhasil diperbarui.", name, username))
	}

	http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
}

// AdminDeleteTechnicianHandler menghapus akun teknisi
func AdminDeleteTechnicianHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	currentUser := middleware.GetUserFromContext(r)
	idStr := r.FormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		SetFlash(w, "flash_error", "ID pengguna tidak valid.")
		http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
		return
	}

	if currentUser != nil && currentUser.ID == id {
		SetFlash(w, "flash_error", "Anda tidak dapat menghapus akun Anda sendiri saat sedang login.")
		http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
		return
	}

	if err := database.DeleteUser(id); err != nil {
		SetFlash(w, "flash_error", "Gagal menghapus akun: "+err.Error())
	} else {
		SetFlash(w, "flash_success", "Akun teknisi berhasil dihapus dari sistem.")
	}

	http.Redirect(w, r, "/admin/technicians", http.StatusSeeOther)
}

// AdminProfileHandler menampilkan halaman pengaturan profil dan keamanan akun pengguna
func AdminProfileHandler(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUserFromContext(r)
	if user == nil {
		http.Redirect(w, r, "/admin/login", http.StatusSeeOther)
		return
	}

	freshUser, err := database.GetUserByID(user.ID)
	if err != nil {
		freshUser = user
	}

	RenderTemplate(w, r, "admin/profile.html", PageData{
		Title:       "Profil & Keamanan Akun",
		ActiveNav:   "profile",
		CurrentUser: freshUser,
		Data:        freshUser,
	})
}

// AdminUpdateProfileHandler memproses pembaruan nama, username, email, dan telepon pengguna
func AdminUpdateProfileHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	user := middleware.GetUserFromContext(r)
	if user == nil {
		http.Redirect(w, r, "/admin/login", http.StatusSeeOther)
		return
	}

	name := strings.TrimSpace(r.FormValue("name"))
	username := strings.ToLower(strings.TrimSpace(r.FormValue("username")))
	email := strings.ToLower(strings.TrimSpace(r.FormValue("email")))
	phone := strings.TrimSpace(r.FormValue("phone"))

	if name == "" {
		SetFlash(w, "flash_error", "Nama lengkap tidak boleh kosong.")
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	if username == "" {
		SetFlash(w, "flash_error", "Username login tidak boleh kosong.")
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	if len(username) < 3 {
		SetFlash(w, "flash_error", "Username minimal terdiri dari 3 karakter.")
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	// Cek karakter valid username
	for _, ch := range username {
		if !((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '_' || ch == '-' || ch == '.') {
			SetFlash(w, "flash_error", "Username hanya boleh menggunakan huruf kecil, angka, titik (.), underscore (_), atau strip (-).")
			http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
			return
		}
	}

	if email == "" || !strings.Contains(email, "@") {
		SetFlash(w, "flash_error", "Format email tidak valid.")
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	// Cek keunikan username
	taken, err := database.IsUsernameTaken(username, user.ID)
	if err != nil {
		SetFlash(w, "flash_error", "Terjadi kesalahan sistem: "+err.Error())
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}
	if taken {
		SetFlash(w, "flash_error", fmt.Sprintf("Username '%s' sudah digunakan oleh pengguna lain. Silakan pilih username berbeda.", username))
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	// Cek keunikan email
	emailTaken, err := database.IsEmailTaken(email, user.ID)
	if err != nil {
		SetFlash(w, "flash_error", "Terjadi kesalahan sistem: "+err.Error())
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}
	if emailTaken {
		SetFlash(w, "flash_error", fmt.Sprintf("Email '%s' sudah terdaftar pada akun lain.", email))
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	if err := database.UpdateUserProfile(user.ID, name, username, email, phone); err != nil {
		SetFlash(w, "flash_error", "Gagal memperbarui profil: "+err.Error())
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	SetFlash(w, "flash_success", "Profil Anda dan username login berhasil diperbarui!")
	http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
}

// AdminChangePasswordHandler memproses penggantian kata sandi dengan validasi password lama
func AdminChangePasswordHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	user := middleware.GetUserFromContext(r)
	if user == nil {
		http.Redirect(w, r, "/admin/login", http.StatusSeeOther)
		return
	}

	currentPassword := r.FormValue("current_password")
	newPassword := r.FormValue("new_password")
	confirmPassword := r.FormValue("confirm_password")

	if currentPassword == "" || newPassword == "" || confirmPassword == "" {
		SetFlash(w, "flash_error", "Semua kolom kata sandi wajib diisi.")
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	if len(newPassword) < 6 {
		SetFlash(w, "flash_error", "Kata sandi baru minimal harus 6 karakter.")
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	if newPassword != confirmPassword {
		SetFlash(w, "flash_error", "Konfirmasi kata sandi baru tidak sesuai!")
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	// Ambil hash password saat ini
	currentHash, err := database.GetUserPasswordHash(user.ID)
	if err != nil {
		SetFlash(w, "flash_error", "Gagal memverifikasi kata sandi lama: "+err.Error())
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	// Verifikasi kecocokan kata sandi lama
	if err := bcrypt.CompareHashAndPassword([]byte(currentHash), []byte(currentPassword)); err != nil {
		SetFlash(w, "flash_error", "Kata sandi saat ini (lama) salah!")
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	// Update kata sandi baru
	if err := database.UpdateUserPassword(user.ID, newPassword); err != nil {
		SetFlash(w, "flash_error", "Gagal menyimpan kata sandi baru: "+err.Error())
		http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
		return
	}

	SetFlash(w, "flash_success", "Kata sandi akun Anda berhasil diperbarui! Gunakan kata sandi baru saat login selanjutnya.")
	http.Redirect(w, r, "/admin/profile", http.StatusSeeOther)
}

// NotificationTicketDTO merepresentasikan struktur data tiket ringkas untuk notifikasi real-time
type NotificationTicketDTO struct {
	ID                 int64  `json:"id"`
	TicketCode         string `json:"ticket_code"`
	RequesterName      string `json:"requester_name"`
	Department         string `json:"department"`
	Category           string `json:"category"`
	Priority           string `json:"priority"`
	Subject            string `json:"subject"`
	Status             string `json:"status"`
	CreatedAtFormatted string `json:"created_at_formatted"`
	TimeAgo            string `json:"time_ago"`
}

// AdminPollNotificationsHandler menangani endpoint polling notifikasi tiket baru secara realtime
func AdminPollNotificationsHandler(w http.ResponseWriter, r *http.Request) {
	currentUser := middleware.GetUserFromContext(r)
	var currentUserID int64
	if currentUser != nil {
		currentUserID = currentUser.ID
	}

	sinceIDStr := r.URL.Query().Get("since_id")
	var sinceID int64
	if sinceIDStr != "" {
		sinceID, _ = strconv.ParseInt(sinceIDStr, 10, 64)
	}

	maxID, err := database.GetMaxTicketID()
	if err != nil {
		RenderJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"status":  "error",
			"message": err.Error(),
		})
		return
	}

	// Ambil statistik terkini untuk live dashboard sync setiap 5 detik
	stats, _ := database.GetDashboardStats()
	var resRate float64
	if stats != nil && stats.TotalTickets > 0 {
		resRate = float64(stats.ResolvedTickets+stats.ClosedTickets) / float64(stats.TotalTickets) * 100.0
	}

	// Ambil record tiket terakhir yang pernah dinotifikasikan ke user ini dari database
	var userLastNotifiedID int64
	if currentUserID > 0 {
		userLastNotifiedID, _ = database.GetUserLastNotifiedTicketID(currentUserID)
	}

	// Tentukan effectiveSinceID:
	// - Jika client mengirim sinceID > 0, ambil max(sinceID, userLastNotifiedID)
	// - Jika client mengirim sinceID <= 0 (login baru / tab baru), gunakan userLastNotifiedID di database
	effectiveSinceID := sinceID
	if sinceID <= 0 {
		effectiveSinceID = userLastNotifiedID
	} else if userLastNotifiedID > effectiveSinceID {
		effectiveSinceID = userLastNotifiedID
	}

	// Cek apakah ada tiket baru yang belum dinotifikasikan ke user ini
	var newTickets []models.Ticket
	if maxID > effectiveSinceID {
		newTickets, _ = database.GetNewTicketsForUserNotification(effectiveSinceID, 10)
	}

	// Jika ada tiket baru yang relevan untuk user ini
	if len(newTickets) > 0 {
		var newDTOs []NotificationTicketDTO
		for _, t := range newTickets {
			newDTOs = append(newDTOs, NotificationTicketDTO{
				ID:                 t.ID,
				TicketCode:         t.TicketCode,
				RequesterName:      t.RequesterName,
				Department:         t.Department,
				Category:           t.Category,
				Priority:           t.Priority,
				Subject:            t.Subject,
				Status:             t.Status,
				CreatedAtFormatted: t.CreatedAt.Format("02 Jan 15:04 WIB"),
				TimeAgo:            FormatTimeAgo(t.CreatedAt),
			})
		}

		// Update database user agar tiket-tiket ini tercatat sudah dinotifikasikan ke akun ini
		if currentUserID > 0 {
			_ = database.UpdateUserLastNotifiedTicketID(currentUserID, maxID)
		}

		RenderJSON(w, http.StatusOK, map[string]interface{}{
			"status":          "ok",
			"latest_id":       maxID,
			"has_new":         true,
			"new_count":       len(newDTOs),
			"new_tickets":     newDTOs,
			"stats":           stats,
			"resolution_rate": fmt.Sprintf("%.0f", resRate),
		})
		return
	}

	// Jika tidak ada tiket baru untuk user ini
	// Dan jika ini polling inisialisasi (sinceID <= 0):
	if sinceID <= 0 {
		// Sinkronkan last_notified_ticket_id di database ke maxID jika belum
		if currentUserID > 0 && maxID > userLastNotifiedID {
			_ = database.UpdateUserLastNotifiedTicketID(currentUserID, maxID)
		}

		recent, _ := database.GetRecentTicketsForNotification(5)
		var recentDTOs []NotificationTicketDTO
		for _, t := range recent {
			recentDTOs = append(recentDTOs, NotificationTicketDTO{
				ID:                 t.ID,
				TicketCode:         t.TicketCode,
				RequesterName:      t.RequesterName,
				Department:         t.Department,
				Category:           t.Category,
				Priority:           t.Priority,
				Subject:            t.Subject,
				Status:             t.Status,
				CreatedAtFormatted: t.CreatedAt.Format("02 Jan 15:04 WIB"),
				TimeAgo:            FormatTimeAgo(t.CreatedAt),
			})
		}

		RenderJSON(w, http.StatusOK, map[string]interface{}{
			"status":          "ok",
			"latest_id":       maxID,
			"has_new":         false,
			"new_count":       0,
			"recent_tickets":  recentDTOs,
			"stats":           stats,
			"resolution_rate": fmt.Sprintf("%.0f", resRate),
		})
		return
	}

	// Polling rutin berkala tanpa tiket baru
	RenderJSON(w, http.StatusOK, map[string]interface{}{
		"status":          "ok",
		"latest_id":       maxID,
		"has_new":         false,
		"new_count":       0,
		"new_tickets":     []NotificationTicketDTO{},
		"stats":           stats,
		"resolution_rate": fmt.Sprintf("%.0f", resRate),
	})
}

// AdminSecurityStatsHandler menyajikan metrik keamanan sistem & firewall secara real-time
func AdminSecurityStatsHandler(w http.ResponseWriter, r *http.Request) {
	stats := middleware.GlobalFirewall.GetStats()
	RenderJSON(w, http.StatusOK, map[string]interface{}{
		"status": "ok",
		"data":   stats,
	})
}

// AdminTelegramTestHandler mengirimkan pesan uji coba notifikasi Telegram
func AdminTelegramTestHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	targetChatID := strings.TrimSpace(r.FormValue("chat_id"))
	if targetChatID == "" {
		currentUser := middleware.GetUserFromContext(r)
		if currentUser != nil && currentUser.TelegramChatID != "" {
			targetChatID = currentUser.TelegramChatID
		} else {
			subs, _ := database.GetAllActiveTelegramSubscribers()
			if len(subs) > 0 {
				targetChatID = subs[0]
			}
		}
	}

	if targetChatID == "" {
		RenderJSON(w, http.StatusBadRequest, map[string]string{"status": "error", "message": "Pilih penerima Telegram dahulu."})
		return
	}
	err := telegram.SendTestNotification(targetChatID)
	if err != nil {
		RenderJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"status":  "error",
			"message": "Gagal mengirim pesan Telegram: " + err.Error(),
		})
		return
	}

	RenderJSON(w, http.StatusOK, map[string]interface{}{
		"status":  "ok",
		"message": fmt.Sprintf("Pesan uji coba berhasil dikirim ke Telegram Chat ID: %s", targetChatID),
	})
}

// AdminTelegramStatusHandler menyajikan status bot Telegram dan daftar penerima notifikasi
func AdminTelegramStatusHandler(w http.ResponseWriter, r *http.Request) {
	subscribers, err := database.GetAllTelegramSubscribers()
	if err != nil {
		RenderJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"status":  "error",
			"message": err.Error(),
		})
		return
	}

	token := telegram.GetBotToken()
	maskedToken := ""
	if len(token) > 10 {
		maskedToken = token[:6] + "..." + token[len(token)-4:]
	} else {
		maskedToken = "Belum disetel"
	}

	RenderJSON(w, http.StatusOK, map[string]interface{}{
		"status":       "ok",
		"bot_username": os.Getenv("TELEGRAM_BOT_USERNAME"),
		"bot_enabled":  telegram.IsBotEnabled(),
		"masked_token": maskedToken,
		"subscribers":  subscribers,
	})
}
