package handlers

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"it-ticket-support/internal/database"
	"it-ticket-support/internal/models"
)

// HomeHandler menampilkan halaman depan IT Support Portal
func HomeHandler(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}

	stats, _ := database.GetDashboardStats()

	RenderTemplate(w, r, "public/index.html", PageData{
		Title:     "Portal IT Support & Tiket Bantuan",
		ActiveNav: "home",
		Data: map[string]interface{}{
			"Stats": stats,
		},
	})
}

// CreateTicketFormHandler menampilkan formulir pendaftaran tiket baru di luar login
func CreateTicketFormHandler(w http.ResponseWriter, r *http.Request) {
	categories, _ := database.GetAllCategories()
	departments, _ := database.GetAllDepartments()

	RenderTemplate(w, r, "public/create_ticket.html", PageData{
		Title:     "Buat Tiket Dukungan IT Baru",
		ActiveNav: "create_ticket",
		Data: map[string]interface{}{
			"Categories":  categories,
			"Departments": departments,
		},
	})
}

// SubmitTicketHandler memproses pengiriman form tiket baru
func SubmitTicketHandler(w http.ResponseWriter, r *http.Request) {
	// Batasi ukuran request max 10MB
	if err := r.ParseMultipartForm(10 << 20); err != nil {
		// Jika bukan multipart, coba form biasa
		_ = r.ParseForm()
	}

	name := strings.TrimSpace(r.FormValue("requester_name"))
	email := strings.TrimSpace(r.FormValue("requester_email"))
	phone := strings.TrimSpace(r.FormValue("requester_phone"))
	dept := strings.TrimSpace(r.FormValue("department"))
	category := strings.TrimSpace(r.FormValue("category"))
	priority := strings.TrimSpace(r.FormValue("priority"))
	subject := strings.TrimSpace(r.FormValue("subject"))
	desc := strings.TrimSpace(r.FormValue("description"))

	// Default jika email, nomor telepon, atau deskripsi tidak diinput oleh pemohon
	if email == "" {
		email = "-"
	}
	if phone == "" {
		phone = "-"
	}
	if desc == "" {
		desc = "-"
	}

	// Validasi input
	if name == "" || dept == "" || category == "" || subject == "" {
		categories, _ := database.GetAllCategories()
		departments, _ := database.GetAllDepartments()

		RenderTemplate(w, r, "public/create_ticket.html", PageData{
			Title:      "Buat Tiket Dukungan IT Baru",
			ActiveNav:  "create_ticket",
			FlashError: "Mohon lengkapi semua kolom yang bertanda bintang (*)",
			Data: map[string]interface{}{
				"Categories":     categories,
				"Departments":    departments,
				"RequesterName":  name,
				"RequesterEmail": email,
				"RequesterPhone": phone,
				"Department":     dept,
				"Category":       category,
				"Priority":       priority,
				"Subject":        subject,
				"Description":    desc,
			},
		})
		return
	}

	if priority == "" {
		priority = "Sedang"
	}

	// Tangani upload lampiran jika ada
	var attachmentFilename string
	file, header, err := r.FormFile("attachment")
	if err == nil && file != nil {
		defer file.Close()

		ext := strings.ToLower(filepath.Ext(header.Filename))
		// Validasi ekstensi yang diizinkan
		allowedExts := map[string]bool{
			".jpg": true, ".jpeg": true, ".png": true, ".gif": true,
			".pdf": true, ".txt": true, ".log": true, ".zip": true,
		}

		if allowedExts[ext] {
			_ = os.MkdirAll("web/static/uploads", 0755)
			randomBytes := make([]byte, 8)
			_, _ = rand.Read(randomBytes)
			attachmentFilename = fmt.Sprintf("att_%s%s", hex.EncodeToString(randomBytes), ext)

			destPath := filepath.Join("web/static/uploads", attachmentFilename)
			destFile, err := os.Create(destPath)
			if err == nil {
				defer destFile.Close()
				_, _ = io.Copy(destFile, file)
			}
		}
	}

	ticket := &models.Ticket{
		RequesterName:  name,
		RequesterEmail: email,
		RequesterPhone: phone,
		Department:     dept,
		Category:       category,
		Priority:       priority,
		Subject:        subject,
		Description:    desc,
		Attachment:     attachmentFilename,
	}

	_, ticketCode, err := database.CreateTicket(ticket)
	if err != nil {
		RenderTemplate(w, r, "public/create_ticket.html", PageData{
			Title:      "Buat Tiket Dukungan IT Baru",
			ActiveNav:  "create_ticket",
			FlashError: "Gagal menyimpan tiket: " + err.Error(),
		})
		return
	}

	http.Redirect(w, r, "/tickets/success?code="+ticketCode, http.StatusSeeOther)
}

// TicketSuccessHandler menampilkan halaman konfirmasi pembuatan tiket
func TicketSuccessHandler(w http.ResponseWriter, r *http.Request) {
	code := strings.TrimSpace(r.URL.Query().Get("code"))
	if code == "" {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}

	ticket, err := database.GetTicketByCode(code)
	if err != nil {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}

	RenderTemplate(w, r, "public/ticket_success.html", PageData{
		Title:     "Tiket Berhasil Dibuat",
		ActiveNav: "create_ticket",
		Data:      ticket,
	})
}

// TrackTicketHandler menampilkan formulir cek tiket dan status tiket hanya dengan nomor tiket tanpa email
func TrackTicketHandler(w http.ResponseWriter, r *http.Request) {
	code := strings.TrimSpace(r.URL.Query().Get("code"))

	data := map[string]interface{}{
		"SearchCode": code,
		"Ticket":     nil,
		"Updates":    nil,
	}

	if code != "" {
		ticket, err := database.GetTicketByCode(code)
		if err != nil {
			data["ErrorMessage"] = fmt.Sprintf("Nomor tiket '%s' tidak ditemukan. Silakan periksa kembali nomor tiket Anda.", code)
		} else {
			updates, _ := database.GetTicketUpdates(ticket.ID, false) // Hanya update publik
			data["Ticket"] = ticket
			data["Updates"] = updates
		}
	}

	RenderTemplate(w, r, "public/track_ticket.html", PageData{
		Title:     "Cek Status Tiket IT",
		ActiveNav: "track_ticket",
		Data:      data,
	})
}

// AddPublicCommentHandler memungkinkan pemohon menambahkan tanggapan pada tiket dari halaman tracking
func AddPublicCommentHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Metode tidak diizinkan", http.StatusMethodNotAllowed)
		return
	}

	code := strings.TrimSpace(r.FormValue("ticket_code"))
	message := strings.TrimSpace(r.FormValue("message"))

	if code == "" || message == "" {
		http.Redirect(w, r, "/tickets/track?code="+code, http.StatusSeeOther)
		return
	}

	ticket, err := database.GetTicketByCode(code)
	if err != nil {
		http.Redirect(w, r, "/tickets/track?code="+code, http.StatusSeeOther)
		return
	}

	// Jangan izinkan update jika tiket sudah Closed
	if ticket.Status == "Closed" {
		SetFlash(w, "flash_error", "Tiket ini telah ditutup dan tidak dapat menerima tanggapan baru.")
		http.Redirect(w, r, "/tickets/track?code="+code, http.StatusSeeOther)
		return
	}

	update := &models.TicketUpdate{
		TicketID:   ticket.ID,
		SenderName: ticket.RequesterName + " (Pemohon)",
		SenderType: "requester",
		Message:    message,
		IsInternal: false,
	}

	if err := database.AddTicketUpdate(update); err != nil {
		SetFlash(w, "flash_error", "Gagal mengirim tanggapan: "+err.Error())
	} else {
		SetFlash(w, "flash_success", "Tanggapan Anda berhasil dikirim ke teknisi.")
	}

	http.Redirect(w, r, "/tickets/track?code="+code, http.StatusSeeOther)
}
