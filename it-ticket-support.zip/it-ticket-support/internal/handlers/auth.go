package handlers

import (
	"net/http"
	"strings"
	"time"

	"it-ticket-support/internal/database"
	"it-ticket-support/internal/middleware"

	"golang.org/x/crypto/bcrypt"
)

// LoginFormHandler menampilkan halaman login teknisi & admin
func LoginFormHandler(w http.ResponseWriter, r *http.Request) {
	if middleware.GetUserFromContext(r) != nil {
		http.Redirect(w, r, "/admin/dashboard", http.StatusSeeOther)
		return
	}

	next := r.URL.Query().Get("next")
	RenderTemplate(w, r, "admin/login.html", PageData{
		Title:     "Login Teknisi IT Support",
		ActiveNav: "login",
		Data: map[string]string{
			"Next": next,
		},
	})
}

// LoginSubmitHandler memproses autentikasi teknisi & admin
func LoginSubmitHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Redirect(w, r, "/admin/login", http.StatusSeeOther)
		return
	}

	username := strings.TrimSpace(r.FormValue("username"))
	if username == "" {
		username = strings.TrimSpace(r.FormValue("email"))
	}
	password := strings.TrimSpace(r.FormValue("password"))
	next := r.FormValue("next")

	if username == "" || password == "" {
		RenderTemplate(w, r, "admin/login.html", PageData{
			Title:      "Login Teknisi IT Support",
			ActiveNav:  "login",
			FlashError: "Username dan kata sandi wajib diisi",
			Data: map[string]string{
				"Username": username,
				"Next":     next,
			},
		})
		return
	}

	user, err := database.GetUserByUsernameOrEmail(username)
	if err != nil {
		RenderTemplate(w, r, "admin/login.html", PageData{
			Title:      "Login Teknisi IT Support",
			ActiveNav:  "login",
			FlashError: "Username atau kata sandi tidak cocok",
			Data: map[string]string{
				"Username": username,
				"Next":     next,
			},
		})
		return
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)); err != nil {
		RenderTemplate(w, r, "admin/login.html", PageData{
			Title:      "Login Teknisi IT Support",
			ActiveNav:  "login",
			FlashError: "Username atau kata sandi tidak cocok",
			Data: map[string]string{
				"Username": username,
				"Next":     next,
			},
		})
		return
	}

	// Buat session baru (berlaku 24 jam)
	token, err := database.CreateSession(user.ID, 24*time.Hour)
	if err != nil {
		http.Error(w, "Gagal membuat sesi: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// Set cookie session
	http.SetCookie(w, &http.Cookie{
		Name:     "session_token",
		Value:    token,
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   86400, // 24 jam
	})

	if next == "" || !strings.HasPrefix(next, "/admin") {
		next = "/admin/dashboard"
	}
	http.Redirect(w, r, next, http.StatusSeeOther)
}

// LogoutHandler menghapus sesi dan logout teknisi
func LogoutHandler(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session_token")
	if err == nil && cookie.Value != "" {
		_ = database.DeleteSession(cookie.Value)
	}

	http.SetCookie(w, &http.Cookie{
		Name:     "session_token",
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		HttpOnly: true,
	})

	SetFlash(w, "flash_success", "Anda telah berhasil keluar dari sistem.")
	http.Redirect(w, r, "/admin/login", http.StatusSeeOther)
}
