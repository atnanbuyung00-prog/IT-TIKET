package handlers

import (
	"encoding/json"
	"fmt"
	"html/template"
	"net/http"
	"strings"
	"time"

	"it-ticket-support/internal/database"
	"it-ticket-support/internal/middleware"
	"it-ticket-support/internal/models"
)

type PageData struct {
	Title              string
	ActiveNav          string
	CurrentUser        *models.User
	FlashSuccess       string
	FlashError         string
	Data               interface{}
	RingtonePreference string
	SoundEnabled       bool
}

// TemplateFuncs menyediakan fungsi pembantu untuk rendering template HTML
func TemplateFuncs() template.FuncMap {
	return template.FuncMap{
		"statusBadge": func(status string) template.HTML {
			var badgeClass string
			var icon string
			switch status {
			case "Open":
				badgeClass = "badge-status-open"
				icon = "<i class=\"bi bi-envelope-open me-1\"></i>"
			case "In Progress":
				badgeClass = "badge-status-inprogress"
				icon = "<i class=\"bi bi-arrow-repeat me-1\"></i>"
			case "Pending":
				badgeClass = "badge-status-pending"
				icon = "<i class=\"bi bi-clock-history me-1\"></i>"
			case "Resolved":
				badgeClass = "badge-status-resolved"
				icon = "<i class=\"bi bi-check-circle me-1\"></i>"
			case "Closed":
				badgeClass = "badge-status-closed"
				icon = "<i class=\"bi bi-archive me-1\"></i>"
			default:
				badgeClass = "badge-status-closed"
				icon = ""
			}
			return template.HTML(fmt.Sprintf(`<span class="badge %s font-monospace">%s<span>%s</span></span>`, badgeClass, icon, template.HTMLEscapeString(status)))
		},
		"priorityBadge": func(priority string) template.HTML {
			var badgeClass string
			var icon string
			switch priority {
			case "Darurat":
				badgeClass = "badge-priority-darurat animate-pulse"
				icon = "<i class=\"bi bi-exclamation-triangle-fill me-1\"></i>"
			case "Tinggi":
				badgeClass = "badge-priority-tinggi"
				icon = "<i class=\"bi bi-exclamation-circle me-1\"></i>"
			case "Sedang":
				badgeClass = "badge-priority-sedang"
				icon = "<i class=\"bi bi-dash-circle me-1\"></i>"
			case "Rendah":
				badgeClass = "badge-priority-rendah"
				icon = "<i class=\"bi bi-arrow-down-circle me-1\"></i>"
			default:
				badgeClass = "badge-status-closed"
				icon = ""
			}
			return template.HTML(fmt.Sprintf(`<span class="badge %s">%s<span>%s</span></span>`, badgeClass, icon, template.HTMLEscapeString(priority)))
		},
		"categoryGroupBadge": func(category string) template.HTML {
			group := database.ClassifyCategoryGroup(category)
			var badgeClass string
			var icon string
			switch group {
			case "Hardware":
				badgeClass = "badge-cat-hardware"
				icon = "<i class=\"bi bi-pc-display me-1\"></i>"
			case "Software":
				badgeClass = "badge-cat-software"
				icon = "<i class=\"bi bi-window-stack me-1\"></i>"
			case "Jaringan & Akun":
				badgeClass = "badge-cat-network"
				icon = "<i class=\"bi bi-router-fill me-1\"></i>"
			default:
				badgeClass = "badge-cat-other"
				icon = "<i class=\"bi bi-tag-fill me-1\"></i>"
			}
			return template.HTML(fmt.Sprintf(`<span class="badge %s">%s<span>%s</span></span>`, badgeClass, icon, template.HTMLEscapeString(group)))
		},
		"categoryGroupName": func(category string) string {
			return database.ClassifyCategoryGroup(category)
		},
		"formatDate": func(t time.Time) string {
			if t.IsZero() {
				return "-"
			}
			// Format Indonesia: 19 Okt 2026 14:05
			months := []string{
				"", "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
				"Jul", "Agu", "Sep", "Okt", "Nov", "Des",
			}
			loc := time.Local
			t = t.In(loc)
			return fmt.Sprintf("%02d %s %d %02d:%02d WIB",
				t.Day(), months[t.Month()], t.Year(), t.Hour(), t.Minute())
		},
		"formatTimeAgo": FormatTimeAgo,
		"isEqual": func(a, b interface{}) bool {
			if a == nil || b == nil {
				return a == b
			}
			valA := fmt.Sprintf("%v", a)
			if p, ok := a.(*int64); ok {
				if p != nil {
					valA = fmt.Sprintf("%d", *p)
				} else {
					return false
				}
			}
			valB := fmt.Sprintf("%v", b)
			if p, ok := b.(*int64); ok {
				if p != nil {
					valB = fmt.Sprintf("%d", *p)
				} else {
					return false
				}
			}
			return valA == valB
		},
		"contains": func(s, substr string) bool {
			return strings.Contains(s, substr)
		},
		"nl2br": func(text string) template.HTML {
			escaped := template.HTMLEscapeString(text)
			return template.HTML(strings.ReplaceAll(escaped, "\n", "<br>"))
		},
		"statusStepIndex": func(status string) int {
			switch status {
			case "Open":
				return 1
			case "In Progress":
				return 2
			case "Pending":
				return 2
			case "Resolved":
				return 3
			case "Closed":
				return 4
			default:
				return 1
			}
		},
		"add": func(a, b int) int {
			return a + b
		},
		"canModifyTicket": func(t interface{}, u *models.User) bool {
			if u == nil {
				return false
			}
			if u.IsAdmin() {
				return true
			}
			var assignedTo *int64
			var status string
			switch ticket := t.(type) {
			case models.Ticket:
				assignedTo = ticket.AssignedTo
				status = ticket.Status
			case *models.Ticket:
				if ticket == nil {
					return false
				}
				assignedTo = ticket.AssignedTo
				status = ticket.Status
			default:
				return false
			}

			// Jika tiket sudah memiliki penugasan teknisi (sudah diubah/dikerjakan):
			if assignedTo != nil && *assignedTo != 0 {
				return *assignedTo == u.ID
			}

			// Jika tiket belum ditugaskan ke siapapun, hanya bisa diambil jika statusnya Open
			return status == "Open"
		},
		"toJson": func(v interface{}) template.JS {
			b, err := json.Marshal(v)
			if err != nil {
				return template.JS("[]")
			}
			return template.JS(b)
		},
		"initials": func(name string) string {
			name = strings.TrimSpace(name)
			if name == "" {
				return "U"
			}
			parts := strings.Fields(name)
			if len(parts) >= 2 {
				r1 := []rune(parts[0])
				r2 := []rune(parts[1])
				return strings.ToUpper(string(r1[0]) + string(r2[0]))
			}
			r := []rune(name)
			return strings.ToUpper(string(r[0]))
		},
	}
}

// RenderTemplate merender file template dengan master layout
func RenderTemplate(w http.ResponseWriter, r *http.Request, tmplName string, data PageData) {
	// Isi data currentUser jika ada di context
	if data.CurrentUser == nil {
		data.CurrentUser = middleware.GetUserFromContext(r)
	}

	// Baca flash message dari cookie jika ada
	if data.FlashSuccess == "" {
		if c, err := r.Cookie("flash_success"); err == nil && c.Value != "" {
			data.FlashSuccess = c.Value
			// Hapus cookie setelah dibaca
			http.SetCookie(w, &http.Cookie{
				Name:   "flash_success",
				Value:  "",
				Path:   "/",
				MaxAge: -1,
			})
		}
	}
	if data.FlashError == "" {
		if c, err := r.Cookie("flash_error"); err == nil && c.Value != "" {
			data.FlashError = c.Value
			http.SetCookie(w, &http.Cookie{
				Name:   "flash_error",
				Value:  "",
				Path:   "/",
				MaxAge: -1,
			})
		}
	}

	// Baca preferensi nada dering dari cookie agar langsung terpilih di template
	if data.RingtonePreference == "" {
		if c, err := r.Cookie("it_ticket_ringtone_type"); err == nil && c.Value != "" {
			data.RingtonePreference = c.Value
		} else {
			data.RingtonePreference = "custom"
		}
	}
	if c, err := r.Cookie("it_ticket_sound_enabled"); err == nil && c.Value == "false" {
		data.SoundEnabled = false
	} else {
		data.SoundEnabled = true
	}

	files := []string{
		"web/templates/layout.html",
		fmt.Sprintf("web/templates/%s", tmplName),
	}

	tmpl, err := template.New("layout.html").Funcs(TemplateFuncs()).ParseFiles(files...)
	if err != nil {
		http.Error(w, fmt.Sprintf("Template parse error: %v", err), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.Execute(w, data); err != nil {
		http.Error(w, fmt.Sprintf("Template render error: %v", err), http.StatusInternalServerError)
	}
}

// SetFlash menyetel pesan notifikasi cepat via cookie
func SetFlash(w http.ResponseWriter, name, message string) {
	http.SetCookie(w, &http.Cookie{
		Name:     name,
		Value:    message,
		Path:     "/",
		HttpOnly: true,
		MaxAge:   30, // 30 detik
	})
}

// RenderJSON menuliskan respons JSON dengan status HTTP tertentu
func RenderJSON(w http.ResponseWriter, status int, data interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(data)
}

// FormatTimeAgo memformat durasi relatif waktu dalam bahasa Indonesia
func FormatTimeAgo(t time.Time) string {
	if t.IsZero() {
		return "-"
	}
	diff := time.Since(t)
	if diff < time.Minute {
		return "Baru saja"
	}
	if diff < time.Hour {
		mins := int(diff.Minutes())
		return fmt.Sprintf("%d menit lalu", mins)
	}
	if diff < 24*time.Hour {
		hours := int(diff.Hours())
		return fmt.Sprintf("%d jam lalu", hours)
	}
	days := int(diff.Hours() / 24)
	if days == 1 {
		return "Kemarin"
	}
	return fmt.Sprintf("%d hari lalu", days)
}


