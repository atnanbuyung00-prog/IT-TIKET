package handlers

import (
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"it-ticket-support/internal/database"
	"it-ticket-support/internal/middleware"
	"it-ticket-support/internal/models"

	"github.com/xuri/excelize/v2"
)

// AdminExportExcelHandler menghasilkan dan mengunduh file spreadsheet Excel (.xlsx) dengan format rapi dan filter lengkap
func AdminExportExcelHandler(w http.ResponseWriter, r *http.Request) {
	filterType := strings.TrimSpace(r.URL.Query().Get("filter_type"))
	startDate := strings.TrimSpace(r.URL.Query().Get("start_date"))
	endDate := strings.TrimSpace(r.URL.Query().Get("end_date"))
	monthStr := strings.TrimSpace(r.URL.Query().Get("month"))
	yearStr := strings.TrimSpace(r.URL.Query().Get("year"))
	period := strings.TrimSpace(r.URL.Query().Get("period"))
	status := strings.TrimSpace(r.URL.Query().Get("status"))
	category := strings.TrimSpace(r.URL.Query().Get("category"))
	dept := strings.TrimSpace(r.URL.Query().Get("department"))

	month, _ := strconv.Atoi(monthStr)
	year, _ := strconv.Atoi(yearStr)

	// Deteksi filterType jika belum diset eksplisit
	if filterType == "" {
		if startDate != "" || endDate != "" {
			filterType = "range"
		} else if monthStr != "" && monthStr != "0" {
			filterType = "month"
		} else if yearStr != "" && yearStr != "0" && yearStr != "all" {
			filterType = "year"
		} else if period != "" {
			filterType = "period"
		} else {
			filterType = "all"
		}
	}

	tickets, periodLabel, fileName, err := database.GetTicketsForExport(filterType, startDate, endDate, month, year, period, status, category, dept)
	if err != nil {
		http.Error(w, "Gagal memuat data tiket untuk ekspor: "+err.Error(), http.StatusInternalServerError)
		return
	}

	user := middleware.GetUserFromContext(r)
	userName := "Administrator IT"
	if user != nil {
		userName = user.Name
	}

	f := excelize.NewFile()
	defer func() { _ = f.Close() }()

	sheetData := "Data Tiket IT"
	f.SetSheetName("Sheet1", sheetData)

	// Styles
	titleStyle, _ := f.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true, Size: 16, Color: "1e3a8a"},
		Alignment: &excelize.Alignment{Vertical: "center"},
	})
	subTitleStyle, _ := f.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Italic: true, Size: 10, Color: "64748b"},
		Alignment: &excelize.Alignment{Vertical: "center"},
	})
	headerStyle, _ := f.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true, Color: "ffffff", Size: 11},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"1d4ed8"}, Pattern: 1},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center", WrapText: true},
		Border: []excelize.Border{
			{Type: "left", Color: "cbd5e1", Style: 1},
			{Type: "top", Color: "cbd5e1", Style: 1},
			{Type: "right", Color: "cbd5e1", Style: 1},
			{Type: "bottom", Color: "cbd5e1", Style: 1},
		},
	})
	borderStyle, _ := f.NewStyle(&excelize.Style{
		Border: []excelize.Border{
			{Type: "left", Color: "e2e8f0", Style: 1},
			{Type: "top", Color: "e2e8f0", Style: 1},
			{Type: "right", Color: "e2e8f0", Style: 1},
			{Type: "bottom", Color: "e2e8f0", Style: 1},
		},
		Alignment: &excelize.Alignment{Vertical: "center"},
	})
	centerBorderStyle, _ := f.NewStyle(&excelize.Style{
		Border: []excelize.Border{
			{Type: "left", Color: "e2e8f0", Style: 1},
			{Type: "top", Color: "e2e8f0", Style: 1},
			{Type: "right", Color: "e2e8f0", Style: 1},
			{Type: "bottom", Color: "e2e8f0", Style: 1},
		},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})
	zebraStyle, _ := f.NewStyle(&excelize.Style{
		Fill: excelize.Fill{Type: "pattern", Color: []string{"f8fafc"}, Pattern: 1},
		Border: []excelize.Border{
			{Type: "left", Color: "e2e8f0", Style: 1},
			{Type: "top", Color: "e2e8f0", Style: 1},
			{Type: "right", Color: "e2e8f0", Style: 1},
			{Type: "bottom", Color: "e2e8f0", Style: 1},
		},
		Alignment: &excelize.Alignment{Vertical: "center"},
	})

	// Judul Header Dokumen
	_ = f.SetCellValue(sheetData, "A1", "LAPORAN TIKET IT SUPPORT & SIMRS - RS MUTIARA AINI")
	_ = f.SetCellStyle(sheetData, "A1", "A1", titleStyle)

	infoStr := fmt.Sprintf("Kriteria Filter: %s | Total: %d Tiket | Dicetak Oleh: %s | Tanggal Unduh: %s",
		periodLabel, len(tickets), userName, time.Now().Format("02 Jan 2006 15:04 WIB"))
	_ = f.SetCellValue(sheetData, "A2", infoStr)
	_ = f.SetCellStyle(sheetData, "A2", "A2", subTitleStyle)

	// Header Kolom Tabel
	headers := []string{
		"No", "No. Tiket", "Waktu Dibuat", "Nama Pemohon", "Email Pemohon",
		"No. Telp", "Divisi / Ruangan", "Kategori Masalah", "Prioritas",
		"Subjek Kendala", "Status", "Teknisi Penanggung Jawab", "Waktu Selesai", "Deskripsi Masalah",
	}

	startRow := 4
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, startRow)
		_ = f.SetCellValue(sheetData, cell, h)
		_ = f.SetCellStyle(sheetData, cell, cell, headerStyle)
	}
	_ = f.SetRowHeight(sheetData, startRow, 28)

	// Kategori & Status map untuk statistik analisis Sheet 2
	catCountMap := make(map[string]int)
	statusCountMap := make(map[string]int)

	// Isi Data Baris Tabel
	for idx, t := range tickets {
		rowNum := startRow + 1 + idx
		currStyle := borderStyle
		if idx%2 == 1 {
			currStyle = zebraStyle
		}

		resolvedStr := "-"
		if t.ResolvedAt != nil {
			resolvedStr = t.ResolvedAt.Format("02/01/2006 15:04")
		}

		// Hitung statistik
		catCountMap[t.Category]++
		statusCountMap[t.Status]++

		reqEmail := t.RequesterEmail
		if reqEmail == "-" {
			reqEmail = "Tidak dicantumkan"
		}
		reqPhone := t.RequesterPhone
		if reqPhone == "-" || reqPhone == "" {
			reqPhone = "Tidak dicantumkan"
		}

		rowValues := []interface{}{
			idx + 1,
			t.TicketCode,
			t.CreatedAt.Format("02/01/2006 15:04"),
			t.RequesterName,
			reqEmail,
			reqPhone,
			t.Department,
			t.Category,
			t.Priority,
			t.Subject,
			t.Status,
			t.TechnicianName,
			resolvedStr,
			t.Description,
		}

		for cIdx, val := range rowValues {
			cell, _ := excelize.CoordinatesToCellName(cIdx+1, rowNum)
			_ = f.SetCellValue(sheetData, cell, val)
			if cIdx == 0 || cIdx == 1 || cIdx == 2 || cIdx == 8 || cIdx == 10 || cIdx == 12 {
				_ = f.SetCellStyle(sheetData, cell, cell, centerBorderStyle)
			} else {
				_ = f.SetCellStyle(sheetData, cell, cell, currStyle)
			}
		}
		_ = f.SetRowHeight(sheetData, rowNum, 22)
	}

	// Atur Lebar Kolom agar Rapi
	colWidths := map[string]float64{
		"A": 6,  // No
		"B": 22, // No Tiket
		"C": 18, // Waktu Dibuat
		"D": 22, // Pemohon
		"E": 25, // Email
		"F": 18, // Telp
		"G": 24, // Departemen
		"H": 20, // Kategori
		"I": 14, // Prioritas
		"J": 35, // Subjek
		"K": 15, // Status
		"L": 24, // Teknisi
		"M": 18, // Waktu Selesai
		"N": 40, // Deskripsi
	}
	for col, width := range colWidths {
		_ = f.SetColWidth(sheetData, col, col, width)
	}

	// SHEET 2: Ringkasan & Analisis Kendala
	sheetSummary := "Ringkasan & Analisis"
	_, _ = f.NewSheet(sheetSummary)

	_ = f.SetCellValue(sheetSummary, "A1", "RINGKASAN & ANALISIS KENDALA IT & SIMRS - RS MUTIARA AINI")
	_ = f.SetCellStyle(sheetSummary, "A1", "A1", titleStyle)
	_ = f.SetCellValue(sheetSummary, "A2", "Filter Analisis: "+periodLabel)
	_ = f.SetCellStyle(sheetSummary, "A2", "A2", subTitleStyle)

	// Urutkan kategori terbanyak
	var topCats []models.ChartItem
	for cName, cCount := range catCountMap {
		topCats = append(topCats, models.ChartItem{Label: cName, Count: cCount})
	}
	// Sort descending
	for i := 0; i < len(topCats)-1; i++ {
		for j := i + 1; j < len(topCats); j++ {
			if topCats[j].Count > topCats[i].Count {
				topCats[i], topCats[j] = topCats[j], topCats[i]
			}
		}
	}

	// Tabel 1: Kendala Terbanyak (Top Kategori)
	_ = f.SetCellValue(sheetSummary, "A4", "KATEGORI KENDALA PALING BANYAK PADA PERIODE INI")
	_ = f.SetCellStyle(sheetSummary, "A4", "A4", subTitleStyle)

	_ = f.SetCellValue(sheetSummary, "A5", "No")
	_ = f.SetCellValue(sheetSummary, "B5", "Kategori Masalah")
	_ = f.SetCellValue(sheetSummary, "C5", "Jumlah Tiket")
	_ = f.SetCellValue(sheetSummary, "D5", "Persentase")
	_ = f.SetCellStyle(sheetSummary, "A5", "D5", headerStyle)

	tot := len(tickets)
	for i, c := range topCats {
		rNum := 6 + i
		pct := 0.0
		if tot > 0 {
			pct = float64(c.Count) / float64(tot) * 100.0
		}
		_ = f.SetCellValue(sheetSummary, fmt.Sprintf("A%d", rNum), i+1)
		_ = f.SetCellValue(sheetSummary, fmt.Sprintf("B%d", rNum), c.Label)
		_ = f.SetCellValue(sheetSummary, fmt.Sprintf("C%d", rNum), c.Count)
		_ = f.SetCellValue(sheetSummary, fmt.Sprintf("D%d", rNum), fmt.Sprintf("%.1f%%", pct))
		_ = f.SetCellStyle(sheetSummary, fmt.Sprintf("A%d", rNum), fmt.Sprintf("A%d", rNum), centerBorderStyle)
		_ = f.SetCellStyle(sheetSummary, fmt.Sprintf("B%d", rNum), fmt.Sprintf("B%d", rNum), borderStyle)
		_ = f.SetCellStyle(sheetSummary, fmt.Sprintf("C%d", rNum), fmt.Sprintf("D%d", rNum), centerBorderStyle)
	}

	// Tabel 2: Distribusi Status
	statusStartRow := 8 + len(topCats)
	_ = f.SetCellValue(sheetSummary, fmt.Sprintf("A%d", statusStartRow), "DISTRIBUSI STATUS PENANGANAN TIKET")
	_ = f.SetCellStyle(sheetSummary, fmt.Sprintf("A%d", statusStartRow), fmt.Sprintf("A%d", statusStartRow), subTitleStyle)

	_ = f.SetCellValue(sheetSummary, fmt.Sprintf("A%d", statusStartRow+1), "No")
	_ = f.SetCellValue(sheetSummary, fmt.Sprintf("B%d", statusStartRow+1), "Status Tiket")
	_ = f.SetCellValue(sheetSummary, fmt.Sprintf("C%d", statusStartRow+1), "Jumlah")
	_ = f.SetCellStyle(sheetSummary, fmt.Sprintf("A%d", statusStartRow+1), fmt.Sprintf("C%d", statusStartRow+1), headerStyle)

	allStatuses := []string{"Open", "In Progress", "Pending", "Resolved", "Closed"}
	for j, st := range allStatuses {
		count := statusCountMap[st]
		rNum := statusStartRow + 2 + j
		_ = f.SetCellValue(sheetSummary, fmt.Sprintf("A%d", rNum), j+1)
		_ = f.SetCellValue(sheetSummary, fmt.Sprintf("B%d", rNum), st)
		_ = f.SetCellValue(sheetSummary, fmt.Sprintf("C%d", rNum), count)
		_ = f.SetCellStyle(sheetSummary, fmt.Sprintf("A%d", rNum), fmt.Sprintf("A%d", rNum), centerBorderStyle)
		_ = f.SetCellStyle(sheetSummary, fmt.Sprintf("B%d", rNum), fmt.Sprintf("B%d", rNum), borderStyle)
		_ = f.SetCellStyle(sheetSummary, fmt.Sprintf("C%d", rNum), fmt.Sprintf("C%d", rNum), centerBorderStyle)
	}

	_ = f.SetColWidth(sheetSummary, "A", "A", 6)
	_ = f.SetColWidth(sheetSummary, "B", "B", 30)
	_ = f.SetColWidth(sheetSummary, "C", "C", 16)
	_ = f.SetColWidth(sheetSummary, "D", "D", 16)

	// Set header HTTP untuk unduhan file
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, fileName))

	if err := f.Write(w); err != nil {
		http.Error(w, "Gagal menulis file Excel: "+err.Error(), http.StatusInternalServerError)
	}
}
