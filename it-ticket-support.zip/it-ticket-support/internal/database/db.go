package database

import (
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"golang.org/x/crypto/bcrypt"
	_ "modernc.org/sqlite"
)

var DB *sql.DB

func InitDB(dbPath string) (*sql.DB, error) {
	// Pastikan direktori database ada
	dir := filepath.Dir(dbPath)
	if dir != "" && dir != "." {
		if err := os.MkdirAll(dir, 0755); err != nil {
			return nil, fmt.Errorf("gagal membuat direktori database: %w", err)
		}
	}

	db, err := sql.Open("sqlite", dbPath)
	if err != nil {
		return nil, fmt.Errorf("gagal membuka database: %w", err)
	}

	// Optimasi SQLite untuk web app concurrency
	db.SetMaxOpenConns(1)
	db.SetMaxIdleConns(1)

	pragmas := []string{
		"PRAGMA foreign_keys = ON;",
		"PRAGMA journal_mode = WAL;",
		"PRAGMA busy_timeout = 5000;",
	}
	for _, pragma := range pragmas {
		if _, err := db.Exec(pragma); err != nil {
			log.Printf("Warning setting pragma '%s': %v", pragma, err)
		}
	}

	if err := createTables(db); err != nil {
		return nil, fmt.Errorf("gagal membuat tabel: %w", err)
	}

	if err := seedDefaultData(db); err != nil {
		db.Close()
		return nil, fmt.Errorf("inisialisasi data awal: %w", err)
	}

	DB = db
	RefreshCategoryCache()
	return db, nil
}

func createTables(db *sql.DB) error {
	schema := `
	CREATE TABLE IF NOT EXISTS users (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		name TEXT NOT NULL,
		username TEXT UNIQUE,
		email TEXT UNIQUE NOT NULL,
		password TEXT NOT NULL,
		role TEXT NOT NULL DEFAULT 'technician',
		phone TEXT,
		can_manage_tickets INTEGER DEFAULT 1,
		can_manage_master INTEGER DEFAULT 0,
		can_manage_users INTEGER DEFAULT 0,
		last_notified_ticket_id INTEGER DEFAULT 0,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS categories (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		name TEXT UNIQUE NOT NULL,
		section TEXT DEFAULT 'Hardware',
		description TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS departments (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		name TEXT UNIQUE NOT NULL,
		description TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS tickets (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		ticket_code TEXT UNIQUE NOT NULL,
		requester_name TEXT NOT NULL,
		requester_email TEXT NOT NULL,
		requester_phone TEXT,
		department TEXT NOT NULL,
		category TEXT NOT NULL,
		priority TEXT NOT NULL DEFAULT 'Sedang',
		subject TEXT NOT NULL,
		description TEXT NOT NULL,
		attachment TEXT,
		status TEXT NOT NULL DEFAULT 'Open',
		assigned_to INTEGER,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		resolved_at DATETIME,
		FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
	);

	CREATE TABLE IF NOT EXISTS ticket_updates (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		ticket_id INTEGER NOT NULL,
		user_id INTEGER,
		sender_name TEXT NOT NULL,
		sender_type TEXT NOT NULL, -- 'requester', 'technician', 'system'
		message TEXT NOT NULL,
		is_internal INTEGER DEFAULT 0,
		attachment TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
		FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
	);

	CREATE TABLE IF NOT EXISTS sessions (
		token TEXT PRIMARY KEY,
		user_id INTEGER NOT NULL,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		expires_at DATETIME NOT NULL,
		FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
	);

	CREATE TABLE IF NOT EXISTS telegram_subscribers (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		chat_id TEXT UNIQUE NOT NULL,
		name TEXT NOT NULL DEFAULT '',
		username TEXT DEFAULT '',
		is_active INTEGER DEFAULT 1,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS telegram_settings (
		key TEXT PRIMARY KEY,
		value TEXT NOT NULL
	);
	`
	if _, err := db.Exec(schema); err != nil {
		return err
	}

	// Migrasi otomatis kolom username & hak akses jika tabel users sudah ada dari versi sebelumnya
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN username TEXT;")
	_, _ = db.Exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username) WHERE username IS NOT NULL AND username != '';")
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN can_manage_tickets INTEGER DEFAULT 1;")
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN can_manage_master INTEGER DEFAULT 0;")
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN can_manage_users INTEGER DEFAULT 0;")

	// Update username default untuk akun bawaan
	_, _ = db.Exec("UPDATE users SET username = 'admin' WHERE (username IS NULL OR username = '') AND (email = 'admin@itsupport.local' OR role = 'admin');")
	_, _ = db.Exec("UPDATE users SET username = 'teknisi' WHERE (username IS NULL OR username = '') AND email = 'teknisi@itsupport.local';")
	_, _ = db.Exec("UPDATE users SET username = 'eko' WHERE (username IS NULL OR username = '') AND email = 'eko@itsupport.local';")
	// Untuk user lain yang username-nya masih kosong, generate username dari nama sebelum @ di email
	_, _ = db.Exec("UPDATE users SET username = LOWER(SUBSTR(email, 1, INSTR(email, '@') - 1)) WHERE username IS NULL OR username = '';")

	// Update admin agar selalu memiliki hak akses penuh
	_, _ = db.Exec("UPDATE users SET can_manage_tickets = 1, can_manage_master = 1, can_manage_users = 1 WHERE role = 'admin'")

	// Migrasi otomatis kolom last_notified_ticket_id di tabel users untuk melacak notifikasi per-teknisi
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN last_notified_ticket_id INTEGER DEFAULT 0;")

	// Set nilai default last_notified_ticket_id untuk user yang masih 0 / NULL ke tiket terbaru agar tiket lama tidak membunyikan alarm
	var currentMaxTicketID int64
	_ = db.QueryRow("SELECT COALESCE(MAX(id), 0) FROM tickets").Scan(&currentMaxTicketID)
	_, _ = db.Exec("UPDATE users SET last_notified_ticket_id = ? WHERE last_notified_ticket_id IS NULL OR last_notified_ticket_id = 0", currentMaxTicketID)

	// Migrasi otomatis kolom section di tabel categories untuk memisahkan bagian Hardware, Software, Jaringan & Akun, Lainnya
	_, _ = db.Exec("ALTER TABLE categories ADD COLUMN section TEXT DEFAULT '';")

	// Backfill section untuk kategori yang section-nya masih kosong
	type unassignedCat struct {
		id   int64
		name string
	}
	var unassigned []unassignedCat
	if catRows, err := db.Query("SELECT id, name FROM categories WHERE section IS NULL OR section = ''"); err == nil {
		for catRows.Next() {
			var item unassignedCat
			if err := catRows.Scan(&item.id, &item.name); err == nil {
				unassigned = append(unassigned, item)
			}
		}
		catRows.Close()

		for _, item := range unassigned {
			grp := ClassifyCategoryGroup(item.name)
			_, _ = db.Exec("UPDATE categories SET section = ? WHERE id = ?", grp, item.id)
		}
	}

	// Migrasi kolom telegram_chat_id di tabel users
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN telegram_chat_id TEXT DEFAULT '';")

	return nil
}

func seedDefaultData(db *sql.DB) error {
	// 1. Seed Kategori Layanan IT RS Mutiara Aini (Dikelompokkan per Bagian)
	hospitalCategories := []struct {
		name    string
		section string
		desc    string
	}{
		{"SIMRS & Rekam Medis Elektronik (RME)", "Software", "Sistem Informasi Manajemen Rumah Sakit, input SOAP dokter/perawat, billing pasien, riwayat medis"},
		{"Bridging BPJS (V-Claim / PCare / Antrean)", "Software", "Koneksi web service BPJS Kesehatan, SEP rawat jalan/inap, rujukan online, antrean Mobile JKN"},
		{"Printer Label & Gelang Pasien", "Hardware", "Printer barcode poli/farmasi, cetak gelang identitas pasien rawat inap, printer thermal struk kasir"},
		{"Jaringan & WiFi Rumah Sakit", "Jaringan & Akun", "Koneksi LAN komputer poli, WiFi bangsal rawat inap, internet IGD, VPN rumah sakit"},
		{"Hardware Komputer & Monitor", "Hardware", "PC dokter/perawat, monitor poli, scanner resep/KTP, UPS ruang kritis, mouse/keyboard"},
		{"Penunjang Medis (LIS / RIS / PACS)", "Software", "Sistem informasi laboratorium (LIS), radiologi (RIS), dan arsip gambar rontgen/CT-Scan (PACS)"},
		{"Email, Akun & Hak Akses User", "Jaringan & Akun", "Pembuatan akun staf baru, reset password SIMRS, otorisasi dokter DPJP dan perawat"},
		{"Hardware & Perangkat Medis", "Hardware", "Perangkat keras: Komputer, Laptop, Monitor, Keyboard, Mouse, Motherboard, RAM, Harddisk/SSD"},
		{"Software & OS Rumah Sakit", "Software", "Sistem operasi Windows/Linux, driver alat medis, Microsoft Office, instalasi aplikasi penunjang"},
		{"Lainnya / Sarana IT", "Lainnya", "Kendala teknis IT lainnya, permohonan kabel/aksesoris, atau konsultasi kebutuhan perangkat"},
	}
	for _, c := range hospitalCategories {
		_, _ = db.Exec("INSERT OR IGNORE INTO categories (name, section, description) VALUES (?, ?, ?)", c.name, c.section, c.desc)
	}

	// 2. Seed Departemen / Unit Kerja RS Mutiara Aini
	hospitalDepartments := []struct {
		name string
		desc string
	}{
		{"Instalasi Gawat Darurat (IGD)", "Unit penanganan pasien gawat darurat 24 jam"},
		{"Poliklinik / Rawat Jalan", "Poli Dokter Spesialis (Penyakit Dalam, Anak, Obgyn, Bedah, Gigi, dll.)"},
		{"Rawat Inap (Ranap)", "Ruang perawatan inap pasien, bangsal, dan nurse station"},
		{"Farmasi & Apotek", "Instalasi Farmasi, penyiapan obat, telaah resep dokter, dan stok obat"},
		{"Laboratorium & Patologi", "Instalasi pemeriksaan darah, urine, kimia klinik, dan mikrobiologi"},
		{"Radiologi (Rontgen / USG / CT-Scan)", "Instalasi pencitraan diagnostik medis"},
		{"Rekam Medis (Medical Records)", "Unit pengelolaan data rekam medis pasien & pengarsipan dokumen"},
		{"Kasir & Keuangan RS", "Kasir pembayaran pasien umum/asuransi, verifikasi billing, klaim BPJS & keuangan"},
		{"Admisi & Pendaftaran Pasien (Admission)", "Loket pendaftaran rawat jalan, rawat inap, dan verifikasi kepesertaan"},
		{"Kamar Operasi (IBS / OK)", "Instalasi Bedah Sentral dan ruang operasi"},
		{"Intensive Care (ICU / HCU / NICU)", "Unit perawatan intensif dan ruang monitoring pasien kritis"},
		{"Manajemen & Administrasi RS", "Direksi, HRD, Umum, Logistik, dan Kesekretariatan Rumah Sakit"},
	}
	for _, d := range hospitalDepartments {
		_, _ = db.Exec("INSERT OR IGNORE INTO departments (name, description) VALUES (?, ?)", d.name, d.desc)
	}

	// 3. Seed User Default jika belum ada user
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM users").Scan(&count)
	if err != nil {
		return err
	}
	if count > 0 {
		return nil
	}

	password := os.Getenv("INITIAL_ADMIN_PASSWORD")
	if len(password) < 12 || len(password) > 72 || strings.TrimSpace(password) != password {
		return fmt.Errorf("atur INITIAL_ADMIN_PASSWORD sepanjang 12–72 byte tanpa spasi di awal atau akhir")
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	_, err = db.Exec(`INSERT INTO users (name, username, email, password, role, can_manage_tickets, can_manage_master, can_manage_users)
 VALUES (?, ?, ?, ?, ?, 1, 1, 1)`, "Administrator IT", "admin", "admin@itsupport.local", string(hash), "admin")
	return err
}

// GenerateTicketCode membuat kode tiket unik format TCK-YYYYMMDD-XXXX
func GenerateTicketCode() string {
	dateStr := time.Now().Format("20060102")
	b := make([]byte, 2)
	_, _ = rand.Read(b)
	randStr := strings.ToUpper(hex.EncodeToString(b))
	return fmt.Sprintf("TCK-%s-%s", dateStr, randStr)
}
