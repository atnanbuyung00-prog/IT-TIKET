package database

import (
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"golang.org/x/crypto/bcrypt"
	_ "modernc.org/sqlite"
)

var DB *sql.DB

func InitDB(dbPath string) (*sql.DB, error) {
	// Pastikan direktori database ada
	dir := filepath.Dir(dbPath)
	if dir != "" && dir != "." {
		if err := os.MkdirAll(dir, 0755); err != nil {
			return nil, fmt.Errorf("gagal membuat direktori database: %w", err)
		}
	}

	db, err := sql.Open("sqlite", dbPath)
	if err != nil {
		return nil, fmt.Errorf("gagal membuka database: %w", err)
	}

	// Optimasi SQLite untuk web app concurrency
	db.SetMaxOpenConns(1)
	db.SetMaxIdleConns(1)

	pragmas := []string{
		"PRAGMA foreign_keys = ON;",
		"PRAGMA journal_mode = WAL;",
		"PRAGMA busy_timeout = 5000;",
	}
	for _, pragma := range pragmas {
		if _, err := db.Exec(pragma); err != nil {
			log.Printf("Warning setting pragma '%s': %v", pragma, err)
		}
	}

	if err := createTables(db); err != nil {
		return nil, fmt.Errorf("gagal membuat tabel: %w", err)
	}

	if err := seedDefaultData(db); err != nil {
		log.Printf("Warning saat seeding data awal: %v", err)
	}

	DB = db
	RefreshCategoryCache()
	return db, nil
}

func createTables(db *sql.DB) error {
	schema := `
	CREATE TABLE IF NOT EXISTS users (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		name TEXT NOT NULL,
		username TEXT UNIQUE,
		email TEXT UNIQUE NOT NULL,
		password TEXT NOT NULL,
		role TEXT NOT NULL DEFAULT 'technician',
		phone TEXT,
		can_manage_tickets INTEGER DEFAULT 1,
		can_manage_master INTEGER DEFAULT 0,
		can_manage_users INTEGER DEFAULT 0,
		last_notified_ticket_id INTEGER DEFAULT 0,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS categories (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		name TEXT UNIQUE NOT NULL,
		section TEXT DEFAULT 'Hardware',
		description TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS departments (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		name TEXT UNIQUE NOT NULL,
		description TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS tickets (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		ticket_code TEXT UNIQUE NOT NULL,
		requester_name TEXT NOT NULL,
		requester_email TEXT NOT NULL,
		requester_phone TEXT,
		department TEXT NOT NULL,
		category TEXT NOT NULL,
		priority TEXT NOT NULL DEFAULT 'Sedang',
		subject TEXT NOT NULL,
		description TEXT NOT NULL,
		attachment TEXT,
		status TEXT NOT NULL DEFAULT 'Open',
		assigned_to INTEGER,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		resolved_at DATETIME,
		FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
	);

	CREATE TABLE IF NOT EXISTS ticket_updates (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		ticket_id INTEGER NOT NULL,
		user_id INTEGER,
		sender_name TEXT NOT NULL,
		sender_type TEXT NOT NULL, -- 'requester', 'technician', 'system'
		message TEXT NOT NULL,
		is_internal INTEGER DEFAULT 0,
		attachment TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
		FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
	);

	CREATE TABLE IF NOT EXISTS sessions (
		token TEXT PRIMARY KEY,
		user_id INTEGER NOT NULL,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		expires_at DATETIME NOT NULL,
		FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
	);

	CREATE TABLE IF NOT EXISTS telegram_subscribers (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		chat_id TEXT UNIQUE NOT NULL,
		name TEXT NOT NULL DEFAULT '',
		username TEXT DEFAULT '',
		is_active INTEGER DEFAULT 1,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS telegram_settings (
		key TEXT PRIMARY KEY,
		value TEXT NOT NULL
	);
	`
	if _, err := db.Exec(schema); err != nil {
		return err
	}

	// Migrasi otomatis kolom username & hak akses jika tabel users sudah ada dari versi sebelumnya
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN username TEXT;")
	_, _ = db.Exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username) WHERE username IS NOT NULL AND username != '';")
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN can_manage_tickets INTEGER DEFAULT 1;")
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN can_manage_master INTEGER DEFAULT 0;")
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN can_manage_users INTEGER DEFAULT 0;")

	// Update username default untuk akun bawaan
	_, _ = db.Exec("UPDATE users SET username = 'admin' WHERE (username IS NULL OR username = '') AND (email = 'admin@itsupport.local' OR role = 'admin');")
	_, _ = db.Exec("UPDATE users SET username = 'teknisi' WHERE (username IS NULL OR username = '') AND email = 'teknisi@itsupport.local';")
	_, _ = db.Exec("UPDATE users SET username = 'eko' WHERE (username IS NULL OR username = '') AND email = 'eko@itsupport.local';")
	// Untuk user lain yang username-nya masih kosong, generate username dari nama sebelum @ di email
	_, _ = db.Exec("UPDATE users SET username = LOWER(SUBSTR(email, 1, INSTR(email, '@') - 1)) WHERE username IS NULL OR username = '';")

	// Update admin agar selalu memiliki hak akses penuh
	_, _ = db.Exec("UPDATE users SET can_manage_tickets = 1, can_manage_master = 1, can_manage_users = 1 WHERE role = 'admin'")

	// Migrasi otomatis kolom last_notified_ticket_id di tabel users untuk melacak notifikasi per-teknisi
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN last_notified_ticket_id INTEGER DEFAULT 0;")

	// Set nilai default last_notified_ticket_id untuk user yang masih 0 / NULL ke tiket terbaru agar tiket lama tidak membunyikan alarm
	var currentMaxTicketID int64
	_ = db.QueryRow("SELECT COALESCE(MAX(id), 0) FROM tickets").Scan(&currentMaxTicketID)
	_, _ = db.Exec("UPDATE users SET last_notified_ticket_id = ? WHERE last_notified_ticket_id IS NULL OR last_notified_ticket_id = 0", currentMaxTicketID)

	// Migrasi otomatis kolom section di tabel categories untuk memisahkan bagian Hardware, Software, Jaringan & Akun, Lainnya
	_, _ = db.Exec("ALTER TABLE categories ADD COLUMN section TEXT DEFAULT '';")

	// Backfill section untuk kategori yang section-nya masih kosong
	type unassignedCat struct {
		id   int64
		name string
	}
	var unassigned []unassignedCat
	if catRows, err := db.Query("SELECT id, name FROM categories WHERE section IS NULL OR section = ''"); err == nil {
		for catRows.Next() {
			var item unassignedCat
			if err := catRows.Scan(&item.id, &item.name); err == nil {
				unassigned = append(unassigned, item)
			}
		}
		catRows.Close()

		for _, item := range unassigned {
			grp := ClassifyCategoryGroup(item.name)
			_, _ = db.Exec("UPDATE categories SET section = ? WHERE id = ?", grp, item.id)
		}
	}

	// Migrasi kolom telegram_chat_id di tabel users
	_, _ = db.Exec("ALTER TABLE users ADD COLUMN telegram_chat_id TEXT DEFAULT '';")

	// Inisialisasi default bot token & status aktif
	_, _ = db.Exec("INSERT OR IGNORE INTO telegram_settings (key, value) VALUES ('bot_token', '9108076489:AAGyGQThGjhRwXvXH_zVGgOB1bFZ9a2aEoQ');")
	_, _ = db.Exec("INSERT OR IGNORE INTO telegram_settings (key, value) VALUES ('bot_enabled', '1');")
	_, _ = db.Exec("INSERT OR IGNORE INTO telegram_settings (key, value) VALUES ('bot_username', 'AiniDeskbot');")

	// Daftarkan akun atnan (5502041173) secara otomatis sebagai subscriber awal
	_, _ = db.Exec("INSERT OR IGNORE INTO telegram_subscribers (chat_id, name, username, is_active) VALUES ('5502041173', 'atnan b', 'atnan', 1);")
	_, _ = db.Exec("UPDATE users SET telegram_chat_id = '5502041173' WHERE (telegram_chat_id IS NULL OR telegram_chat_id = '') AND (username = 'atnan' OR email LIKE '%atnan%');")

	return nil
}

func seedDefaultData(db *sql.DB) error {
	// 1. Seed Kategori Layanan IT RS Mutiara Aini (Dikelompokkan per Bagian)
	hospitalCategories := []struct {
		name    string
		section string
		desc    string
	}{
		{"SIMRS & Rekam Medis Elektronik (RME)", "Software", "Sistem Informasi Manajemen Rumah Sakit, input SOAP dokter/perawat, billing pasien, riwayat medis"},
		{"Bridging BPJS (V-Claim / PCare / Antrean)", "Software", "Koneksi web service BPJS Kesehatan, SEP rawat jalan/inap, rujukan online, antrean Mobile JKN"},
		{"Printer Label & Gelang Pasien", "Hardware", "Printer barcode poli/farmasi, cetak gelang identitas pasien rawat inap, printer thermal struk kasir"},
		{"Jaringan & WiFi Rumah Sakit", "Jaringan & Akun", "Koneksi LAN komputer poli, WiFi bangsal rawat inap, internet IGD, VPN rumah sakit"},
		{"Hardware Komputer & Monitor", "Hardware", "PC dokter/perawat, monitor poli, scanner resep/KTP, UPS ruang kritis, mouse/keyboard"},
		{"Penunjang Medis (LIS / RIS / PACS)", "Software", "Sistem informasi laboratorium (LIS), radiologi (RIS), dan arsip gambar rontgen/CT-Scan (PACS)"},
		{"Email, Akun & Hak Akses User", "Jaringan & Akun", "Pembuatan akun staf baru, reset password SIMRS, otorisasi dokter DPJP dan perawat"},
		{"Hardware & Perangkat Medis", "Hardware", "Perangkat keras: Komputer, Laptop, Monitor, Keyboard, Mouse, Motherboard, RAM, Harddisk/SSD"},
		{"Software & OS Rumah Sakit", "Software", "Sistem operasi Windows/Linux, driver alat medis, Microsoft Office, instalasi aplikasi penunjang"},
		{"Lainnya / Sarana IT", "Lainnya", "Kendala teknis IT lainnya, permohonan kabel/aksesoris, atau konsultasi kebutuhan perangkat"},
	}
	for _, c := range hospitalCategories {
		_, _ = db.Exec("INSERT OR IGNORE INTO categories (name, section, description) VALUES (?, ?, ?)", c.name, c.section, c.desc)
	}

	// 2. Seed Departemen / Unit Kerja RS Mutiara Aini
	hospitalDepartments := []struct {
		name string
		desc string
	}{
		{"Instalasi Gawat Darurat (IGD)", "Unit penanganan pasien gawat darurat 24 jam"},
		{"Poliklinik / Rawat Jalan", "Poli Dokter Spesialis (Penyakit Dalam, Anak, Obgyn, Bedah, Gigi, dll.)"},
		{"Rawat Inap (Ranap)", "Ruang perawatan inap pasien, bangsal, dan nurse station"},
		{"Farmasi & Apotek", "Instalasi Farmasi, penyiapan obat, telaah resep dokter, dan stok obat"},
		{"Laboratorium & Patologi", "Instalasi pemeriksaan darah, urine, kimia klinik, dan mikrobiologi"},
		{"Radiologi (Rontgen / USG / CT-Scan)", "Instalasi pencitraan diagnostik medis"},
		{"Rekam Medis (Medical Records)", "Unit pengelolaan data rekam medis pasien & pengarsipan dokumen"},
		{"Kasir & Keuangan RS", "Kasir pembayaran pasien umum/asuransi, verifikasi billing, klaim BPJS & keuangan"},
		{"Admisi & Pendaftaran Pasien (Admission)", "Loket pendaftaran rawat jalan, rawat inap, dan verifikasi kepesertaan"},
		{"Kamar Operasi (IBS / OK)", "Instalasi Bedah Sentral dan ruang operasi"},
		{"Intensive Care (ICU / HCU / NICU)", "Unit perawatan intensif dan ruang monitoring pasien kritis"},
		{"Manajemen & Administrasi RS", "Direksi, HRD, Umum, Logistik, dan Kesekretariatan Rumah Sakit"},
	}
	for _, d := range hospitalDepartments {
		_, _ = db.Exec("INSERT OR IGNORE INTO departments (name, description) VALUES (?, ?)", d.name, d.desc)
	}

	// 3. Seed User Default jika belum ada user
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM users").Scan(&count)
	if err != nil {
		return err
	}
	if count > 0 {
		return nil
	}

	adminPass, _ := bcrypt.GenerateFromPassword([]byte("admin123"), bcrypt.DefaultCost)
	techPass, _ := bcrypt.GenerateFromPassword([]byte("teknisi123"), bcrypt.DefaultCost)

	// Admin (Akses Penuh: Tiket, Master Data, Kelola User)
	_, _ = db.Exec(`
		INSERT INTO users (name, username, email, password, role, phone, can_manage_tickets, can_manage_master, can_manage_users)
		VALUES (?, ?, ?, ?, ?, ?, 1, 1, 1)
	`, "Administrator IT", "admin", "admin@itsupport.local", string(adminPass), "admin", "081234567890")

	// Teknisi 1 (Akses Tiket saja)
	_, _ = db.Exec(`
		INSERT INTO users (name, username, email, password, role, phone, can_manage_tickets, can_manage_master, can_manage_users)
		VALUES (?, ?, ?, ?, ?, ?, 1, 0, 0)
	`, "Budi Santoso (Teknisi)", "teknisi", "teknisi@itsupport.local", string(techPass), "technician", "081234567891")

	// Teknisi 2 (Akses Tiket + Master Data)
	_, _ = db.Exec(`
		INSERT INTO users (name, username, email, password, role, phone, can_manage_tickets, can_manage_master, can_manage_users)
		VALUES (?, ?, ?, ?, ?, ?, 1, 1, 0)
	`, "Eko Prasetyo (Teknisi Jaringan)", "eko", "eko@itsupport.local", string(techPass), "technician", "081234567892")

	// 4. Masukkan sample tiket contoh
	sampleTickets := []struct {
		code        string
		reqName     string
		reqEmail    string
		phone       string
		dept        string
		category    string
		priority    string
		subject     string
		desc        string
		status      string
		assignedTo  int64
		createdAgo  time.Duration
		resolvedAgo time.Duration
	}{
		{
			code:       "TCK-20261019-A1B2",
			reqName:    "Siti Aminah",
			reqEmail:   "siti.aminah@company.com",
			phone:      "085712349999",
			dept:       "Finance & Accounting",
			category:   "Software",
			priority:   "Tinggi",
			subject:    "Aplikasi SAP tidak bisa login setelah update Windows",
			desc:       "Pagi IT Support, sejak komputer saya restart otomatis tadi pagi, muncul error 'Cannot connect to SAP GUI server'. Tolong bantuannya karena sedang proses closing bulanan.",
			status:     "In Progress",
			assignedTo: 2,
			createdAgo: 3 * time.Hour,
		},
		{
			code:       "TCK-20261019-C3D4",
			reqName:    "Rian Hidayat",
			reqEmail:   "rian.hidayat@company.com",
			phone:      "081987654321",
			dept:       "Marketing & Sales",
			category:   "Hardware",
			priority:   "Sedang",
			subject:    "Printer Epson L3110 di Lantai 2 Paper Jam terus menerus",
			desc:       "Sudah coba bersihkan roller kertas tapi setiap tarik kertas macet di tengah. Lampu indikator tinta dan kertas berkedip bergantian.",
			status:     "Open",
			assignedTo: 0,
			createdAgo: 1 * time.Hour,
		},
		{
			code:        "TCK-20261018-E5F6",
			reqName:     "Dewi Sartika",
			reqEmail:    "dewi.sartika@company.com",
			phone:       "087812345678",
			dept:        "Human Resources & GA",
			category:    "Jaringan / Network",
			priority:    "Sedang",
			subject:     "Koneksi WiFi Ruang HR lantai 3 terputus-putus",
			desc:        "Sinyal WiFi sering drop dan IP conflict saat banyak peserta interview connect ke SSID 'Office-Staff'.",
			status:      "Resolved",
			assignedTo:  3,
			createdAgo:  24 * time.Hour,
			resolvedAgo: 6 * time.Hour,
		},
	}

	for _, st := range sampleTickets {
		now := time.Now()
		createdAt := now.Add(-st.createdAgo)
		var resolvedAt *time.Time
		if st.status == "Resolved" || st.status == "Closed" {
			t := now.Add(-st.resolvedAgo)
			resolvedAt = &t
		}

		var assignedSQL interface{} = nil
		if st.assignedTo > 0 {
			assignedSQL = st.assignedTo
		}

		res, err := db.Exec(`
			INSERT INTO tickets (ticket_code, requester_name, requester_email, requester_phone, department, category, priority, subject, description, status, assigned_to, created_at, updated_at, resolved_at)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
		`, st.code, st.reqName, st.reqEmail, st.phone, st.dept, st.category, st.priority, st.subject, st.desc, st.status, assignedSQL, createdAt, createdAt, resolvedAt)

		if err != nil {
			continue
		}

		ticketID, _ := res.LastInsertId()

		// Initial update log
		_, _ = db.Exec(`
			INSERT INTO ticket_updates (ticket_id, sender_name, sender_type, message, is_internal, created_at)
			VALUES (?, ?, 'system', 'Tiket berhasil dibuat oleh pemohon', 0, ?)
		`, ticketID, st.reqName, createdAt)

		if st.status == "In Progress" {
			_, _ = db.Exec(`
				INSERT INTO ticket_updates (ticket_id, user_id, sender_name, sender_type, message, is_internal, created_at)
				VALUES (?, 2, 'Budi Santoso (Teknisi)', 'technician', 'Halo Bu Siti, tiket sudah saya terima. Saya sedang remote cek konfigurasi hosts dan registry SAP di PC Ibu.', 0, ?)
			`, ticketID, createdAt.Add(30*time.Minute))
		} else if st.status == "Resolved" {
			_, _ = db.Exec(`
				INSERT INTO ticket_updates (ticket_id, user_id, sender_name, sender_type, message, is_internal, created_at)
				VALUES (?, 3, 'Eko Prasetyo (Teknisi Jaringan)', 'technician', 'Access Point Lantai 3 sudah di-restart dan kanal frekuensi dipindahkan ke channel 6 untuk menghindari interferensi. Masalah teratasi.', 0, ?)
			`, ticketID, now.Add(-st.resolvedAgo))
		}
	}

	return nil
}

// GenerateTicketCode membuat kode tiket unik format TCK-YYYYMMDD-XXXX
func GenerateTicketCode() string {
	dateStr := time.Now().Format("20060102")
	b := make([]byte, 2)
	_, _ = rand.Read(b)
	randStr := strings.ToUpper(hex.EncodeToString(b))
	return fmt.Sprintf("TCK-%s-%s", dateStr, randStr)
}
