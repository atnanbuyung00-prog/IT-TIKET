package database

import (
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"
	"unicode"

	"it-ticket-support/internal/models"

	"golang.org/x/crypto/bcrypt"
)

// User & Auth Queries

func GetUserByUsernameOrEmail(identifier string) (*models.User, error) {
	u := &models.User{}
	var canTickets, canMaster, canUsers int
	query := `
		SELECT id, name, COALESCE(username, ''), email, password, role, COALESCE(phone, ''),
		       can_manage_tickets, can_manage_master, can_manage_users, COALESCE(telegram_chat_id, ''), created_at
		FROM users
		WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)
	`
	err := DB.QueryRow(query, identifier, identifier).Scan(
		&u.ID, &u.Name, &u.Username, &u.Email, &u.Password, &u.Role, &u.Phone,
		&canTickets, &canMaster, &canUsers, &u.TelegramChatID, &u.CreatedAt,
	)
	if err != nil {
		return nil, err
	}
	u.CanManageTickets = canTickets == 1 || u.Role == "admin"
	u.CanManageMaster = canMaster == 1 || u.Role == "admin"
	u.CanManageUsers = canUsers == 1 || u.Role == "admin"
	return u, nil
}

func GetUserByEmail(email string) (*models.User, error) {
	return GetUserByUsernameOrEmail(email)
}

func GetUserByID(id int64) (*models.User, error) {
	u := &models.User{}
	var canTickets, canMaster, canUsers int
	query := `
		SELECT id, name, COALESCE(username, ''), email, role, COALESCE(phone, ''),
		       can_manage_tickets, can_manage_master, can_manage_users, COALESCE(telegram_chat_id, ''), created_at
		FROM users
		WHERE id = ?
	`
	err := DB.QueryRow(query, id).Scan(
		&u.ID, &u.Name, &u.Username, &u.Email, &u.Role, &u.Phone,
		&canTickets, &canMaster, &canUsers, &u.TelegramChatID, &u.CreatedAt,
	)
	if err != nil {
		return nil, err
	}
	u.CanManageTickets = canTickets == 1 || u.Role == "admin"
	u.CanManageMaster = canMaster == 1 || u.Role == "admin"
	u.CanManageUsers = canUsers == 1 || u.Role == "admin"
	return u, nil
}

func GetAllTechnicians() ([]models.User, error) {
	rows, err := DB.Query(`
		SELECT id, name, COALESCE(username, ''), email, role, COALESCE(phone, ''),
		       can_manage_tickets, can_manage_master, can_manage_users, COALESCE(telegram_chat_id, ''), created_at
		FROM users
		ORDER BY CASE role WHEN 'admin' THEN 1 ELSE 2 END, name ASC
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var users []models.User
	for rows.Next() {
		var u models.User
		var canTickets, canMaster, canUsers int
		if err := rows.Scan(
			&u.ID, &u.Name, &u.Username, &u.Email, &u.Role, &u.Phone,
			&canTickets, &canMaster, &canUsers, &u.TelegramChatID, &u.CreatedAt,
		); err != nil {
			return nil, err
		}
		u.CanManageTickets = canTickets == 1 || u.Role == "admin"
		u.CanManageMaster = canMaster == 1 || u.Role == "admin"
		u.CanManageUsers = canUsers == 1 || u.Role == "admin"
		users = append(users, u)
	}
	return users, nil
}

func CreateUser(name, username, email, plainPassword, role, phone string, canTickets, canMaster, canUsers bool) (*models.User, error) {
	hashed, err := bcrypt.GenerateFromPassword([]byte(plainPassword), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	username = strings.TrimSpace(username)
	if username == "" {
		parts := strings.Split(email, "@")
		username = strings.ToLower(parts[0])
	}

	canT := 0
	if canTickets || role == "admin" {
		canT = 1
	}
	canM := 0
	if canMaster || role == "admin" {
		canM = 1
	}
	canU := 0
	if canUsers || role == "admin" {
		canU = 1
	}

	var currentMaxID int64
	_ = DB.QueryRow("SELECT COALESCE(MAX(id), 0) FROM tickets").Scan(&currentMaxID)

	res, err := DB.Exec(`
		INSERT INTO users (name, username, email, password, role, phone, can_manage_tickets, can_manage_master, can_manage_users, last_notified_ticket_id)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
	`, name, username, email, string(hashed), role, phone, canT, canM, canU, currentMaxID)
	if err != nil {
		return nil, err
	}

	id, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}

	return GetUserByID(id)
}

func UpdateUser(id int64, name, username, email, role, phone string, canTickets, canMaster, canUsers bool, newPassword string) error {
	canT := 0
	if canTickets || role == "admin" {
		canT = 1
	}
	canM := 0
	if canMaster || role == "admin" {
		canM = 1
	}
	canU := 0
	if canUsers || role == "admin" {
		canU = 1
	}

	username = strings.TrimSpace(username)
	if username == "" {
		parts := strings.Split(email, "@")
		username = strings.ToLower(parts[0])
	}

	if strings.TrimSpace(newPassword) != "" {
		hashed, err := bcrypt.GenerateFromPassword([]byte(newPassword), bcrypt.DefaultCost)
		if err != nil {
			return err
		}
		_, err = DB.Exec(`
			UPDATE users
			SET name = ?, username = ?, email = ?, password = ?, role = ?, phone = ?,
			    can_manage_tickets = ?, can_manage_master = ?, can_manage_users = ?
			WHERE id = ?
		`, name, username, email, string(hashed), role, phone, canT, canM, canU, id)
		return err
	}

	_, err := DB.Exec(`
		UPDATE users
		SET name = ?, username = ?, email = ?, role = ?, phone = ?,
		    can_manage_tickets = ?, can_manage_master = ?, can_manage_users = ?
		WHERE id = ?
	`, name, username, email, role, phone, canT, canM, canU, id)
	return err
}

func DeleteUser(id int64) error {
	// Lepas penugasan tiket dari teknisi yang dihapus
	_, _ = DB.Exec(`UPDATE tickets SET assigned_to = NULL WHERE assigned_to = ?`, id)
	_, err := DB.Exec(`DELETE FROM users WHERE id = ?`, id)
	return err
}

// GetUserPasswordHash mengambil hash password pengguna untuk verifikasi
func GetUserPasswordHash(userID int64) (string, error) {
	var hashed string
	err := DB.QueryRow(`SELECT password FROM users WHERE id = ?`, userID).Scan(&hashed)
	return hashed, err
}

// IsUsernameTaken mengecek apakah username sudah digunakan akun lain
func IsUsernameTaken(username string, excludeUserID int64) (bool, error) {
	var count int
	err := DB.QueryRow(`SELECT COUNT(*) FROM users WHERE LOWER(username) = LOWER(?) AND id != ?`, strings.TrimSpace(username), excludeUserID).Scan(&count)
	return count > 0, err
}

// IsEmailTaken mengecek apakah email sudah digunakan akun lain
func IsEmailTaken(email string, excludeUserID int64) (bool, error) {
	var count int
	err := DB.QueryRow(`SELECT COUNT(*) FROM users WHERE LOWER(email) = LOWER(?) AND id != ?`, strings.TrimSpace(email), excludeUserID).Scan(&count)
	return count > 0, err
}

// UpdateUserProfile memperbarui profil pengguna saat ini (nama, username, email, telepon)
func UpdateUserProfile(userID int64, name, username, email, phone string) error {
	name = strings.TrimSpace(name)
	username = strings.TrimSpace(username)
	email = strings.TrimSpace(email)
	phone = strings.TrimSpace(phone)
	_, err := DB.Exec(`
		UPDATE users
		SET name = ?, username = ?, email = ?, phone = ?
		WHERE id = ?
	`, name, username, email, phone, userID)
	return err
}

// UpdateUserPassword memperbarui kata sandi akun pengguna dengan hashing bcrypt
func UpdateUserPassword(userID int64, newPassword string) error {
	hashed, err := bcrypt.GenerateFromPassword([]byte(newPassword), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	_, err = DB.Exec(`UPDATE users SET password = ? WHERE id = ?`, string(hashed), userID)
	return err
}

// Session queries

func CreateSession(userID int64, duration time.Duration) (string, error) {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	token := hex.EncodeToString(b)
	expiresAt := time.Now().Add(duration)

	_, err := DB.Exec(`INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)`,
		token, userID, expiresAt)
	if err != nil {
		return "", err
	}
	return token, nil
}

func GetSession(token string) (*models.Session, error) {
	query := `
		SELECT s.token, s.user_id, s.created_at, s.expires_at,
		       u.id, u.name, COALESCE(u.username, ''), u.email, u.role, COALESCE(u.phone, ''),
		       u.can_manage_tickets, u.can_manage_master, u.can_manage_users, u.created_at
		FROM sessions s
		JOIN users u ON s.user_id = u.id
		WHERE s.token = ? AND s.expires_at > CURRENT_TIMESTAMP
	`
	sess := &models.Session{User: &models.User{}}
	var canTickets, canMaster, canUsers int
	err := DB.QueryRow(query, token).Scan(
		&sess.Token, &sess.UserID, &sess.CreatedAt, &sess.ExpiresAt,
		&sess.User.ID, &sess.User.Name, &sess.User.Username, &sess.User.Email, &sess.User.Role, &sess.User.Phone,
		&canTickets, &canMaster, &canUsers, &sess.User.CreatedAt,
	)
	if err != nil {
		return nil, err
	}
	sess.User.CanManageTickets = canTickets == 1 || sess.User.Role == "admin"
	sess.User.CanManageMaster = canMaster == 1 || sess.User.Role == "admin"
	sess.User.CanManageUsers = canUsers == 1 || sess.User.Role == "admin"
	return sess, nil
}

func DeleteSession(token string) error {
	_, err := DB.Exec(`DELETE FROM sessions WHERE token = ?`, token)
	return err
}

// Category Master Data Queries

func GetAllCategories() ([]models.Category, error) {
	query := `
		SELECT c.id, c.name, COALESCE(c.section, ''), COALESCE(c.description, ''), c.created_at,
		       (SELECT COUNT(*) FROM tickets t WHERE LOWER(t.category) = LOWER(c.name)) as ticket_count
		FROM categories c
		ORDER BY c.name ASC
	`
	rows, err := DB.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var categories []models.Category
	for rows.Next() {
		var cat models.Category
		if err := rows.Scan(&cat.ID, &cat.Name, &cat.Section, &cat.Description, &cat.CreatedAt, &cat.TicketCount); err != nil {
			return nil, err
		}
		if cat.Section == "" {
			cat.Section = ClassifyCategoryGroup(cat.Name)
		}
		cat.CategoryGroup = cat.Section
		categories = append(categories, cat)
	}
	return categories, nil
}

func GetCategoryByID(id int64) (*models.Category, error) {
	cat := &models.Category{}
	err := DB.QueryRow(`
		SELECT c.id, c.name, COALESCE(c.section, ''), COALESCE(c.description, ''), c.created_at,
		       (SELECT COUNT(*) FROM tickets t WHERE LOWER(t.category) = LOWER(c.name)) as ticket_count
		FROM categories c
		WHERE c.id = ?
	`, id).Scan(&cat.ID, &cat.Name, &cat.Section, &cat.Description, &cat.CreatedAt, &cat.TicketCount)
	if err != nil {
		return nil, err
	}
	if cat.Section == "" {
		cat.Section = ClassifyCategoryGroup(cat.Name)
	}
	cat.CategoryGroup = cat.Section
	return cat, nil
}

var (
	categorySectionCache = make(map[string]string)
	categoryCacheMu      sync.RWMutex
)

// RefreshCategoryCache memuat pemetaan nama kategori -> section dari database ke cache memori
func RefreshCategoryCache() {
	if DB == nil {
		return
	}
	rows, err := DB.Query(`SELECT LOWER(name), section FROM categories WHERE section IS NOT NULL AND section != ''`)
	if err != nil {
		return
	}
	defer rows.Close()

	newMap := make(map[string]string)
	for rows.Next() {
		var name, sec string
		if err := rows.Scan(&name, &sec); err == nil {
			newMap[strings.TrimSpace(name)] = strings.TrimSpace(sec)
		}
	}

	categoryCacheMu.Lock()
	categorySectionCache = newMap
	categoryCacheMu.Unlock()
}

func CreateCategory(name, section, description string) error {
	name = strings.TrimSpace(name)
	section = strings.TrimSpace(section)
	if name == "" {
		return fmt.Errorf("nama kategori tidak boleh kosong")
	}
	if section == "" {
		section = ClassifyCategoryGroup(name)
	}
	_, err := DB.Exec(`INSERT INTO categories (name, section, description) VALUES (?, ?, ?)`, name, section, strings.TrimSpace(description))
	if err == nil {
		RefreshCategoryCache()
	}
	return err
}

func UpdateCategory(id int64, newName, section, description string) error {
	newName = strings.TrimSpace(newName)
	section = strings.TrimSpace(section)
	if newName == "" {
		return fmt.Errorf("nama kategori tidak boleh kosong")
	}
	if section == "" {
		section = ClassifyCategoryGroup(newName)
	}

	// Ambil nama lama untuk update tiket yang sudah menggunakan kategori ini
	var oldName string
	err := DB.QueryRow(`SELECT name FROM categories WHERE id = ?`, id).Scan(&oldName)
	if err != nil {
		return err
	}

	// Update tiket lama jika namanya berubah
	if !strings.EqualFold(oldName, newName) {
		_, _ = DB.Exec(`UPDATE tickets SET category = ? WHERE LOWER(category) = LOWER(?)`, newName, oldName)
	}

	_, err = DB.Exec(`UPDATE categories SET name = ?, section = ?, description = ? WHERE id = ?`, newName, section, strings.TrimSpace(description), id)
	if err == nil {
		RefreshCategoryCache()
	}
	return err
}

func DeleteCategory(id int64) error {
	var name string
	var count int
	err := DB.QueryRow(`
		SELECT c.name, (SELECT COUNT(*) FROM tickets t WHERE LOWER(t.category) = LOWER(c.name))
		FROM categories c WHERE c.id = ?
	`, id).Scan(&name, &count)
	if err != nil {
		return err
	}

	if count > 0 {
		return fmt.Errorf("kategori '%s' masih digunakan oleh %d tiket. Ubah kategori tiket terkait terlebih dahulu sebelum menghapus", name, count)
	}

	_, err = DB.Exec(`DELETE FROM categories WHERE id = ?`, id)
	if err == nil {
		RefreshCategoryCache()
	}
	return err
}

// Department Master Data Queries

func GetAllDepartments() ([]models.Department, error) {
	query := `
		SELECT d.id, d.name, COALESCE(d.description, ''), d.created_at,
		       (SELECT COUNT(*) FROM tickets t WHERE LOWER(t.department) = LOWER(d.name)) as ticket_count
		FROM departments d
		ORDER BY d.name ASC
	`
	rows, err := DB.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var departments []models.Department
	for rows.Next() {
		var dept models.Department
		if err := rows.Scan(&dept.ID, &dept.Name, &dept.Description, &dept.CreatedAt, &dept.TicketCount); err != nil {
			return nil, err
		}
		departments = append(departments, dept)
	}
	return departments, nil
}

func GetDepartmentByID(id int64) (*models.Department, error) {
	dept := &models.Department{}
	err := DB.QueryRow(`
		SELECT d.id, d.name, COALESCE(d.description, ''), d.created_at,
		       (SELECT COUNT(*) FROM tickets t WHERE LOWER(t.department) = LOWER(d.name)) as ticket_count
		FROM departments d
		WHERE d.id = ?
	`, id).Scan(&dept.ID, &dept.Name, &dept.Description, &dept.CreatedAt, &dept.TicketCount)
	if err != nil {
		return nil, err
	}
	return dept, nil
}

func CreateDepartment(name, description string) error {
	name = strings.TrimSpace(name)
	if name == "" {
		return fmt.Errorf("nama departemen tidak boleh kosong")
	}
	_, err := DB.Exec(`INSERT INTO departments (name, description) VALUES (?, ?)`, name, strings.TrimSpace(description))
	return err
}

func UpdateDepartment(id int64, newName, description string) error {
	newName = strings.TrimSpace(newName)
	if newName == "" {
		return fmt.Errorf("nama departemen tidak boleh kosong")
	}

	var oldName string
	err := DB.QueryRow(`SELECT name FROM departments WHERE id = ?`, id).Scan(&oldName)
	if err != nil {
		return err
	}

	if !strings.EqualFold(oldName, newName) {
		_, _ = DB.Exec(`UPDATE tickets SET department = ? WHERE LOWER(department) = LOWER(?)`, newName, oldName)
	}

	_, err = DB.Exec(`UPDATE departments SET name = ?, description = ? WHERE id = ?`, newName, strings.TrimSpace(description), id)
	return err
}

func DeleteDepartment(id int64) error {
	var name string
	var count int
	err := DB.QueryRow(`
		SELECT d.name, (SELECT COUNT(*) FROM tickets t WHERE LOWER(t.department) = LOWER(d.name))
		FROM departments d WHERE d.id = ?
	`, id).Scan(&name, &count)
	if err != nil {
		return err
	}

	if count > 0 {
		return fmt.Errorf("departemen '%s' masih digunakan oleh %d tiket. Ubah departemen tiket terkait terlebih dahulu sebelum menghapus", name, count)
	}

	_, err = DB.Exec(`DELETE FROM departments WHERE id = ?`, id)
	return err
}

// Ticket Queries

// OnTicketCreatedHook dapat didaftarkan oleh modul lain (misal Telegram bot agent) untuk merespon pembuatan tiket baru
var OnTicketCreatedHook func(ticket *models.Ticket)

func CreateTicket(ticket *models.Ticket) (int64, string, error) {
	ticket.TicketCode = GenerateTicketCode()
	ticket.Status = "Open"
	now := time.Now()
	ticket.CreatedAt = now
	ticket.UpdatedAt = now

	res, err := DB.Exec(`
		INSERT INTO tickets (ticket_code, requester_name, requester_email, requester_phone, department, category, priority, subject, description, attachment, status, created_at, updated_at)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
	`, ticket.TicketCode, ticket.RequesterName, ticket.RequesterEmail, ticket.RequesterPhone, ticket.Department, ticket.Category, ticket.Priority, ticket.Subject, ticket.Description, ticket.Attachment, ticket.Status, ticket.CreatedAt, ticket.UpdatedAt)
	if err != nil {
		return 0, "", err
	}

	id, err := res.LastInsertId()
	if err != nil {
		return 0, "", err
	}
	ticket.ID = id

	_, _ = DB.Exec(`
		INSERT INTO ticket_updates (ticket_id, sender_name, sender_type, message, is_internal, created_at)
		VALUES (?, ?, 'system', 'Tiket baru telah dibuat oleh ' || ?, 0, ?)
	`, id, ticket.RequesterName, ticket.RequesterName, now)

	if OnTicketCreatedHook != nil {
		go OnTicketCreatedHook(ticket)
	}

	return id, ticket.TicketCode, nil
}

func GetTicketByCode(code string) (*models.Ticket, error) {
	query := `
		SELECT t.id, t.ticket_code, t.requester_name, t.requester_email, COALESCE(t.requester_phone, ''),
		       t.department, t.category, t.priority, t.subject, t.description, COALESCE(t.attachment, ''),
		       t.status, t.assigned_to, COALESCE(u.name, 'Belum ditugaskan') as tech_name,
		       t.created_at, t.updated_at, t.resolved_at
		FROM tickets t
		LEFT JOIN users u ON t.assigned_to = u.id
		WHERE UPPER(t.ticket_code) = UPPER(?)
	`
	t := &models.Ticket{}
	var resolvedAt sql.NullTime
	var assignedTo sql.NullInt64

	err := DB.QueryRow(query, strings.TrimSpace(code)).Scan(
		&t.ID, &t.TicketCode, &t.RequesterName, &t.RequesterEmail, &t.RequesterPhone,
		&t.Department, &t.Category, &t.Priority, &t.Subject, &t.Description, &t.Attachment,
		&t.Status, &assignedTo, &t.TechnicianName,
		&t.CreatedAt, &t.UpdatedAt, &resolvedAt,
	)
	if err != nil {
		return nil, err
	}
	if resolvedAt.Valid {
		t.ResolvedAt = &resolvedAt.Time
	}
	if assignedTo.Valid {
		t.AssignedTo = &assignedTo.Int64
	}
	t.CategoryGroup = ClassifyCategoryGroup(t.Category)
	return t, nil
}

// GetMaxTicketID mengembalikan ID tiket terbesar yang ada di database saat ini
func GetMaxTicketID() (int64, error) {
	var maxID sql.NullInt64
	err := DB.QueryRow(`SELECT MAX(id) FROM tickets`).Scan(&maxID)
	if err != nil {
		return 0, err
	}
	if !maxID.Valid {
		return 0, nil
	}
	return maxID.Int64, nil
}

// GetNewTicketsSinceID mengambil tiket-tiket baru yang masuk setelah ID tertentu
func GetNewTicketsSinceID(sinceID int64, limit int) ([]models.Ticket, error) {
	if limit <= 0 {
		limit = 10
	}
	query := `
		SELECT t.id, t.ticket_code, t.requester_name, t.requester_email, COALESCE(t.requester_phone, ''),
		       t.department, t.category, t.priority, t.subject, t.status, t.created_at
		FROM tickets t
		WHERE t.id > ?
		ORDER BY t.id DESC
		LIMIT ?
	`
	rows, err := DB.Query(query, sinceID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tickets []models.Ticket
	for rows.Next() {
		var t models.Ticket
		err := rows.Scan(
			&t.ID, &t.TicketCode, &t.RequesterName, &t.RequesterEmail, &t.RequesterPhone,
			&t.Department, &t.Category, &t.Priority, &t.Subject, &t.Status, &t.CreatedAt,
		)
		if err != nil {
			return nil, err
		}
		tickets = append(tickets, t)
	}
	return tickets, nil
}

// GetUserLastNotifiedTicketID mengambil ID tiket terakhir yang telah dinotifikasikan ke user tertentu
func GetUserLastNotifiedTicketID(userID int64) (int64, error) {
	var lastID sql.NullInt64
	err := DB.QueryRow("SELECT last_notified_ticket_id FROM users WHERE id = ?", userID).Scan(&lastID)
	if err != nil || !lastID.Valid {
		return 0, err
	}
	return lastID.Int64, nil
}

// UpdateUserLastNotifiedTicketID memperbarui ID tiket terakhir yang telah dinotifikasikan ke user
func UpdateUserLastNotifiedTicketID(userID int64, ticketID int64) error {
	_, err := DB.Exec(`
		UPDATE users 
		SET last_notified_ticket_id = ? 
		WHERE id = ? AND (? > COALESCE(last_notified_ticket_id, 0))
	`, ticketID, userID, ticketID)
	return err
}

// GetNewTicketsForUserNotification mengambil tiket baru yang belum dinotifikasikan ke user tertentu
// Memprioritaskan tiket yang statusnya masih Open atau dibuat dalam 24 jam terakhir
func GetNewTicketsForUserNotification(sinceID int64, limit int) ([]models.Ticket, error) {
	if limit <= 0 {
		limit = 10
	}
	query := `
		SELECT t.id, t.ticket_code, t.requester_name, t.requester_email, COALESCE(t.requester_phone, ''),
		       t.department, t.category, t.priority, t.subject, t.status, t.created_at
		FROM tickets t
		WHERE t.id > ?
		  AND (t.status = 'Open' OR t.created_at >= datetime('now', '-24 hours'))
		ORDER BY t.id DESC
		LIMIT ?
	`
	rows, err := DB.Query(query, sinceID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tickets []models.Ticket
	for rows.Next() {
		var t models.Ticket
		err := rows.Scan(
			&t.ID, &t.TicketCode, &t.RequesterName, &t.RequesterEmail, &t.RequesterPhone,
			&t.Department, &t.Category, &t.Priority, &t.Subject, &t.Status, &t.CreatedAt,
		)
		if err != nil {
			return nil, err
		}
		tickets = append(tickets, t)
	}
	return tickets, nil
}




// GetRecentTicketsForNotification mengambil daftar tiket terbaru untuk ditampilkan di menu notifikasi
func GetRecentTicketsForNotification(limit int) ([]models.Ticket, error) {
	if limit <= 0 {
		limit = 5
	}
	query := `
		SELECT t.id, t.ticket_code, t.requester_name, t.requester_email, COALESCE(t.requester_phone, ''),
		       t.department, t.category, t.priority, t.subject, t.status, t.created_at
		FROM tickets t
		ORDER BY t.id DESC
		LIMIT ?
	`
	rows, err := DB.Query(query, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tickets []models.Ticket
	for rows.Next() {
		var t models.Ticket
		err := rows.Scan(
			&t.ID, &t.TicketCode, &t.RequesterName, &t.RequesterEmail, &t.RequesterPhone,
			&t.Department, &t.Category, &t.Priority, &t.Subject, &t.Status, &t.CreatedAt,
		)
		if err != nil {
			return nil, err
		}
		tickets = append(tickets, t)
	}
	return tickets, nil
}

func GetTicketByID(id int64) (*models.Ticket, error) {
	query := `
		SELECT t.id, t.ticket_code, t.requester_name, t.requester_email, COALESCE(t.requester_phone, ''),
		       t.department, t.category, t.priority, t.subject, t.description, COALESCE(t.attachment, ''),
		       t.status, t.assigned_to, COALESCE(u.name, 'Belum ditugaskan') as tech_name,
		       t.created_at, t.updated_at, t.resolved_at
		FROM tickets t
		LEFT JOIN users u ON t.assigned_to = u.id
		WHERE t.id = ?
	`
	t := &models.Ticket{}
	var resolvedAt sql.NullTime
	var assignedTo sql.NullInt64

	err := DB.QueryRow(query, id).Scan(
		&t.ID, &t.TicketCode, &t.RequesterName, &t.RequesterEmail, &t.RequesterPhone,
		&t.Department, &t.Category, &t.Priority, &t.Subject, &t.Description, &t.Attachment,
		&t.Status, &assignedTo, &t.TechnicianName,
		&t.CreatedAt, &t.UpdatedAt, &resolvedAt,
	)
	if err != nil {
		return nil, err
	}
	if resolvedAt.Valid {
		t.ResolvedAt = &resolvedAt.Time
	}
	if assignedTo.Valid {
		t.AssignedTo = &assignedTo.Int64
	}
	t.CategoryGroup = ClassifyCategoryGroup(t.Category)
	return t, nil
}

// GetActiveTicketsForDashboard mengambil daftar tiket aktif yang sedang dalam antrean pengerjaan
// (Open, In Progress, Pending). Tiket yang telah selesai (Resolved atau Closed) otomatis tidak tampil di dashboard.
func GetActiveTicketsForDashboard(limit int) ([]models.Ticket, error) {
	if limit <= 0 {
		limit = 10
	}
	query := `
		SELECT t.id, t.ticket_code, t.requester_name, t.requester_email, COALESCE(t.requester_phone, ''),
		       t.department, t.category, t.priority, t.subject, t.description, COALESCE(t.attachment, ''),
		       t.status, t.assigned_to, COALESCE(u.name, 'Belum ditugaskan') as tech_name,
		       t.created_at, t.updated_at, t.resolved_at
		FROM tickets t
		LEFT JOIN users u ON t.assigned_to = u.id
		WHERE t.status NOT IN ('Resolved', 'Closed')
		ORDER BY 
			CASE t.priority 
				WHEN 'Darurat' THEN 1 
				WHEN 'Tinggi' THEN 2 
				WHEN 'Sedang' THEN 3 
				ELSE 4 
			END,
			t.created_at DESC
		LIMIT ?
	`
	rows, err := DB.Query(query, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tickets []models.Ticket
	for rows.Next() {
		var t models.Ticket
		var resolvedAt sql.NullTime
		var assignedTo sql.NullInt64

		if err := rows.Scan(
			&t.ID, &t.TicketCode, &t.RequesterName, &t.RequesterEmail, &t.RequesterPhone,
			&t.Department, &t.Category, &t.Priority, &t.Subject, &t.Description, &t.Attachment,
			&t.Status, &assignedTo, &t.TechnicianName,
			&t.CreatedAt, &t.UpdatedAt, &resolvedAt,
		); err != nil {
			return nil, err
		}
		if resolvedAt.Valid {
			t.ResolvedAt = &resolvedAt.Time
		}
		if assignedTo.Valid {
			t.AssignedTo = &assignedTo.Int64
		}
		t.CategoryGroup = ClassifyCategoryGroup(t.Category)
		tickets = append(tickets, t)
	}
	return tickets, nil
}

func GetTickets(statusFilter, categoryFilter, priorityFilter, search string) ([]models.Ticket, error) {
	baseQuery := `
		SELECT t.id, t.ticket_code, t.requester_name, t.requester_email, COALESCE(t.requester_phone, ''),
		       t.department, t.category, t.priority, t.subject, t.description, COALESCE(t.attachment, ''),
		       t.status, t.assigned_to, COALESCE(u.name, 'Belum ditugaskan') as tech_name,
		       t.created_at, t.updated_at, t.resolved_at
		FROM tickets t
		LEFT JOIN users u ON t.assigned_to = u.id
		WHERE 1=1
	`
	var args []interface{}

	if statusFilter != "" && statusFilter != "All" {
		baseQuery += " AND t.status = ?"
		args = append(args, statusFilter)
	}
	if categoryFilter != "" && categoryFilter != "All" && !strings.HasPrefix(categoryFilter, "group:") {
		baseQuery += " AND t.category = ?"
		args = append(args, categoryFilter)
	}
	if priorityFilter != "" && priorityFilter != "All" {
		baseQuery += " AND t.priority = ?"
		args = append(args, priorityFilter)
	}
	if search != "" {
		baseQuery += " AND (t.ticket_code LIKE ? OR t.requester_name LIKE ? OR t.subject LIKE ? OR t.department LIKE ?)"
		pattern := "%" + search + "%"
		args = append(args, pattern, pattern, pattern, pattern)
	}

	baseQuery += " ORDER BY CASE t.priority WHEN 'Darurat' THEN 1 WHEN 'Tinggi' THEN 2 WHEN 'Sedang' THEN 3 ELSE 4 END, t.created_at DESC"

	rows, err := DB.Query(baseQuery, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tickets []models.Ticket
	for rows.Next() {
		var t models.Ticket
		var resolvedAt sql.NullTime
		var assignedTo sql.NullInt64

		if err := rows.Scan(
			&t.ID, &t.TicketCode, &t.RequesterName, &t.RequesterEmail, &t.RequesterPhone,
			&t.Department, &t.Category, &t.Priority, &t.Subject, &t.Description, &t.Attachment,
			&t.Status, &assignedTo, &t.TechnicianName,
			&t.CreatedAt, &t.UpdatedAt, &resolvedAt,
		); err != nil {
			return nil, err
		}
		if resolvedAt.Valid {
			t.ResolvedAt = &resolvedAt.Time
		}
		if assignedTo.Valid {
			t.AssignedTo = &assignedTo.Int64
		}
		t.CategoryGroup = ClassifyCategoryGroup(t.Category)
		if strings.HasPrefix(categoryFilter, "group:") {
			targetGroup := strings.TrimPrefix(categoryFilter, "group:")
			if !strings.EqualFold(t.CategoryGroup, targetGroup) {
				continue
			}
		}
		tickets = append(tickets, t)
	}
	return tickets, nil
}

func UpdateTicketStatusAndAssignee(ticketID int64, newStatus string, assignedTo *int64) error {
	now := time.Now()
	var resolvedAt interface{} = nil
	if newStatus == "Resolved" || newStatus == "Closed" {
		resolvedAt = now
	}

	var assignedSQL interface{} = nil
	if assignedTo != nil && *assignedTo > 0 {
		assignedSQL = *assignedTo
	}

	_, err := DB.Exec(`
		UPDATE tickets
		SET status = ?, assigned_to = ?, updated_at = ?, resolved_at = ?
		WHERE id = ?
	`, newStatus, assignedSQL, now, resolvedAt, ticketID)

	return err
}

// UpdateTicketDetails memperbarui detail informasi tiket (khusus administrator)
func UpdateTicketDetails(id int64, subject, description, category, department, priority, reqName, reqEmail, reqPhone string) error {
	now := time.Now()
	subject = strings.TrimSpace(subject)
	description = strings.TrimSpace(description)
	category = strings.TrimSpace(category)
	department = strings.TrimSpace(department)
	priority = strings.TrimSpace(priority)
	reqName = strings.TrimSpace(reqName)
	reqEmail = strings.TrimSpace(reqEmail)
	reqPhone = strings.TrimSpace(reqPhone)

	_, err := DB.Exec(`
		UPDATE tickets
		SET subject = ?, description = ?, category = ?, department = ?, priority = ?,
		    requester_name = ?, requester_email = ?, requester_phone = ?, updated_at = ?
		WHERE id = ?
	`, subject, description, category, department, priority, reqName, reqEmail, reqPhone, now, id)
	return err
}

// DeleteTicket menghapus tiket beserta seluruh log riwayat aktivitas/komentarnya (khusus administrator)
func DeleteTicket(id int64) error {
	// Hapus seluruh pembaruan/catatan tiket terkait terlebih dahulu
	_, _ = DB.Exec(`DELETE FROM ticket_updates WHERE ticket_id = ?`, id)
	_, err := DB.Exec(`DELETE FROM tickets WHERE id = ?`, id)
	return err
}

func AddTicketUpdate(update *models.TicketUpdate) error {
	now := time.Now()
	update.CreatedAt = now

	res, err := DB.Exec(`
		INSERT INTO ticket_updates (ticket_id, user_id, sender_name, sender_type, message, is_internal, attachment, created_at)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?)
	`, update.TicketID, update.UserID, update.SenderName, update.SenderType, update.Message, update.IsInternal, update.Attachment, now)
	if err != nil {
		return err
	}

	_, _ = DB.Exec(`UPDATE tickets SET updated_at = ? WHERE id = ?`, now, update.TicketID)

	id, err := res.LastInsertId()
	if err == nil {
		update.ID = id
	}
	return nil
}

func GetTicketUpdates(ticketID int64, includeInternal bool) ([]models.TicketUpdate, error) {
	query := `
		SELECT id, ticket_id, user_id, sender_name, sender_type, message, is_internal, COALESCE(attachment, ''), created_at
		FROM ticket_updates
		WHERE ticket_id = ?
	`
	if !includeInternal {
		query += " AND is_internal = 0"
	}
	query += " ORDER BY created_at ASC"

	rows, err := DB.Query(query, ticketID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var updates []models.TicketUpdate
	for rows.Next() {
		var u models.TicketUpdate
		var userID sql.NullInt64
		var isInternalInt int

		if err := rows.Scan(
			&u.ID, &u.TicketID, &userID, &u.SenderName, &u.SenderType,
			&u.Message, &isInternalInt, &u.Attachment, &u.CreatedAt,
		); err != nil {
			return nil, err
		}
		if userID.Valid {
			u.UserID = &userID.Int64
		}
		u.IsInternal = isInternalInt == 1
		updates = append(updates, u)
	}
	return updates, nil
}

func GetDashboardStats() (*models.DashboardStats, error) {
	stats := &models.DashboardStats{}

	row := DB.QueryRow(`
		SELECT 
			COUNT(*),
			COALESCE(SUM(CASE WHEN status = 'Open' THEN 1 ELSE 0 END), 0),
			COALESCE(SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END), 0),
			COALESCE(SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END), 0),
			COALESCE(SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END), 0),
			COALESCE(SUM(CASE WHEN status = 'Closed' THEN 1 ELSE 0 END), 0),
			COALESCE(SUM(CASE WHEN (priority = 'Darurat' OR priority = 'Tinggi') AND status NOT IN ('Resolved', 'Closed') THEN 1 ELSE 0 END), 0)
		FROM tickets
	`)

	err := row.Scan(
		&stats.TotalTickets,
		&stats.OpenTickets,
		&stats.InProgressTickets,
		&stats.PendingTickets,
		&stats.ResolvedTickets,
		&stats.ClosedTickets,
		&stats.UrgentTickets,
	)
	if err != nil {
		return nil, err
	}
	return stats, nil
}

// Helper untuk memisahkan kata secara presisi
func hasWord(s, word string) bool {
	fields := strings.FieldsFunc(s, func(r rune) bool {
		return !unicode.IsLetter(r) && !unicode.IsNumber(r)
	})
	for _, f := range fields {
		if strings.EqualFold(f, word) {
			return true
		}
	}
	return false
}

// ClassifyCategoryGroup mengelompokkan kategori teknis ke dalam 3 kelompok utama:
// Hardware, Software, dan Jaringan & Akun (serta Lainnya bila ada sisa).
// Prioritas utama diambil dari kolom section pada tabel categories di database.
func ClassifyCategoryGroup(cat string) string {
	trimmed := strings.TrimSpace(cat)
	if trimmed == "" {
		return "Lainnya"
	}

	// 1. Jika sudah merupakan nama kelompok utama
	switch trimmed {
	case "Hardware", "Software", "Jaringan & Akun", "Lainnya":
		return trimmed
	}

	// 2. Cek pemetaan database yang telah di-cache
	categoryCacheMu.RLock()
	sec, exists := categorySectionCache[strings.ToLower(trimmed)]
	categoryCacheMu.RUnlock()
	if exists && sec != "" {
		return sec
	}

	lower := strings.ToLower(trimmed)

	// 1. Jaringan & Akun
	networkSubstrings := []string{
		"jaringan", "network", "wifi", "wi-fi", "internet", "vpn",
		"mikrotik", "router", "switch", "koneksi", "email", "mail",
		"akun", "account", "akses", "password", "sso", "login",
	}
	for _, kw := range networkSubstrings {
		if strings.Contains(lower, kw) {
			return "Jaringan & Akun"
		}
	}
	if hasWord(lower, "lan") || hasWord(lower, "wlan") {
		return "Jaringan & Akun"
	}

	// 2. Hardware
	hardwareSubstrings := []string{
		"hardware", "komputer", "computer", "laptop", "desktop",
		"monitor", "layar", "printer", "scanner", "perangkat",
		"keyboard", "mouse", "ups", "cctv", "proyektor",
	}
	for _, kw := range hardwareSubstrings {
		if strings.Contains(lower, kw) {
			return "Hardware"
		}
	}
	if hasWord(lower, "pc") {
		return "Hardware"
	}

	// 3. Software
	softwareSubstrings := []string{
		"software", "aplikasi", "app", "simrs", "rme", "rekam medis",
		"bpjs", "v-claim", "vclaim", "pcare", "antrean", "lis", "ris", "pacs",
		"os", "windows", "linux", "office", "erp", "crm", "pos",
		"sistem", "program", "database", "driver", "bridging",
	}
	for _, kw := range softwareSubstrings {
		if strings.Contains(lower, kw) {
			return "Software"
		}
	}

	return "Lainnya"
}

func GetAnalyticsData(period string) (*models.AnalyticsData, error) {
	var dateFilter string
	var periodLabel string

	switch period {
	case "weekly":
		dateFilter = "created_at >= datetime('now', '-7 days')"
		periodLabel = "7 Hari Terakhir (Mingguan)"
	case "monthly":
		dateFilter = "created_at >= datetime('now', '-30 days')"
		periodLabel = "30 Hari Terakhir (Bulanan)"
	case "yearly":
		dateFilter = "created_at >= datetime('now', 'start of year')"
		periodLabel = "Tahun Ini (" + time.Now().Format("2006") + ")"
	default:
		period = "all"
		dateFilter = "1=1"
		periodLabel = "Seluruh Periode"
	}

	analytics := &models.AnalyticsData{
		Period:      period,
		PeriodLabel: periodLabel,
	}

	// 1. Total & Resolved Rate
	row := DB.QueryRow(fmt.Sprintf(`
		SELECT COUNT(*),
		       COALESCE(SUM(CASE WHEN status IN ('Resolved', 'Closed') THEN 1 ELSE 0 END), 0)
		FROM tickets WHERE %s
	`, dateFilter))
	var resolvedCount int
	if err := row.Scan(&analytics.TotalTickets, &resolvedCount); err != nil {
		return nil, err
	}
	if analytics.TotalTickets > 0 {
		analytics.ResolvedRate = float64(resolvedCount) / float64(analytics.TotalTickets) * 100.0
	}

	// 2. Kendala Paling Banyak (Dikelompokkan per Kategori Utama: Hardware, Software, Jaringan & Akun)
	catRows, err := DB.Query(fmt.Sprintf(`
		SELECT category, COUNT(*) as cnt
		FROM tickets
		WHERE %s
		GROUP BY category
	`, dateFilter))
	if err == nil {
		defer catRows.Close()

		groupCounts := map[string]int{
			"Hardware":        0,
			"Software":        0,
			"Jaringan & Akun": 0,
			"Lainnya":         0,
		}

		for catRows.Next() {
			var catName string
			var count int
			if err := catRows.Scan(&catName, &count); err == nil {
				grp := ClassifyCategoryGroup(catName)
				groupCounts[grp] += count
			}
		}

		if analytics.TotalTickets > 0 {
			mainGroups := []string{"Hardware", "Software", "Jaringan & Akun"}
			sort.SliceStable(mainGroups, func(i, j int) bool {
				return groupCounts[mainGroups[i]] > groupCounts[mainGroups[j]]
			})

			for _, g := range mainGroups {
				analytics.TopCategories = append(analytics.TopCategories, models.ChartItem{
					Label: g,
					Count: groupCounts[g],
				})
			}

			if groupCounts["Lainnya"] > 0 {
				analytics.TopCategories = append(analytics.TopCategories, models.ChartItem{
					Label: "Lainnya",
					Count: groupCounts["Lainnya"],
				})
			}
		}
	}

	// 3. Departemen Terbanyak (Top Departments)
	deptRows, err := DB.Query(fmt.Sprintf(`
		SELECT department, COUNT(*) as cnt
		FROM tickets
		WHERE %s
		GROUP BY department
		ORDER BY cnt DESC
		LIMIT 8
	`, dateFilter))
	if err == nil {
		defer deptRows.Close()
		for deptRows.Next() {
			var item models.ChartItem
			if err := deptRows.Scan(&item.Label, &item.Count); err == nil {
				analytics.TopDepartments = append(analytics.TopDepartments, item)
			}
		}
	}

	// 4. Status Counts
	statusRows, err := DB.Query(fmt.Sprintf(`
		SELECT status, COUNT(*) as cnt
		FROM tickets
		WHERE %s
		GROUP BY status
		ORDER BY CASE status
			WHEN 'Open' THEN 1
			WHEN 'In Progress' THEN 2
			WHEN 'Pending' THEN 3
			WHEN 'Resolved' THEN 4
			WHEN 'Closed' THEN 5
			ELSE 6 END
	`, dateFilter))
	if err == nil {
		defer statusRows.Close()
		for statusRows.Next() {
			var item models.ChartItem
			if err := statusRows.Scan(&item.Label, &item.Count); err == nil {
				analytics.StatusCounts = append(analytics.StatusCounts, item)
			}
		}
	}

	// 5. Timeline tren tiket masuk vs selesai
	var timeFormat string
	if period == "yearly" || period == "all" {
		timeFormat = "%Y-%m"
	} else {
		timeFormat = "%Y-%m-%d"
	}

	timelineRows, err := DB.Query(fmt.Sprintf(`
		SELECT strftime('%s', created_at) as t_date,
		       COUNT(*) as incoming,
		       COALESCE(SUM(CASE WHEN status IN ('Resolved', 'Closed') THEN 1 ELSE 0 END), 0) as resolved
		FROM tickets
		WHERE %s
		GROUP BY t_date
		ORDER BY t_date ASC
	`, timeFormat, dateFilter))
	if err == nil {
		defer timelineRows.Close()
		for timelineRows.Next() {
			var item models.TimelineItem
			if err := timelineRows.Scan(&item.Date, &item.Incoming, &item.Resolved); err == nil {
				analytics.Timeline = append(analytics.Timeline, item)
			}
		}
	}

	return analytics, nil
}

func GetTicketsByPeriod(period string) ([]models.Ticket, error) {
	var dateFilter string
	switch period {
	case "weekly":
		dateFilter = "t.created_at >= datetime('now', '-7 days')"
	case "monthly":
		dateFilter = "t.created_at >= datetime('now', '-30 days')"
	case "yearly":
		dateFilter = "t.created_at >= datetime('now', 'start of year')"
	default:
		dateFilter = "1=1"
	}

	query := fmt.Sprintf(`
		SELECT t.id, t.ticket_code, t.requester_name, t.requester_email, COALESCE(t.requester_phone, ''),
		       t.department, t.category, t.priority, t.subject, t.description, COALESCE(t.attachment, ''),
		       t.status, t.assigned_to, COALESCE(u.name, 'Belum ditugaskan') as tech_name,
		       t.created_at, t.updated_at, t.resolved_at
		FROM tickets t
		LEFT JOIN users u ON t.assigned_to = u.id
		WHERE %s
		ORDER BY t.created_at DESC
	`, dateFilter)

	rows, err := DB.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tickets []models.Ticket
	for rows.Next() {
		var t models.Ticket
		var resolvedAt sql.NullTime
		var assignedTo sql.NullInt64

		if err := rows.Scan(
			&t.ID, &t.TicketCode, &t.RequesterName, &t.RequesterEmail, &t.RequesterPhone,
			&t.Department, &t.Category, &t.Priority, &t.Subject, &t.Description, &t.Attachment,
			&t.Status, &assignedTo, &t.TechnicianName,
			&t.CreatedAt, &t.UpdatedAt, &resolvedAt,
		); err != nil {
			return nil, err
		}
		if resolvedAt.Valid {
			t.ResolvedAt = &resolvedAt.Time
		}
		if assignedTo.Valid {
			t.AssignedTo = &assignedTo.Int64
		}
		t.CategoryGroup = ClassifyCategoryGroup(t.Category)
		tickets = append(tickets, t)
	}
	return tickets, nil
}

// GetTicketsForExport mengambil data tiket dengan filter fleksibel (rentang tanggal, per bulan, per tahun, atau periode)
func GetTicketsForExport(filterType, startDate, endDate string, month, year int, period, status, category, dept string) ([]models.Ticket, string, string, error) {
	var conditions []string
	var args []interface{}

	var periodLabel string
	var filenameSuffix string

	monthNames := []string{
		"", "Januari", "Februari", "Maret", "April", "Mei", "Juni",
		"Juli", "Agustus", "September", "Oktober", "November", "Desember",
	}

	switch filterType {
	case "range", "custom":
		if startDate != "" && endDate != "" {
			conditions = append(conditions, "substr(t.created_at, 1, 10) >= ? AND substr(t.created_at, 1, 10) <= ?")
			args = append(args, startDate, endDate)
			periodLabel = fmt.Sprintf("Rentang Tanggal: %s s/d %s", startDate, endDate)
			filenameSuffix = fmt.Sprintf("%s_sd_%s", startDate, endDate)
		} else if startDate != "" {
			conditions = append(conditions, "substr(t.created_at, 1, 10) >= ?")
			args = append(args, startDate)
			periodLabel = fmt.Sprintf("Mulai Tanggal: %s", startDate)
			filenameSuffix = fmt.Sprintf("dari_%s", startDate)
		} else if endDate != "" {
			conditions = append(conditions, "substr(t.created_at, 1, 10) <= ?")
			args = append(args, endDate)
			periodLabel = fmt.Sprintf("Sampai Tanggal: %s", endDate)
			filenameSuffix = fmt.Sprintf("sampai_%s", endDate)
		} else {
			periodLabel = "Semua Tanggal"
			filenameSuffix = "semua"
		}

	case "month":
		if year <= 0 {
			year = time.Now().Year()
		}
		if month >= 1 && month <= 12 {
			mStr := fmt.Sprintf("%04d-%02d", year, month)
			conditions = append(conditions, "substr(t.created_at, 1, 7) = ?")
			args = append(args, mStr)
			periodLabel = fmt.Sprintf("Bulan %s %d", monthNames[month], year)
			filenameSuffix = fmt.Sprintf("%04d_%02d_%s", year, month, monthNames[month])
		} else {
			yStr := fmt.Sprintf("%04d", year)
			conditions = append(conditions, "substr(t.created_at, 1, 4) = ?")
			args = append(args, yStr)
			periodLabel = fmt.Sprintf("Tahun %d", year)
			filenameSuffix = fmt.Sprintf("tahun_%d", year)
		}

	case "year":
		if year <= 0 {
			year = time.Now().Year()
		}
		yStr := fmt.Sprintf("%04d", year)
		conditions = append(conditions, "substr(t.created_at, 1, 4) = ?")
		args = append(args, yStr)
		periodLabel = fmt.Sprintf("Tahun %d", year)
		filenameSuffix = fmt.Sprintf("tahun_%d", year)

	default: // period fallback: weekly, monthly, yearly, all
		switch period {
		case "weekly":
			conditions = append(conditions, "substr(t.created_at, 1, 10) >= date('now', '-7 days')")
			periodLabel = "7 Hari Terakhir (Mingguan)"
			filenameSuffix = "mingguan_7hari"
		case "monthly":
			conditions = append(conditions, "substr(t.created_at, 1, 10) >= date('now', '-30 days')")
			periodLabel = "30 Hari Terakhir (Bulanan)"
			filenameSuffix = "bulanan_30hari"
		case "yearly":
			conditions = append(conditions, "substr(t.created_at, 1, 4) = strftime('%Y', 'now')")
			periodLabel = fmt.Sprintf("Tahun Ini (%d)", time.Now().Year())
			filenameSuffix = fmt.Sprintf("tahun_%d", time.Now().Year())
		default:
			periodLabel = "Seluruh Periode Data"
			filenameSuffix = "semua_tiket"
		}
	}

	// Filter Tambahan: Status
	if status != "" && status != "all" {
		conditions = append(conditions, "LOWER(t.status) = LOWER(?)")
		args = append(args, status)
		periodLabel += fmt.Sprintf(" | Status: %s", status)
	}

	// Filter Tambahan: Kategori
	if category != "" && category != "all" {
		conditions = append(conditions, "LOWER(t.category) = LOWER(?)")
		args = append(args, category)
		periodLabel += fmt.Sprintf(" | Kategori: %s", category)
	}

	// Filter Tambahan: Departemen / Unit
	if dept != "" && dept != "all" {
		conditions = append(conditions, "LOWER(t.department) = LOWER(?)")
		args = append(args, dept)
		periodLabel += fmt.Sprintf(" | Unit: %s", dept)
	}

	whereClause := "1=1"
	if len(conditions) > 0 {
		whereClause = strings.Join(conditions, " AND ")
	}

	query := fmt.Sprintf(`
		SELECT t.id, t.ticket_code, t.requester_name, t.requester_email, COALESCE(t.requester_phone, ''),
		       t.department, t.category, t.priority, t.subject, t.description, COALESCE(t.attachment, ''),
		       t.status, t.assigned_to, COALESCE(u.name, 'Belum ditugaskan') as tech_name,
		       t.created_at, t.updated_at, t.resolved_at
		FROM tickets t
		LEFT JOIN users u ON t.assigned_to = u.id
		WHERE %s
		ORDER BY t.created_at DESC
	`, whereClause)

	rows, err := DB.Query(query, args...)
	if err != nil {
		return nil, "", "", err
	}
	defer rows.Close()

	var tickets []models.Ticket
	for rows.Next() {
		var t models.Ticket
		var resolvedAt sql.NullTime
		var assignedTo sql.NullInt64

		if err := rows.Scan(
			&t.ID, &t.TicketCode, &t.RequesterName, &t.RequesterEmail, &t.RequesterPhone,
			&t.Department, &t.Category, &t.Priority, &t.Subject, &t.Description, &t.Attachment,
			&t.Status, &assignedTo, &t.TechnicianName,
			&t.CreatedAt, &t.UpdatedAt, &resolvedAt,
		); err != nil {
			return nil, "", "", err
		}
		if resolvedAt.Valid {
			t.ResolvedAt = &resolvedAt.Time
		}
		if assignedTo.Valid {
			t.AssignedTo = &assignedTo.Int64
		}
		t.CategoryGroup = ClassifyCategoryGroup(t.Category)
		if strings.HasPrefix(category, "group:") {
			targetGroup := strings.TrimPrefix(category, "group:")
			if !strings.EqualFold(t.CategoryGroup, targetGroup) {
				continue
			}
		}
		tickets = append(tickets, t)
	}

	filename := fmt.Sprintf("Laporan_Tiket_IT_%s.xlsx", filenameSuffix)
	return tickets, periodLabel, filename, nil
}

// =========================================================
// TELEGRAM BOT AGENT QUERIES & HELPERS
// =========================================================

// GetAllActiveTelegramSubscribers mengambil semua chat_id penerima notifikasi yang aktif
func GetAllActiveTelegramSubscribers() ([]string, error) {
	rows, err := DB.Query("SELECT chat_id FROM telegram_subscribers WHERE is_active = 1")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var chatIDs []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err == nil && strings.TrimSpace(id) != "" {
			chatIDs = append(chatIDs, strings.TrimSpace(id))
		}
	}
	return chatIDs, nil
}

// GetAllTelegramSubscribers mengambil daftar lengkap pelanggan notifikasi Telegram
func GetAllTelegramSubscribers() ([]models.TelegramSubscriber, error) {
	rows, err := DB.Query("SELECT id, chat_id, name, username, is_active, created_at, updated_at FROM telegram_subscribers ORDER BY created_at DESC")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []models.TelegramSubscriber
	for rows.Next() {
		var s models.TelegramSubscriber
		var active int
		if err := rows.Scan(&s.ID, &s.ChatID, &s.Name, &s.Username, &active, &s.CreatedAt, &s.UpdatedAt); err == nil {
			s.IsActive = active == 1
			list = append(list, s)
		}
	}
	return list, nil
}

// RegisterTelegramSubscriber mendaftarkan / memperbarui pelanggan bot Telegram
func RegisterTelegramSubscriber(chatID, name, username string) error {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return fmt.Errorf("chat_id tidak boleh kosong")
	}

	_, err := DB.Exec(`
		INSERT INTO telegram_subscribers (chat_id, name, username, is_active, updated_at)
		VALUES (?, ?, ?, 1, CURRENT_TIMESTAMP)
		ON CONFLICT(chat_id) DO UPDATE SET
			name = CASE WHEN ? != '' THEN ? ELSE name END,
			username = CASE WHEN ? != '' THEN ? ELSE username END,
			is_active = 1,
			updated_at = CURRENT_TIMESTAMP
	`, chatID, name, username, name, name, username, username)
	return err
}

// SetTelegramSubscriberActive mengaktifkan / menonaktifkan status langganan
func SetTelegramSubscriberActive(chatID string, active bool) error {
	val := 0
	if active {
		val = 1
	}
	_, err := DB.Exec("UPDATE telegram_subscribers SET is_active = ?, updated_at = CURRENT_TIMESTAMP WHERE chat_id = ?", val, strings.TrimSpace(chatID))
	return err
}

// DeleteTelegramSubscriber menghapus subscriber Telegram
func DeleteTelegramSubscriber(chatID string) error {
	_, err := DB.Exec("DELETE FROM telegram_subscribers WHERE chat_id = ?", strings.TrimSpace(chatID))
	return err
}

// GetTelegramSetting membaca pengaturan bot Telegram dari database
func GetTelegramSetting(key string, fallback string) string {
	var val string
	err := DB.QueryRow("SELECT value FROM telegram_settings WHERE key = ?", key).Scan(&val)
	if err != nil || strings.TrimSpace(val) == "" {
		return fallback
	}
	return strings.TrimSpace(val)
}

// SetTelegramSetting menyimpan pengaturan bot Telegram ke database
func SetTelegramSetting(key, value string) error {
	_, err := DB.Exec(`
		INSERT INTO telegram_settings (key, value) VALUES (?, ?)
		ON CONFLICT(key) DO UPDATE SET value = ?
	`, key, value, value)
	return err
}

// UpdateUserTelegramChatID menghubungkan chat_id Telegram ke akun teknisi
func UpdateUserTelegramChatID(userID int64, chatID string) error {
	_, err := DB.Exec("UPDATE users SET telegram_chat_id = ? WHERE id = ?", strings.TrimSpace(chatID), userID)
	return err
}



